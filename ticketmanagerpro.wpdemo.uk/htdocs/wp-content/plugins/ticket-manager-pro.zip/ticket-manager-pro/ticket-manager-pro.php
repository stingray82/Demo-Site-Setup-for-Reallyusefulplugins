<?php
/**
 * Plugin Name: Ticket Manager Pro
 * Description: Assigns sequential event tickets from SureCart purchases, supports multiple events & ticket prices.
 * Version: 1.35
 * Author: ReallyUsefulPlugins.com
 * Author URI: Reallyusefulplugins.com
 * (c) Nathan Foley 2025
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RUPTMP4SC_VERSION', '1.33' );
define( 'RUPTMP4SC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RUPTMP4SC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );


/* --------------------------------------------------
   DEBUGGING HELPER FUNCTION
-------------------------------------------------- */
function rup_tmp4sc_log_debug( $message ) {
    if ( get_option( 'ticket_debug_mode', false ) ) {
        error_log( $message );
    }
}

/* --------------------------------------------------
   DELETE EVENT FUNCTION
-------------------------------------------------- */
function rup_tmp4sc_delete_event( $event_name ) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'event_tickets';
    // Delete tickets associated with the event.
    $wpdb->delete( $table_name, [ 'event_name' => $event_name ] );
    
    // Remove the event from our settings array.
    $events = json_decode( get_option( 'ticket_events', '[]' ), true );
    $new_events = [];
    if ( is_array( $events ) ) {
        foreach ( $events as $event ) {
            if ( $event['event_name'] !== $event_name ) {
                $new_events[] = $event;
            }
        }
    }
    update_option( 'ticket_events', json_encode( $new_events ) );
}

/* --------------------------------------------------
   SET HTML MAIL CONTENT TYPE
-------------------------------------------------- */
function rup_tmp4sc_set_html_content_type() {
    return 'text/html';
}

/* --------------------------------------------------
   ADD ADMIN MENU (Settings page only)
-------------------------------------------------- */
function rup_tmp4sc_ticket_manager_menu() {
    add_menu_page( 
        'Ticket Manager Settings',   // Page title
        'Ticket Manager',            // Menu title
        'manage_options',            // Capability
        'ticket-manager',            // Menu slug
        'rup_tmp4sc_ticket_manager_settings_page', // Callback function
        'dashicons-tickets-alt',     // Icon (WordPress Dashicon)
        90                           // Position (optional)
    );
}
add_action( 'admin_menu', 'rup_tmp4sc_ticket_manager_menu' );


/* --------------------------------------------------
   DYNAMIC SOLD REPORT PAGE
   When a URL like ?sold_report=1&event=EventName is visited, output a report page.
-------------------------------------------------- */
function rup_tmp4sc_handle_sold_report_dynamic_page() {
    if ( isset( $_GET['sold_report'] ) && '1' === $_GET['sold_report'] && ! empty( $_GET['event'] ) ) {
        $event_name = sanitize_text_field( $_GET['event'] );
        global $wpdb;
        $table_name = $wpdb->prefix . 'event_tickets';
        $tickets = $wpdb->get_results( $wpdb->prepare(
            "SELECT buyer_name, order_id, ticket_number FROM $table_name WHERE event_name = %s AND assigned = 1 ORDER BY ticket_number ASC",
            $event_name
        ) );
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Sold Report for <?php echo esc_html( $event_name ); ?></title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                table { border-collapse: collapse; width: 100%; margin-top: 20px; }
                table, th, td { border: 1px solid #000; }
                th, td { padding: 8px; text-align: left; }
                .no-print { margin-bottom: 20px; }
                @media print { .no-print { display: none; } }
            </style>
        </head>
        <body>
            <button class="no-print" onclick="window.print();">Print / Save as PDF</button>
            <h1>Sold Report for <?php echo esc_html( $event_name ); ?></h1>
            <?php if ( $tickets ) : ?>
                <table>
                    <thead>
                        <tr>
                            <th>Buyer Name</th>
                            <th>Order ID</th>
                            <th>Ticket #</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $tickets as $ticket ) : ?>
                            <tr>
                                <td><?php echo esc_html( $ticket->buyer_name ); ?></td>
                                <td><?php echo esc_html( $ticket->order_id ); ?></td>
                                <td><?php echo esc_html( $ticket->ticket_number ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p>No sold tickets found for this event.</p>
            <?php endif; ?>
        </body>
        </html>
        <?php
        exit;
    }
}
add_action( 'template_redirect', 'rup_tmp4sc_handle_sold_report_dynamic_page' );

/* --------------------------------------------------
   ADMIN SETTINGS PAGE (with Sold Report button)
-------------------------------------------------- */
function rup_tmp4sc_ticket_manager_settings_page() {
    global $wpdb;

    if ( ! rup_tmp4sc_is_activated_and_licensed() ) {
        echo '<div class="wrap">';
        echo '<h1>Plugin Activation Required</h1>';
        echo '<p>Please activate your license to access these settings.</p>';
        echo '</div>';
        return; // Prevent further rendering
    }    
    // Check for POST actions.
    if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
        if ( isset( $_POST['create_tables'] ) ) {
            rup_tmp4sc_create_event_tickets_table();
            echo '<div class="updated"><p>✅ Event ticket table created successfully.</p></div>';
        }
        if ( isset( $_POST['delete_tables'] ) ) {
            rup_tmp4sc_delete_event_tickets_table();
            echo '<div class="error"><p>❌ Event ticket table deleted.</p></div>';
        }
        if ( isset( $_POST['populate_data'] ) && isset( $_POST['event_name'] ) ) {
            rup_tmp4sc_populate_event_tickets( $_POST['event_name'] );
            echo '<div class="updated"><p>🎟️ Tickets populated for ' . esc_html( $_POST['event_name'] ) . '.</p></div>';
        }
        if ( isset( $_POST['delete_event'] ) && isset( $_POST['event_name'] ) ) {
            rup_tmp4sc_delete_event( $_POST['event_name'] );
            echo '<div class="updated"><p>🗑️ Event ' . esc_html( $_POST['event_name'] ) . ' deleted.</p></div>';
        }
        if ( isset( $_POST['edit_event'] ) && isset( $_POST['event_name'] ) ) {
            $events = json_decode( get_option( 'ticket_events', '[]' ), true );
            foreach ( $events as $event ) {
                if ( $event['event_name'] === $_POST['event_name'] ) {
                    $editing_event = $event;
                    break;
                }
            }
        }
        if ( isset( $_POST['save_event'] ) ) {
            $new_event = [
                'event_name'     => sanitize_text_field( $_POST['event_name'] ),
                'price_id'       => sanitize_text_field( $_POST['price_id'] ),
                'ticket_path'    => sanitize_text_field( $_POST['ticket_path'] ),
                'naming_pattern' => sanitize_text_field( $_POST['naming_pattern'] ),
                'email_subject'  => sanitize_text_field( $_POST['email_subject'] ),
                'email_message'  => wp_kses_post( $_POST['email_message'] ),
                'delivery_mode'  => in_array( $_POST['delivery_mode'], [ 'both', 'email_only', 'download_only' ] ) ? $_POST['delivery_mode'] : 'both',
                'start_date'     => sanitize_text_field( $_POST['start_date'] ),
                'end_date'       => sanitize_text_field( $_POST['end_date'] )
            ];
            $events = json_decode( get_option( 'ticket_events', '[]' ), true );
            $updated = false;
            if ( is_array( $events ) ) {
                foreach ( $events as &$event ) {
                    if ( $event['event_name'] === $_POST['event_name_original'] ) {
                        $event = $new_event;
                        $updated = true;
                        break;
                    }
                }
            }
            if ( ! $updated ) {
                $events[] = $new_event;
            }
            update_option( 'ticket_events', json_encode( $events ) );
            echo '<div class="updated"><p>🎟️ Event saved successfully!</p></div>';
        }
        if ( isset( $_POST['update_download_page'] ) ) {
            $download_page = esc_url_raw( $_POST['download_page'] );
            update_option( 'ticket_download_page', $download_page );
            echo '<div class="updated"><p>📥 Ticket download page updated.</p></div>';
        }
        if ( isset( $_POST['update_reminder_text'] ) ) {
            $reminder_text = sanitize_text_field( $_POST['reminder_text'] );
            update_option( 'ticket_event_reminder', $reminder_text );
            echo '<div class="updated"><p>📥 Event email reminder updated.</p></div>';
        }
        if ( isset( $_POST['update_debug_mode'] ) ) {
            $debug_mode = isset( $_POST['debug_mode'] ) ? 1 : 0;
            update_option( 'ticket_debug_mode', $debug_mode );
            echo '<div class="updated"><p>🛠 Debug mode ' . ( $debug_mode ? 'enabled' : 'disabled' ) . '.</p></div>';
        }
        
        // NEW: Handle saving "Activate Tabbed Block" option.
        if ( isset( $_POST['activate_tabbed_block_checkbox'] ) ) {
            update_option( 'activate_tabbed_block', 1 );
        } else {
            update_option( 'activate_tabbed_block', 0 );
        }
        echo '<div class="updated"><p>Tabbed Block setting updated.</p></div>';
    }
    
    // Retrieve settings.
    $events                = json_decode( get_option( 'ticket_events', '[]' ), true );
    $debug_mode            = get_option( 'ticket_debug_mode', false );
    $download_page         = get_option( 'ticket_download_page', '' );
    $reminder_text         = get_option( 'ticket_event_reminder', 'Note: You will receive a separate email for each event purchased.' );
    $table_name            = $wpdb->prefix . 'event_tickets';
    $editing_event         = isset( $editing_event ) ? $editing_event : null;
    $activate_tabbed_block = get_option( 'activate_tabbed_block', 0 );
    ?>
    <div class="wrap">
        <h1>Ticket Manager Settings</h1>
        <!-- ADMIN ACTIONS -->
        <form method="post">
            <button type="submit" name="create_tables" class="button button-primary">Create Tables</button>
            <button type="submit" name="delete_tables" class="button button-secondary" onclick="return confirm('⚠️ Are you sure you want to delete the ticket table? This cannot be undone!');">Delete Tables</button>
        </form>
        
        <!-- NEW: Activate Tabbed Block Option -->
        <h2>Tabbed Block Activation</h2>
        <form method="post">
            <label>
                <input type="checkbox" name="activate_tabbed_block_checkbox" value="1" <?php checked( $activate_tabbed_block, 1 ); ?>>
                Activate Tabbed Block
            </label>
            <br><br>
            <button type="submit" class="button button-primary">Save Tabbed Block Setting</button>
        </form>
        
        <!-- DOWNLOAD PAGE SETTING -->
        <h2>Ticket Download Page</h2>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>Page URL</th>
                    <td>
                        <input type="url" name="download_page" class="regular-text" value="<?php echo esc_attr( $download_page ); ?>">
                        <p>This is the page where you’ve added the [ticket_auto_download] shortcode for downloading tickets.</p>
                    </td>
                </tr>
            </table>
            <button type="submit" name="update_download_page" class="button button-primary">Save Download Page</button>
        </form>
        
        <!-- EVENT EMAIL REMINDER -->
        <h2>Event Email Reminder</h2>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>Reminder Message</th>
                    <td>
                        <input type="text" name="reminder_text" class="regular-text" value="<?php echo esc_attr( $reminder_text ); ?>">
                        <p>This message will be appended at the bottom of event emails if more than one event is purchased.</p>
                    </td>
                </tr>
            </table>
            <button type="submit" name="update_reminder_text" class="button button-primary">Save Reminder Message</button>
        </form>
        
        <!-- DEBUG MODE -->
        <h2>Debug Mode</h2>
        <form method="post">
            <label>
                <input type="checkbox" name="debug_mode" value="1" <?php checked( $debug_mode, 1 ); ?>>
                Enable Debugging (logs in wp-content/debug.log)
            </label>
            <button type="submit" name="update_debug_mode" class="button button-primary">Save Debug Settings</button>
        </form>
        
        <!-- ADD / EDIT EVENT FORM -->
        <h2><?php echo $editing_event ? 'Edit Event' : 'Add Event'; ?></h2>
        <form method="post">
            <input type="hidden" name="event_name_original" value="<?php echo esc_attr( $editing_event['event_name'] ?? '' ); ?>">
            <table class="form-table">
                <tr>
                    <th>Event Name</th>
                    <td><input type="text" name="event_name" required class="regular-text" value="<?php echo esc_attr( $editing_event['event_name'] ?? '' ); ?>"></td>
                </tr>
                <tr>
                    <th>Price ID</th>
                    <td>
                        <input type="text" name="price_id" required class="regular-text" value="<?php echo esc_attr( $editing_event['price_id'] ?? '' ); ?>">
                        <p>This is your SureCart Price ID.</p>
                    </td>
                </tr>
                <tr>
    <th>Ticket Path</th>
    <td>
        <?php $uploads_dir = wp_upload_dir(); ?>
        <input type="text" name="ticket_path" id="ticket_path" required class="regular-text" value="<?php echo esc_attr( $editing_event['ticket_path'] ?? '' ); ?>">
        <button type="button" id="set_as_uploads" class="button">Set as Uploads</button>
        <p>This MUST be the full path to your tickets.</p>
        <script type="text/javascript">
            document.getElementById('set_as_uploads').addEventListener('click', function() {
                document.getElementById('ticket_path').value = '<?php echo esc_js( $uploads_dir['basedir'] ); ?>';
            });
        </script>
    </td>
</tr>
                <tr>
                    <th>Naming Pattern</th>
                    <td>
                        <input type="text" name="naming_pattern" required class="regular-text" value="<?php echo esc_attr( $editing_event['naming_pattern'] ?? '' ); ?>">
                        <p>Example: ticket_event_{NUMBER}.pdf</p>
                    </td>
                </tr>
                <tr>
                    <th>Email Subject</th>
                    <td>
                        <input type="text" name="email_subject" required class="regular-text" value="<?php echo esc_attr( $editing_event['email_subject'] ?? 'Your Event Ticket(s)' ); ?>">
                    </td>
                </tr>
                <tr>
    <th>Email Message</th>
    <td>
        <?php
        $content = $editing_event['email_message'] ?? 'Hello, here are your tickets:';
        wp_editor( $content, 'email_message', array(
            'textarea_name' => 'email_message',
            'media_buttons' => false,
            'textarea_rows' => 10,
            'teeny'         => true,
        ) );
        ?>
        <p>Use <strong>{TICKET_LINKS}</strong> where you want the download link to appear. Use <strong>{NAME}</strong> to insert the buyers Name      
        </p>
        <p><button type="button" id="insert_ticket_shortcode" class="button">Insert Download Link</button>
            <button type="button" id="insert_name_shortcode" class="button">Insert Buyers Name</button></p>
        <script type="text/javascript">
            // Insert {TICKET_LINKS} when the Insert Download Link button is clicked
            document.getElementById('insert_ticket_shortcode').addEventListener('click', function() {
                if (typeof tinymce !== 'undefined' && tinymce.activeEditor) {
                    tinymce.activeEditor.execCommand('mceInsertContent', false, '{TICKET_LINKS}');
                }
            });
            // Insert {NAME} when the Insert Buyers Name button is clicked
            document.getElementById('insert_name_shortcode').addEventListener('click', function() {
                if (typeof tinymce !== 'undefined' && tinymce.activeEditor) {
                    tinymce.activeEditor.execCommand('mceInsertContent', false, '{NAME}');
                }
            });
        </script>
    </td>
</tr>

                <tr>
                    <th>Delivery Mode</th>
                    <td>
                        <select name="delivery_mode" class="regular-text">
                            <option value="both" <?php selected( $editing_event['delivery_mode'] ?? 'both', 'both' ); ?>>Both (Email Attachments + Download Link)</option>
                            <option value="email_only" <?php selected( $editing_event['delivery_mode'] ?? 'both', 'email_only' ); ?>>Email Only (Attachments Only)</option>
                            <option value="download_only" <?php selected( $editing_event['delivery_mode'] ?? 'both', 'download_only' ); ?>>Download Link Only</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Start Date</th>
                    <td>
                        <input type="date" name="start_date" required class="regular-text" value="<?php echo esc_attr( $editing_event['start_date'] ?? '' ); ?>">
                    </td>
                </tr>
                <tr>
                    <th>End Date</th>
                    <td>
                        <input type="date" name="end_date" required class="regular-text" value="<?php echo esc_attr( $editing_event['end_date'] ?? '' ); ?>">
                        <p class="description">This should be at least 1 day after the event.</p>
                    </td>
                </tr>
            </table>
            <button type="submit" name="save_event" class="button button-primary">Save Event</button>
        </form>
        
        <!-- EVENT LIST -->
        <h2>Ticket Availability</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Event & Price</th>
                    <th>Price ID</th>
                    <th>Total in Folder</th>
                    <th>Sold (DB)</th>
                    <th>Remaining</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ( is_array( $events ) ) : ?>
                    <?php foreach ( $events as $event ) : ?>
                        <?php
                            $total_tickets = 0;
                            if ( is_dir( $event['ticket_path'] ) ) {
                                $files = glob( $event['ticket_path'] . "/*.pdf" );
                                $total_tickets = is_array( $files ) ? count( $files ) : 0;
                            }
                            $sold_tickets = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table_name WHERE assigned = 1 AND event_name = %s", $event['event_name'] ) ) ?: 0;
                            $remaining_tickets = max( 0, $total_tickets - $sold_tickets );
                        ?>
                        <tr>
                            <td><?php echo esc_html( $event['event_name'] ); ?></td>
                            <td><?php echo esc_html( $event['price_id'] ); ?></td>
                            <td><?php echo esc_html( $total_tickets ); ?></td>
                            <td><?php echo esc_html( $sold_tickets ); ?></td>
                            <td><?php echo esc_html( $remaining_tickets ); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="event_name" value="<?php echo esc_attr( $event['event_name'] ); ?>">
                                    <button type="submit" name="edit_event" class="button">Edit</button>
                                    <button type="submit" name="populate_data" class="button button-secondary">Populate</button>
                                    <button type="submit" name="delete_event" class="button button-danger" onclick="return confirm('⚠️ Are you sure you want to delete this event?');">Delete</button>
                                    <!-- Sold Report Button: redirects to dynamic page -->
                                    <?php
                                    $report_url = add_query_arg( [
                                        'sold_report' => '1',
                                        'event'       => urlencode( $event['event_name'] )
                                    ], home_url() );
                                    ?>
                                    <a href="<?php echo esc_url( $report_url ); ?>" class="button">Sold Report</a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

/* --------------------------------------------------
   Debug Checkout Data from SureCart
-------------------------------------------------- */
function rup_tmp4sc_debug_checkout_data( $checkout ) {
    rup_tmp4sc_log_debug( "=== Debug: SureCart Checkout Data ===" );
    rup_tmp4sc_log_debug( print_r( $checkout, true ) );
    rup_tmp4sc_log_debug( "======================================" );
}
add_action( 'surecart/checkout_confirmed', 'rup_tmp4sc_debug_checkout_data', 10, 2 );

/* --------------------------------------------------
   PROCESS TICKET ORDERS WITH CUSTOM EMAIL (ONE EMAIL PER EVENT)
-------------------------------------------------- */
function rup_tmp4sc_assign_and_send_tickets( $checkout, $request ) {
     if ( ! rup_tmp4sc_is_activated_and_licensed() ) {
        // Output an error message using your debug function.
        rup_tmp4sc_debug_checkout_data( 'Error: Please activate license via the appropriate activation page.' );
        return; // Stop further execution.
    }
    global $wpdb;

    // Debug the checkout object.
    rup_tmp4sc_debug_checkout_data( $checkout );

    $order_id       = $checkout->id;
    $customer_email = $checkout->email;
    
    // Capture the buyer's name.
    if ( isset( $checkout->name ) && ! empty( $checkout->name ) ) {
        $buyer_name = sanitize_text_field( $checkout->name );
    } elseif ( isset( $checkout->inherited_name ) && ! empty( $checkout->inherited_name ) ) {
        $buyer_name = sanitize_text_field( $checkout->inherited_name );
    } else {
        $buyer_name = '';
        if ( isset( $checkout->billing ) ) {
            $first = isset( $checkout->billing->first_name ) ? sanitize_text_field( $checkout->billing->first_name ) : '';
            $last  = isset( $checkout->billing->last_name ) ? sanitize_text_field( $checkout->billing->last_name ) : '';
            $buyer_name = trim( $first . ' ' . $last );
        }
    }
    
    // Determine distinct events in this order.
    $distinct_events = [];
    foreach ( $checkout->line_items->data as $item ) {
        $price_id = $item->price_id ?? null;
        if ( ! $price_id ) {
            continue;
        }
        $all_events = json_decode( get_option( 'ticket_events', '[]' ), true );
        foreach ( $all_events as $event ) {
            if ( $event['price_id'] === $price_id ) {
                $distinct_events[ $event['event_name'] ] = true;
            }
        }
    }
    $num_events = count( $distinct_events );
    $include_reminder = $num_events > 1;
    $reminder_text = get_option( 'ticket_event_reminder', 'Note: You will receive a separate email for each event purchased.' );

    // Process each line item so that each event gets its own email.
    foreach ( $checkout->line_items->data as $item ) {
        $price_id = $item->price_id ?? null;
        $quantity = isset( $item->quantity ) ? intval( $item->quantity ) : 1;
        if ( ! $price_id || $quantity < 1 ) {
            rup_tmp4sc_log_debug( "Invalid line item - missing price ID or quantity." );
            continue;
        }
        rup_tmp4sc_log_debug( "Processing line item with Price ID: {$price_id} (Quantity: {$quantity}) for order {$order_id}" );

        $events = json_decode( get_option( 'ticket_events', '[]' ), true );
        foreach ( $events as $event ) {
            if ( $event['price_id'] === $price_id ) {
                // Query available (unassigned) tickets for this event.
                $available_tickets = $wpdb->get_results( $wpdb->prepare( "
                    SELECT id, ticket_number FROM {$wpdb->prefix}event_tickets 
                    WHERE assigned = 0 AND event_name = %s 
                    ORDER BY ticket_number ASC LIMIT %d",
                    $event['event_name'], $quantity
                ) );
                $available_count = count( $available_tickets );
                rup_tmp4sc_log_debug( "Found {$available_count} available tickets for event: {$event['event_name']}" );
                if ( $available_count < $quantity ) {
                    rup_tmp4sc_log_debug( "Not enough tickets available for event {$event['event_name']}. Requested: {$quantity}, Available: {$available_count}" );
                    continue 2;
                }

                // Determine delivery mode. Default to "both" if not set.
                $mode = isset( $event['delivery_mode'] ) ? $event['delivery_mode'] : 'both';
                rup_tmp4sc_log_debug( "Delivery mode for event {$event['event_name']}: {$mode}" );
                
                // Initialize attachments array.
                $attachments = [];
                // Assign tickets.
                foreach ( $available_tickets as $ticket ) {
                    $file_name = str_replace( '{NUMBER}', $ticket->ticket_number, $event['naming_pattern'] );
                    rup_tmp4sc_log_debug( "Assigning ticket #{$ticket->ticket_number} with file name {$file_name} for event {$event['event_name']}" );
                    $wpdb->update( "{$wpdb->prefix}event_tickets", 
                        [
                            'assigned'       => 1, 
                            'customer_email' => $customer_email, 
                            'order_id'       => $order_id,
                            'buyer_name'     => $buyer_name
                        ], 
                        [ 'id' => $ticket->id ] 
                    );
                    if ( in_array( $mode, [ 'both', 'email_only' ] ) ) {
                        $file_path = rtrim( $event['ticket_path'], '/' ) . '/' . $file_name;
                        if ( file_exists( $file_path ) ) {
                            $attachments[] = $file_path;
                            rup_tmp4sc_log_debug( "Attached file: {$file_path}" );
                        } else {
                            rup_tmp4sc_log_debug( "File not found for ticket #{$ticket->ticket_number}: {$file_path}" );
                        }
                    }
                }

                // Build the download URL for this event.
                $download_page = get_option( 'ticket_download_page', '' );
                rup_tmp4sc_log_debug( "Download page URL setting: " . $download_page );
                if ( empty( $download_page ) ) {
                    rup_tmp4sc_log_debug("Download page URL is empty. Skipping download link generation.");
                }
                $download_url = add_query_arg( [
                    'order_id' => $order_id,
                    'email'    => $customer_email,
                    'event'    => $event['event_name']
                ], $download_page );
                rup_tmp4sc_log_debug( "Generated download URL for event {$event['event_name']}: {$download_url}" );

                // Build the email body.
                $email_body = $event['email_message'];
                $email_body = str_replace( '{rup_tmp4sc_buyersname}', esc_html( $buyer_name ), $email_body );
                
                if ( in_array( $mode, [ 'download_only', 'both' ] ) ) {
                    if ( preg_match( '/\{TICKET_LINKS\}/i', $email_body ) ) {
                        $email_body = preg_replace( '/\{TICKET_LINKS\}/i', "<a href='" . esc_url( $download_url ) . "'>Download Your Tickets</a>", $email_body );
                    } else {
                        $email_body .= "<br><br><a href='" . esc_url( $download_url ) . "'>Download Your Tickets</a>";
                    }
                }
                if ( $include_reminder ) {
                    $email_body .= "<br><br>" . $reminder_text;
                }
                
                $email_attachments = in_array( $mode, [ 'both', 'email_only' ] ) ? $attachments : [];

                add_filter( 'wp_mail_content_type', 'rup_tmp4sc_set_html_content_type' );
                wp_mail( $customer_email, $event['email_subject'], $email_body, [], $email_attachments );
                rup_tmp4sc_log_debug( "Email sent to {$customer_email} for event {$event['event_name']} with subject: {$event['email_subject']}" );
                remove_filter( 'wp_mail_content_type', 'rup_tmp4sc_set_html_content_type' );
            }
        }
    }
}
add_action( 'surecart/checkout_confirmed', 'rup_tmp4sc_assign_and_send_tickets', 10, 2 );

// Allow the "ticket_download" query var.
function rup_tmp4sc_add_query_vars( $vars ) {
    $vars[] = 'ticket_download';
    return $vars;
}
add_filter( 'query_vars', 'rup_tmp4sc_add_query_vars' );

/* --------------------------------------------------
   SHORTCODE FOR TICKET DOWNLOAD PAGE
-------------------------------------------------- */
function rup_tmp4sc_ticket_auto_download_shortcode() {
    // Start output buffering.
    ob_start();

    rup_tmp4sc_log_debug("=== [Shortcode] Starting ticket download shortcode processing ===");

    global $wpdb;

    $order_id     = isset( $_GET['order_id'] ) ? sanitize_text_field( $_GET['order_id'] ) : '';
    $email        = isset( $_GET['email'] ) ? sanitize_email( $_GET['email'] ) : '';
    $event_filter = isset( $_GET['event'] ) ? sanitize_text_field( $_GET['event'] ) : '';

    rup_tmp4sc_log_debug("[Shortcode] Received parameters: order_id='$order_id', email='$email', event='$event_filter'");

    if ( empty( $order_id ) || empty( $email ) ) {
        rup_tmp4sc_log_debug("[Shortcode] Missing order ID or email.");
        return ob_get_clean() . '<p style="color: red;">⚠️ Missing order ID or email.</p>';
    }
    
    if ( empty( $event_filter ) ) {
        rup_tmp4sc_log_debug("[Shortcode] Missing event parameter.");
        return ob_get_clean() . '<p style="color: red;">⚠️ Missing event parameter. Please contact support.</p>';
    }

    $query = "
        SELECT ticket_number, event_name 
        FROM {$wpdb->prefix}event_tickets 
        WHERE order_id = %s AND customer_email = %s
        AND event_name = %s
    ";
    $params = [ $order_id, $email, $event_filter ];
    rup_tmp4sc_log_debug("[Shortcode] Executing query: $query with parameters: " . json_encode($params));
    $tickets = $wpdb->get_results( $wpdb->prepare( $query, $params ) );

    if ( ! $tickets ) {
        rup_tmp4sc_log_debug("[Shortcode] No tickets found for order_id: $order_id, email: $email, event: $event_filter");
        return ob_get_clean() . '<p style="color: red;">❌ No tickets found.</p>';
    }

    rup_tmp4sc_log_debug("[Shortcode] Found " . count($tickets) . " ticket(s) for event: $event_filter");

    $events = json_decode( get_option( 'ticket_events', '[]' ), true );
    rup_tmp4sc_log_debug("[Shortcode] Loaded events: " . json_encode($events));
    $download_links = [];

    foreach ( $tickets as $ticket ) {
        rup_tmp4sc_log_debug("[Shortcode] Processing ticket: " . json_encode($ticket));
        foreach ( $events as $event ) {
            if ( $event['event_name'] === $ticket->event_name ) {
                $file_name = str_replace( '{NUMBER}', $ticket->ticket_number, $event['naming_pattern'] );
                $download_url = add_query_arg( [
                    'ticket_download' => '1',
                    'order_id'        => urlencode( $order_id ),
                    'email'           => urlencode( $email ),
                    'event'           => urlencode( $event['event_name'] ),
                    'ticket'          => urlencode( $file_name )
                ], site_url() );
                rup_tmp4sc_log_debug("[Shortcode] For event '{$event['event_name']}', ticket #{$ticket->ticket_number} -> file name: $file_name, download URL: $download_url");
                $download_links[] = "<li>🎟️ <a href='" . esc_url( $download_url ) . "' class='button'>Download Ticket #{$ticket->ticket_number}</a></li>";
            }
        }
    }

    if ( empty( $download_links ) ) {
        rup_tmp4sc_log_debug("[Shortcode] No download links generated for order_id: $order_id, email: $email, event: $event_filter");
        return ob_get_clean() . '<p style="color: red;">❌ Ticket files could not be found.</p>';
    }

    $output = '<h2>Your Tickets</h2><ul>' . implode( '', $download_links ) . '</ul>';
    rup_tmp4sc_log_debug("=== [Shortcode] Finished processing ticket download shortcode ===");

    return ob_get_clean() . $output;
}
add_shortcode( 'ticket_auto_download', 'rup_tmp4sc_ticket_auto_download_shortcode' );


/* --------------------------------------------------
   HANDLE FILE DOWNLOAD WHEN LINK IS CLICKED
-------------------------------------------------- */
function rup_tmp4sc_ticket_manager_handle_download() {
    // Instead of checking $_GET, use get_query_var.
    if ( get_query_var('ticket_download') !== '1' ) {
        return;
    }

    rup_tmp4sc_log_debug("=== [Download Handler] Download handler triggered ===");

    // Start output buffering.
    ob_start();
    rup_tmp4sc_log_debug("[Download Handler] Output buffering started.");

    global $wpdb;

    $order_id    = isset( $_GET['order_id'] ) ? sanitize_text_field( $_GET['order_id'] ) : '';
    $email       = isset( $_GET['email'] ) ? sanitize_email( $_GET['email'] ) : '';
    $ticket_file = isset( $_GET['ticket'] ) ? basename( $_GET['ticket'] ) : '';
    $event_param = isset( $_GET['event'] ) ? sanitize_text_field( $_GET['event'] ) : '';

    rup_tmp4sc_log_debug("[Download Handler] Received parameters: order_id='$order_id', email='$email', ticket_file='$ticket_file', event='$event_param'");

    if ( ! $order_id || ! $email || ! $ticket_file ) {
        rup_tmp4sc_log_debug("[Download Handler] Invalid request: Missing required parameters.");
        ob_end_clean();
        die( '❌ Invalid request.' );
    }

    $query  = "
        SELECT event_name 
        FROM {$wpdb->prefix}event_tickets 
        WHERE order_id = %s AND customer_email = %s
    ";
    $params = [ $order_id, $email ];
    if ( ! empty( $event_param ) ) {
        $query   .= " AND event_name = %s";
        $params[] = $event_param;
    }

    rup_tmp4sc_log_debug("[Download Handler] Executing query: $query with parameters: " . json_encode($params));
    $ticket = $wpdb->get_row( $wpdb->prepare( $query, $params ) );

    if ( ! $ticket ) {
        rup_tmp4sc_log_debug("[Download Handler] Unauthorized access or no matching ticket found for order_id: $order_id, email: $email, event: $event_param");
        ob_end_clean();
        die( '❌ Unauthorized access.' );
    }

    rup_tmp4sc_log_debug("[Download Handler] Ticket found for event: " . $ticket->event_name);

    $events = json_decode( get_option( 'ticket_events', '[]' ), true );
    rup_tmp4sc_log_debug("[Download Handler] Loaded events: " . json_encode($events));

    foreach ( $events as $event ) {
        if ( $event['event_name'] === $ticket->event_name ) {
            $file_path = rtrim( $event['ticket_path'], '/' ) . '/' . $ticket_file;
            rup_tmp4sc_log_debug("[Download Handler] Constructed file path: $file_path");
            if ( ! file_exists( $file_path ) ) {
                rup_tmp4sc_log_debug("[Download Handler] File not found at path: $file_path");
                ob_end_clean();
                die( '❌ Ticket file not found.' );
            }
            rup_tmp4sc_log_debug("[Download Handler] File exists. Preparing to send file: $file_path");
            ob_end_clean(); // Clear buffered output.
            header( 'Content-Type: application/pdf' );
            header( 'Content-Disposition: attachment; filename="' . basename( $file_path ) . '"' );
            header( 'Content-Length: ' . filesize( $file_path ) );
            rup_tmp4sc_log_debug("[Download Handler] Headers sent. Reading file now.");
            readfile( $file_path );
            rup_tmp4sc_log_debug("[Download Handler] File read completed. Exiting.");
            exit;
        }
    }

    rup_tmp4sc_log_debug("[Download Handler] No matching event found for ticket event: " . $ticket->event_name);
    ob_end_clean();
    die( '❌ Access denied.' );
}
add_action( 'template_redirect', 'rup_tmp4sc_ticket_manager_handle_download', 0 );


/* --------------------------------------------------
   DATABASE FUNCTIONS
-------------------------------------------------- */
function rup_tmp4sc_create_event_tickets_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'event_tickets';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        event_name VARCHAR(255) NOT NULL,
        ticket_number INT NOT NULL,
        assigned TINYINT(1) NOT NULL DEFAULT 0,
        customer_email VARCHAR(255) NULL,
        order_id VARCHAR(100) NULL,
        buyer_name VARCHAR(255) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY event_ticket (event_name, ticket_number)
    ) $charset_collate;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}

function rup_tmp4sc_delete_event_tickets_table() {
    global $wpdb;
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}event_tickets" );
}

function rup_tmp4sc_populate_event_tickets( $event_name ) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'event_tickets';
    $events = json_decode( get_option( 'ticket_events', '[]' ), true );
    foreach ( $events as $event ) {
        if ( $event['event_name'] === $event_name ) {
            for ( $i = 1; $i <= 101; $i++ ) {
                $existing_ticket = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table_name WHERE event_name = %s AND ticket_number = %d", $event_name, $i ) );
                if ( ! $existing_ticket ) {
                    $wpdb->insert( $table_name, [
                        'event_name'    => $event_name,
                        'ticket_number' => $i,
                        'assigned'      => 0,
                        'customer_email'=> null,
                        'order_id'      => null,
                        'buyer_name'    => null
                    ] );
                    rup_tmp4sc_log_debug( "Inserted ticket #{$i} for event {$event_name}" );
                }
            }
        }
    }
}



/* --------------------------------------------------
   SDK Inclusion - V1.12
-------------------------------------------------- */

function rup_tmp4sc_initialize_licensing() {

$client_path = plugin_dir_path( __FILE__ ) . 'inc/Client.php';

    if ( ! file_exists( $client_path ) ) {
        error_log( 'Client.php not found at: ' . $client_path );
        return;
    }

    if ( ! class_exists( 'RUPTMP4SC\Licensing\Client' ) ) {
        require_once $client_path;
    }

    // Initialize the SureCart Licensing Client
    $client = new \RUPTMP4SC\Licensing\Client( 'Ticket Manager Pro', 'pt_usTzCchJQpYtKWCoRCusHS5P', __FILE__ );

    // Optionally set your plugin's textdomain for internationalization
    $client->set_textdomain( 'ticket-manager-pro-textdomain' );

    // Add the license management settings page
    $client->settings()->add_page(
        [
            'type'        => 'submenu',
            'parent_slug' => 'ticket-manager', // Submenu under your plugin menu
            'page_title'  => 'Manage License',
            'menu_title'  => 'Manage License',
            'capability'  => 'manage_options',
            'menu_slug'   => 'ruptmp4sc_license_settings',
        ]
    );
}
add_action( 'init', 'rup_tmp4sc_initialize_licensing' );



/* --------------------------------------------------
   CONDITIONAL FILTER FOR SURECART CUSTOMER DASHBOARD
-------------------------------------------------- */
function rup_tmp4sc_maybe_enable_tabbed_block() {
    $activate_tabbed_block = get_option( 'activate_tabbed_block', 0 );
    if ( $activate_tabbed_block ) {
        add_filter(
            'block_type_metadata',
            function( $metadata ) {
                if ( 'surecart/customer-dashboard' === $metadata['name'] ) {
                    $metadata['supports']['inserter'] = true;
                }
                return $metadata;
            }
        );
    }
}
add_action( 'plugins_loaded', 'rup_tmp4sc_maybe_enable_tabbed_block' );
 
/**
 * Shortcode: [available_ticket_downloads]
 *
 * Displays a responsive, multi-column list of the user's event tickets.
 * Shows a limited view by default (3 events or 10 tickets, whichever is first),
 * plus a "View All" or "View Less" toggle link at the top right.
 */
function rup_tmp4sc_available_ticket_downloads_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'date_format'   => 'Y-m-d',
        'wrapper_class' => 'rup-ticket-downloads',
        'event_class'   => 'rup-event-group',
    ), $atts, 'available_ticket_downloads' );

    $max_events  = 3;
    $max_tickets = 10;
    $view_all = isset( $_GET['view_all'] ) && '1' === $_GET['view_all'];

    if ( ! is_user_logged_in() ) {
        return '<p>Please log in to view your tickets.</p>';
    }

    global $wpdb;
    $current_user = wp_get_current_user();
    $user_email   = $current_user->user_email;
    $today        = date('Y-m-d');
    $all_events = json_decode( get_option( 'ticket_events', '[]' ), true );
    if ( ! is_array( $all_events ) ) {
        return '<p>No event information found.</p>';
    }

    $user_events = array();

    foreach ( $all_events as $event ) {
        if ( isset( $event['end_date'] ) && $event['end_date'] < $today ) {
            continue;
        }
        $tickets = $wpdb->get_results( $wpdb->prepare( "
            SELECT ticket_number, order_id, created_at 
            FROM {$wpdb->prefix}event_tickets 
            WHERE customer_email = %s 
              AND event_name = %s 
              AND assigned = 1
        ", $user_email, $event['event_name'] ) );

        if ( ! empty( $tickets ) ) {
            $user_events[] = array(
                'event_name'     => $event['event_name'],
                'start_date'     => $event['start_date'],
                'ticket_path'    => $event['ticket_path'],
                'naming_pattern' => $event['naming_pattern'],
                'tickets'        => $tickets,
            );
        }
    }

    if ( empty( $user_events ) ) {
        return '<p>No tickets available for download.</p>';
    }

    usort( $user_events, function ( $a, $b ) {
        return strcmp( $a['start_date'], $b['start_date'] );
    } );

    $total_events = count( $user_events );
    $total_tickets = 0;
    foreach ( $user_events as $event ) {
        $total_tickets += count( $event['tickets'] );
    }

    $output = '<style>
        .' . esc_attr( $atts['wrapper_class'] ) . ' {
            font-family: inherit;
            background: #f9f9f9;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .' . esc_attr( $atts['wrapper_class'] ) . ' .tickets-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1em;
        }
        .' . esc_attr( $atts['wrapper_class'] ) . ' .tickets-header h2 {
            margin: 0;
            font-size: 1.2em;
        }
        .' . esc_attr( $atts['wrapper_class'] ) . ' .tickets-toggle-link {
            color: #0073aa;
            text-decoration: underline;
            font-size: 0.9em;
            cursor: pointer;
        }
        .' . esc_attr( $atts['wrapper_class'] ) . ' .tickets-toggle-link:hover {
            color: #006799;
        }
        .' . esc_attr( $atts['wrapper_class'] ) . ' .event-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1em;
        }
        .' . esc_attr( $atts['event_class'] ) . ' {
            background: #fff;
            padding: 10px;
            border: 1px solid #e5e5e5;
            border-radius: 4px;
        }
        .' . esc_attr( $atts['event_class'] ) . ' .event-info {
            margin-bottom: 0.5em;
        }
        .' . esc_attr( $atts['event_class'] ) . ' .event-info span {
            display: inline-block;
            margin-right: 15px;
        }
        .' . esc_attr( $atts['event_class'] ) . ' ul {
            list-style: none;
            padding-left: 0;
            margin: 0;
        }
        .ticket-item {
            margin-bottom: 0.75em;
        }
        .ticket-item .ticket-number {
            display: inline-block;
            width: 50px;
            text-align: right;
            margin-right: 5px;
            font-family: monospace;
        }
        .ticket-item a.button {
            background-color: #0073aa;
            border: none;
            color: #fff;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 3px;
        }
        .ticket-item a.button:hover {
            background-color: #006799;
        }
    </style>';

    $output .= '<div class="' . esc_attr( $atts['wrapper_class'] ) . '">';
    $output .= '<div class="tickets-header">';
    $output .= '<h2>Tickets</h2>';
    $toggle_url = add_query_arg( 'view_all', $view_all ? '0' : '1', get_permalink() );
    $toggle_text = $view_all ? 'View Less' : 'View All';
    $output .= '<a class="tickets-toggle-link" href="' . esc_url( $toggle_url ) . '">' . esc_html( $toggle_text ) . '</a>';
    $output .= '</div>';
    $output .= '<div class="event-grid">';

    if ( $view_all ) {
        foreach ( $user_events as $event ) {
            $output .= rup_tmp4sc_render_event_block_single_ticket( $event, $atts['event_class'], $atts['date_format'], $user_email );
        }
    } else {
        $events_displayed  = 0;
        $tickets_displayed = 0;
        foreach ( $user_events as $event ) {
            if ( $events_displayed >= $max_events || $tickets_displayed >= $max_tickets ) {
                break;
            }
            $remaining_ticket_slots = $max_tickets - $tickets_displayed;
            $event_tickets = $event['tickets'];
            if ( count( $event_tickets ) > $remaining_ticket_slots ) {
                $event_tickets = array_slice( $event_tickets, 0, $remaining_ticket_slots );
            }
            $truncated_event = $event;
            $truncated_event['tickets'] = $event_tickets;
            $output .= rup_tmp4sc_render_event_block_single_ticket( $truncated_event, $atts['event_class'], $atts['date_format'], $user_email );
            $tickets_displayed += count( $event_tickets );
            $events_displayed++;
            if ( $events_displayed >= $max_events || $tickets_displayed >= $max_tickets ) {
                break;
            }
        }
    }

    $output .= '</div>';
    $output .= '</div>';

    return $output;
}
add_shortcode( 'available_ticket_downloads', 'rup_tmp4sc_available_ticket_downloads_shortcode' );

/* --------------------------------------------------
   SDK HelperFuction - Plugin
-------------------------------------------------- */
function rup_tmp4sc_get_client() {
    static $client = null;

    if ( $client === null ) {
        $client = new \RUPTMP4SC\Licensing\Client( 'Ticket Manager Pro', 'pt_usTzCchJQpYtKWCoRCusHS5P', __FILE__ );
    }

    return $client;
}

/* --------------------------------------------------
   SDK HelperFuction - Activation
-------------------------------------------------- */

function rup_tmp4sc_is_activated_and_licensed() {
    $client = rup_tmp4sc_get_client();

    if ( ! $client ) {
        return false;
    }

    // Retrieve license data from the database
    $license_options = get_option( 'ticketmanagerpro_license_options', [] );
    $license_key = $license_options['sc_license_key'] ?? null;
    $activation_id = $license_options['sc_activation_id'] ?? null;

    if ( empty( $license_key ) || empty( $activation_id ) ) {
        return false;
    }

    $activation = new \RUPTMP4SC\Licensing\Activation( $client );
    $license = new \RUPTMP4SC\Licensing\License( $client );

    $is_license_valid = $license->is_valid( $license_key );

    if ( ! $is_license_valid ) {
            return false;
    }


    $activation_data = $activation->get( $activation_id );

    if ( is_wp_error( $activation_data ) ) {
        return false;
    }

    if ( empty( $activation_data ) || ! isset( $activation_data->id ) ) {
        //error_log( '[RUPTMP4SC] Activation ID not found in activation data.' );
        return false;
    }

    return true;
}


/**
 * Helper function to render a single event block for the dashboard.
 */
function rup_tmp4sc_render_event_block_single_ticket( $event, $event_class, $date_format, $user_email ) {
    $formatted_date = date( $date_format, strtotime( $event['start_date'] ) );
    $block  = '<div class="' . esc_attr( $event_class ) . '">';
    $block .= '<div class="event-info">';
    $block .= '<span><strong>Event:</strong> ' . esc_html( $event['event_name'] ) . '</span>';
    $block .= '<span><strong>Date:</strong> ' . esc_html( $formatted_date ) . '</span>';
    $block .= '</div>';
    $block .= '<strong>Tickets:</strong><ul>';
    foreach ( $event['tickets'] as $ticket ) {
        $file_name = str_replace( '{NUMBER}', $ticket->ticket_number, $event['naming_pattern'] );
        $download_url = add_query_arg( array(
            'ticket_download' => '1',
            'order_id'        => $ticket->order_id,
            'email'           => $user_email,
            'event'           => $event['event_name'],
            'ticket'          => $file_name
        ), site_url() );
        $block .= '<li class="ticket-item">';
        $block .= '<span class="ticket-number">#' . esc_html( $ticket->ticket_number ) . '</span>: ';
        $block .= '<a href="' . esc_url( $download_url ) . '" class="button" target="_blank">Download</a>';
        $block .= '</li>';
    }
    $block .= '</ul></div>';
    return $block;
}