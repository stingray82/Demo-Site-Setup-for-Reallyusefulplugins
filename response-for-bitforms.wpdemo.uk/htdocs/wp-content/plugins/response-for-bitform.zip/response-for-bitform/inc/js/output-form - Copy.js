console.log("ResponseFBF Script Initialized - Final Version");

// Check if script has already been initialized
if (!window.responsefbfInitialized) {
    window.responsefbfInitialized = true;

    console.log("ResponseFBF Script Fully Initialized");

    document.addEventListener("DOMContentLoaded", async () => {
        console.log("Initializing ResponseFBF");

        try {
            // Fetch session ID from the REST API
            const response = await fetch(`${responsefbfData.restBase}session-id`);
            const data = await response.json();

            if (data?.session_id) {
                console.log("Session ID generated:", data.session_id);

                // Add session ID as a hidden field to all forms
                document.querySelectorAll(".bit-form").forEach((form) => {
                    if (!form.querySelector("input[name='session_id']")) {
                        const hiddenField = document.createElement("input");
                        hiddenField.type = "hidden";
                        hiddenField.name = "session_id";
                        hiddenField.value = data.session_id;
                        form.appendChild(hiddenField);
                    }
                });
            } else {
                console.error("Failed to fetch session ID:", data);
            }
        } catch (error) {
            console.error("Error fetching session ID:", error);
        }

        console.log("ResponseFBF Script Initialization Complete");

        // Collect all forms on the page
        const forms = document.querySelectorAll("[id^='form-']");
        console.log(`Detected ${forms.length} forms on the page.`);

        console.log("Webhook-enabled forms (responsefbfData.webhookForms):", responsefbfData.webhookForms);

        // Add event listeners to detected forms
        forms.forEach((formElement) => {
            const formId = formElement.id.replace("form-", ""); // Extract the form ID
            const bitformsIdInput = formElement.querySelector('input[name="bitforms_id"]');

            if (!bitformsIdInput) {
                console.warn(`No BitForms ID input found in form with ID ${formId}. Skipping.`);
                return;
            }

            // Normalize the BitForms ID
            const rawBitformsId = bitformsIdInput.value;
            const normalizedBitformsId = rawBitformsId.replace(/^bitforms_/, "");

            console.log(`Form detected:`);
            console.log(`  - Raw BitForms ID: ${rawBitformsId}`);
            console.log(`  - Normalized BitForms ID: ${normalizedBitformsId}`);

            // Check if the form is webhook-enabled
            if (!responsefbfData.webhookForms.includes(normalizedBitformsId)) {
                console.log(
                    `Form with normalized BitForms ID ${normalizedBitformsId} is not configured for webhooks. Ignoring.`
                );
                return;
            }

            console.log(`Adding listener for webhook-enabled form with normalized ID: ${normalizedBitformsId}`);

            // Add listener for successful submission
            formElement.addEventListener("bf-form-submit-success", async (event) => {
                const { detail: { formId, entryId, formData } } = event;

                console.log(`Form submission successful! Form ID: ${formId}, Entry ID: ${entryId}`);
                console.log("Submitted Form Data:", formData);

                const sessionId = formElement.querySelector("input[name='session_id']")?.value;

                if (!sessionId) {
                    console.error("Session ID is missing from the form.");
                    return;
                }

                console.log("Session ID detected:", sessionId);

                // Start polling for response
                await pollForResponse(formElement, normalizedBitformsId, sessionId);
            });
        });
    });
} else {
    console.log("ResponseFBF Script already initialized. Skipping re-initialization.");
}

// Polling function to check for response
async function pollForResponse(formElement, formId, sessionId) {
    console.log("Starting polling for Form ID:", formId, "Session ID:", sessionId);

    let attemptCount = 0;
    const retryInterval = 2000; // Retry every 2 seconds
    const maxAttempts = 40; // Allow up to 40 retries

    while (attemptCount < maxAttempts) {
        console.log(`Polling attempt #${attemptCount + 1}...`);

        try {
            const response = await fetch(
                `${responsefbfData.restBase}receive-response?session_id=${sessionId}&form_id=${formId}`
            );
            const data = await response.json();

            if (data?.html) {
                console.log("Response received:", data.html);
                displayResponse(formElement, data.html);
                return; // Stop polling once we have the response
            } else {
                console.log("Response not ready. Retrying...");
            }
        } catch (error) {
            console.error("Error while polling for response:", error);
        }

        attemptCount++;
        if (attemptCount < maxAttempts) {
            await new Promise((resolve) => setTimeout(resolve, retryInterval));
        } else {
            console.warn("Max polling attempts reached. No response received.");
            displayFailureMessage(formElement, "No response received. Please try again later.");
        }
    }
}

// Function to display the received response
function displayResponse(formElement, htmlContent) {
    console.log("Displaying response...");

    let responseContainer = formElement.querySelector(".responsefbf-response");
    if (!responseContainer) {
        responseContainer = document.createElement("div");
        responseContainer.classList.add("responsefbf-response");
        responseContainer.style.marginTop = "20px";
        formElement.appendChild(responseContainer);
    }

    responseContainer.innerHTML = htmlContent || "No response received.";
}

// Function to display a failure message
function displayFailureMessage(formElement, message) {
    console.error(message);

    let errorContainer = formElement.querySelector(".responsefbf-error-message");
    if (!errorContainer) {
        errorContainer = document.createElement("div");
        errorContainer.classList.add("responsefbf-error-message");
        formElement.appendChild(errorContainer);
    }

    errorContainer.textContent = message;
}
