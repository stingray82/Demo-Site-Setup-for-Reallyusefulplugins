console.log("ResponseFBF Script Initialized");

if (typeof responsefbfData !== "undefined") {
    //console.log("Initializing ResponseFBF...");
    //console.log("responsefbfData loaded:", responsefbfData);

    // Collect all forms on the page
    const forms = document.querySelectorAll("[id^='form-']");
    //console.log(`Detected ${forms.length} forms on the page.`);

    // Log webhook-enabled forms
    //console.log("Webhook-enabled forms (responsefbfData.webhookForms):", responsefbfData.webhookForms);

    // Add event listeners to all webhook-enabled forms
    forms.forEach((formElement) => {
        const formId = formElement.id.replace("form-", ""); // Extract the form ID
        const bitformsIdInput = formElement.querySelector('input[name="bitforms_id"]');

        if (!bitformsIdInput) {
            console.warn(`No BitForms ID input found in form with ID ${formId}. Skipping.`);
            return;
        }

        // Normalize the BitForms ID by removing the "bitforms_" prefix
        const rawBitformsId = bitformsIdInput.value;
        const normalizedBitformsId = rawBitformsId.replace(/^bitforms_/, "");

        //console.log(`Form detected:`);
        //console.log(`  - Raw BitForms ID: ${rawBitformsId}`);
        //console.log(`  - Normalized BitForms ID: ${normalizedBitformsId}`);

        // Check if this form matches the webhook-enabled forms
        if (!responsefbfData.webhookForms.includes(normalizedBitformsId)) {
            //console.log(`Form with normalized BitForms ID ${normalizedBitformsId} is not configured for webhooks. Ignoring.`);
            return;
        }

        //console.log(`Adding listener for webhook-enabled form with normalized ID: ${normalizedBitformsId}`);

        // Add listener for form submission
        formElement.addEventListener("bf-form-submit-success", async (event) => {
            const { detail: { entryId } } = event;

            //console.log(`Form submission detected! Entry ID: ${entryId}`);

            if (!entryId) {
                console.error("Entry ID is missing. Cannot proceed.");
                return;
            }

            //console.log("Fetching session ID for Entry ID:", entryId);

            // Hide bf-form-msg-wrp elements for targeted forms
            const messageWrapper = formElement.querySelector(".bf-form-msg-wrp");
            if (messageWrapper) {
                messageWrapper.style.display = "none"; // Explicitly hide the success message
            }

            // Add a "please wait" message below the form but outside its DOM
            showLoadingMessage(formElement);

            // Fetch the session ID using the REST API
            try {
                const response = await fetch(`${responsefbfData.restBase}session-id?entry_id=${entryId}`);
                const data = await response.json();

                if (data?.session_id) {
                    //console.log(`Session ID received for Entry ID ${entryId}: ${data.session_id}`);
                    pollForResponse(formElement, data.session_id, normalizedBitformsId);
                } else {
                    console.error("Failed to fetch session ID:", data);
                }
            } catch (error) {
                console.error("Error fetching session ID:", error);
            }
        });
    });

    //console.log("ResponseFBF Script Fully Initialized");
} else {
    console.error("responsefbfData is not defined. Ensure wp_localize_script is configured properly.");
}

// Function to display a "please wait" message
function showLoadingMessage(formElement) {
    const parentElement = formElement.parentNode;

    // Check if a loading message container already exists
    let loadingContainer = parentElement.querySelector(".responsefbf-loading");
    if (!loadingContainer) {
        // Create the loading message container
        loadingContainer = document.createElement("div");
        loadingContainer.classList.add("responsefbf-loading");

        // Style the loading container
        loadingContainer.style.marginTop = "20px";
        loadingContainer.style.padding = "15px";
        loadingContainer.style.border = "1px solid #ddd";
        loadingContainer.style.borderRadius = "8px";
        loadingContainer.style.backgroundColor = "#f9f9f9";
        loadingContainer.style.maxWidth = "100%";
        loadingContainer.style.fontStyle = "italic";
        loadingContainer.textContent = "Please wait, we are processing your submission. This may take up to a minute...";

        // Insert the loading container below the form but outside its DOM
        parentElement.insertBefore(loadingContainer, formElement.nextSibling);
    }
}

// Polling function to check for response
async function pollForResponse(formElement, sessionId, formId) {
    //console.log(`Polling for response with Session ID: ${sessionId}`);
    let attemptCount = 0;
    const retryInterval = 2000; // Retry every 2 seconds
    const maxAttempts = 30; // Allow up to 30 retries

    while (attemptCount < maxAttempts) {
        //console.log(`Polling attempt #${attemptCount + 1}`);

        try {
            const response = await fetch(
                `${responsefbfData.restBase}receive-response?session_id=${sessionId}&form_id=${formId}`
            );
            const data = await response.json();

            if (data?.status === "success" && data.html) {
                //console.log("Response received:", data);

                // Check if there's any valid content to display
                if (
                    data.html.body_display ||
                    data.html.image?.html ||
                    data.html.pdf?.html ||
                    data.html.link
                ) {
                    displayResponse(formElement, data.html);
                    return; // Stop polling once we have valid data to display
                } else {
                    //console.log("Response content not ready. Retrying...");
                }
            } else {
                //console.log("Response not ready. Retrying...");
            }
        } catch (error) {
            console.error("Error fetching response:", error);
        }

        attemptCount++;
        if (attemptCount < maxAttempts) {
            await new Promise((resolve) => setTimeout(resolve, retryInterval));
        } else {
            console.warn("Max attempts reached. No response received.");
            break;
        }
    }

    // Display a failure message if polling fails
    displayFailureMessage(formElement, "Failed to retrieve a response. Please try again later.");
}


// Display our Response
// Function to display the response below the form but outside the form's DOM
function displayResponse(formElement, data) {
    const parentElement = formElement.parentNode;

    // Remove the loading message
    const loadingContainer = parentElement.querySelector(".responsefbf-loading");
    if (loadingContainer) {
        loadingContainer.remove();
    }

    // Check if a response container already exists
    let responseContainer = parentElement.querySelector(".responsefbf-response");
    if (!responseContainer) {
        responseContainer = document.createElement("div");
        responseContainer.classList.add("responsefbf-response");
        responseContainer.style.marginTop = "20px";
        responseContainer.style.padding = "15px";
        responseContainer.style.border = "1px solid #ddd";
        responseContainer.style.borderRadius = "8px";
        responseContainer.style.backgroundColor = "#f9f9f9";
        responseContainer.style.maxWidth = "100%";
        responseContainer.style.textAlign = "center";
        parentElement.insertBefore(responseContainer, formElement.nextSibling);
    }

    responseContainer.innerHTML = ""; // Clear existing content

    // Handle body content if available
    if (data.body_display && data.body) {
        const bodyContent = document.createElement("div");
        bodyContent.classList.add("response-body");
        bodyContent.style.marginBottom = "10px";
        bodyContent.innerHTML = data.body; // Insert the body content
        responseContainer.appendChild(bodyContent);
    }

    // Handle link response
    if (data.link) {
        const linkContent = document.createElement("div");
        linkContent.classList.add("response-link");
        linkContent.style.marginBottom = "10px";
        const linkText = data.link.text || "Visit Link";
        linkContent.innerHTML = `<a href="${data.link.url}" target="_blank">${linkText}</a>`;
        responseContainer.appendChild(linkContent);
    }

    // Handle image response
    if (data.image?.html) {
        const imageContent = document.createElement("div");
        imageContent.classList.add("response-image");
        imageContent.style.marginBottom = "10px";
        imageContent.innerHTML = data.image.html; // Insert the image HTML
        responseContainer.appendChild(imageContent);
    }

    // Handle PDF response
    if (data.pdf?.html) {
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = data.pdf.html;

        // Extract the actual PDF URL from the anchor tag
        const pdfLink = tempDiv.querySelector("a")?.href;
        if (pdfLink) {
            const pdfContainer = document.createElement("div");
            pdfContainer.classList.add("response-pdf");
            pdfContainer.style.marginBottom = "10px";

            const iframe = document.createElement("iframe");
            iframe.src = pdfLink; // Use the direct PDF URL
            iframe.width = "100%";
            iframe.height = "500px";
            iframe.style.border = "none";

            pdfContainer.appendChild(iframe);
            responseContainer.appendChild(pdfContainer);
        }
    }

   // Handle copy button if enabled
let copyButtonContainer = parentElement.querySelector(".responsefbf-copy");
if (!copyButtonContainer && data.copy_button) {
    copyButtonContainer = document.createElement("div");
    copyButtonContainer.classList.add("responsefbf-copy");
    copyButtonContainer.style.marginTop = "15px";
    copyButtonContainer.style.textAlign = "center";

    const copyButton = document.createElement("button");
    copyButton.classList.add("copy-button");
    copyButton.style.padding = "10px 20px";
    copyButton.style.border = "1px solid #ddd";
    copyButton.style.borderRadius = "5px";
    copyButton.style.backgroundColor = "#f0f0f0";
    copyButton.style.cursor = "pointer";
    copyButton.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 1H4C2.9 1 2 1.9 2 3V17H4V3H16V1ZM19 5H8C6.9 5 6 5.9 6 7V21C6 22.1 6.9 23 8 23H19C20.1 23 21 22.1 21 21V7C21 5.9 20.1 5 19 5ZM19 21H8V7H19V21Z" fill="#000000"/>
        </svg> Copy`;

    copyButton.addEventListener("click", () => {
        // Check for the appropriate content to copy
        let contentToCopy = null;

        if (data.body_display && data.body) {
            // Copy the body text if available
            contentToCopy = data.body;
        } else if (data.link?.url) {
            // Copy the link URL if available
            contentToCopy = data.link.url;
        } else if (data.image?.html) {
            // Extract and copy the image URL
            const tempDiv = document.createElement("div");
            tempDiv.innerHTML = data.image.html;
            contentToCopy = tempDiv.querySelector("img")?.src || null;
        } else if (data.pdf?.html) {
            // Extract and copy the PDF URL
            const tempDiv = document.createElement("div");
            tempDiv.innerHTML = data.pdf.html;
            contentToCopy = tempDiv.querySelector("a")?.href || null;
        }

        // Copy the content if it exists
        if (contentToCopy) {
            navigator.clipboard.writeText(contentToCopy).then(() => {
                copyButton.innerHTML = "Copied!";
                setTimeout(() => {
                    copyButton.innerHTML = `
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M16 1H4C2.9 1 2 1.9 2 3V17H4V3H16V1ZM19 5H8C6.9 5 6 5.9 6 7V21C6 22.1 6.9 23 8 23H19C20.1 23 21 22.1 21 21V7C21 5.9 20.1 5 19 5ZM19 21H8V7H19V21Z" fill="#000000"/>
                        </svg> Copy`;
                }, 1500);
            });
        } else {
            alert("No content available to copy.");
        }
    });

    copyButtonContainer.appendChild(copyButton);
    parentElement.insertBefore(copyButtonContainer, responseContainer.nextSibling);
}




    responseContainer.scrollIntoView({ behavior: "smooth" });
}



// Function to display a failure message
function displayFailureMessage(formElement, message) {
    const parentElement = formElement.parentNode;

    // Remove the loading message
    const loadingContainer = parentElement.querySelector(".responsefbf-loading");
    if (loadingContainer) {
        loadingContainer.remove();
    }

    // Create or update the error message container
    let errorContainer = parentElement.querySelector(".polling-error-message");
    if (!errorContainer) {
        errorContainer = document.createElement("div");
        errorContainer.className = "polling-error-message";
        errorContainer.style.marginTop = "20px";
        errorContainer.style.padding = "15px";
        errorContainer.style.border = "1px solid #f44336";
        errorContainer.style.borderRadius = "8px";
        errorContainer.style.backgroundColor = "#ffebee";
        errorContainer.style.maxWidth = "100%";

        parentElement.insertBefore(errorContainer, formElement.nextSibling);
    }

    errorContainer.textContent = message;
}
