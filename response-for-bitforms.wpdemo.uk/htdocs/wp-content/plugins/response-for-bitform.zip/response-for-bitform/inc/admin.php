<?php

// This file handles the admin area and the options for responsefbf
// Exit if accessed directly.
defined('ABSPATH') || exit;

// Save version 14
function responsefbf_admin_menu() {
    add_menu_page(
        'Response for Bit Forms Settings',  // Page title
        'Response 4 BF',                   // Menu title (appears in the admin menu)
        'manage_options',                  // Capability
        'responsefbf_settings',            // Menu slug
        'render_responsefbf_admin_page',   // Callback function to render the page
        'dashicons-feedback',              // Icon
    );
}
add_action('admin_menu', 'responsefbf_admin_menu', 99);

// Render the admin page for managing form-webhook pairs
function render_responsefbf_admin_page() {
    if ( ! responsefbf_is_activated_and_licensed() ) {
        echo '<div class="wrap">';
        echo '<h1>Plugin Activation Required</h1>';
        echo '<p>Please activate your license to access these settings.</p>';
        echo '</div>';
        return; // Prevent further rendering
    }
    global $wpdb;
    // Handle form submission for saving new form-webhook pairs
    if (isset($_POST['responsefbf_nonce']) && wp_verify_nonce($_POST['responsefbf_nonce'], 'save_responsefbf_settings')) {
        // Get and sanitize form data
        $form_id = sanitize_text_field($_POST['form_id']);
        $webhook_url = esc_url_raw($_POST['webhook_url']);
        $form_webhooks = get_option('responsefbf_webhooks', []);

        // Save new form ID and webhook URL pairs
        if (!empty($form_id) && !empty($webhook_url)) {
            $form_webhooks[$form_id] = $webhook_url;
            update_option('responsefbf_webhooks', $form_webhooks);
            echo '<div class="updated"><p>Webhook settings saved successfully.</p></div>';
        }
    }

    // Handle deletion of form-webhook pairs
    if (isset($_GET['delete_form_id'])) {
        $form_webhooks = get_option('responsefbf_webhooks', []);
        $delete_form_id = sanitize_text_field($_GET['delete_form_id']);
        unset($form_webhooks[$delete_form_id]);
        update_option('responsefbf_webhooks', $form_webhooks);
        echo '<div class="updated"><p>Form Webhook deleted successfully.</p></div>';
    }

    // Retrieve saved form-webhook pairs
    $form_webhooks = get_option('responsefbf_webhooks', []);

    global $wpdb;

    // Fetch all forms from wp_bitforms_form table
    $forms_table = $wpdb->prefix . 'bitforms_form';
    $forms = $wpdb->get_results(
    "SELECT id, form_name FROM $forms_table WHERE status = 1", // Assuming 1 indicates 'active'
    ARRAY_A
    );
    // Output the admin page HTML
    ?>
    <div class="wrap">
        <h1>Response For Bit Forms Settings</h1>
        
        <!-- Form to add new webhook mappings -->
        <form method="post">
            <?php wp_nonce_field('save_responsefbf_settings', 'responsefbf_nonce'); ?>
            <h2>Add New Form Webhook</h2>
            <p>Pair a form with a webhook URL. The plugin will handle responses automatically.</p>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="form_id">Form</label></th>
                    <td>
                        <select id="form_id" name="form_id">
                            <?php if (!empty($forms)): ?>
                                <?php foreach ($forms as $form): ?>
                                    <option value="<?php echo esc_attr($form['id']); ?>">
                                        <?php echo esc_html($form['form_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option value="">No forms available</option>
                            <?php endif; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="webhook_url">Webhook URL</label></th>
                    <td><input type="url" id="webhook_url" name="webhook_url" /></td>
                </tr>
            </table>

            <p class="submit"><button type="submit" class="button button-primary">Save Settings</button></p>
        </form>

        <!-- List existing form-webhook mappings -->
        <h2>Existing Form Webhooks</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Form ID</th>
                    <th>Form Name</th>
                    <th>Webhook URL</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($form_webhooks)): ?>
                    <?php foreach ($form_webhooks as $form_id => $webhook_url): ?>
                        <tr>
                            <td><?php echo esc_html($form_id); ?></td>
                            <td>
                                <?php 
                                $form_name = array_search($form_id, array_column($forms, 'id')) !== false ? $forms[array_search($form_id, array_column($forms, 'id'))]['form_name'] : 'Unknown Form'; 
                                echo esc_html($form_name); 
                                ?>
                            </td>
                            <td><?php echo esc_url($webhook_url); ?></td>
                            <td>
                                <a href="<?php echo add_query_arg('delete_form_id', $form_id); ?>" class="button">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4">No webhook mappings found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}
