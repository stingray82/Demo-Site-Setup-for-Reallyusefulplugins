<?php
// Exit if accessed directly.
defined('ABSPATH') || exit;
/*
/**
 * Register REST API routes.
 */
add_action('rest_api_init', function () {
    // Store response data
    register_rest_route('responsefbf/v1', '/bitform-response', [
        'methods' => 'POST',
        'callback' => 'responsefbf_store_bitform_response',
        'permission_callback' => '__return_true',
    ]);

    // Fetch response data
    register_rest_route('responsefbf/v1', '/receive-response', [
        'methods' => 'GET',
        'callback' => 'responsefbf_fetch_response',
        'permission_callback' => '__return_true',
    ]);
});


/**
 * Store response data from FlowMattic or webhook.
 */
function responsefbf_store_bitform_response(WP_REST_Request $request) {
    $form_id = $request->get_param('form_id');
    $session_id = $request->get_param('session_id');
    $body = $request->get_param('body');
    $body_display = $request->get_param('body_display') === 'yes';
    $link_url = $request->get_param('link_url');
    $custom_link_text = $request->get_param('custom_link_text');
    $copy_button = $request->get_param('copy_button') === 'yes';
    $image_url = $request->get_param('image_url');
    $pdf_url = $request->get_param('pdf_url');
    $has_link = $request->get_param('has_link') === 'yes';
    $has_image = $request->get_param('has_image') === 'yes';
    $has_pdf = $request->get_param('has_pdf') === 'yes';

    // Validate input
    if (!$form_id || !$session_id) {
        return new WP_REST_Response([
            'status' => 'error',
            'message' => 'Missing required parameters (form_id or session_id).',
        ], 400);
    }

    // Check if the form is enabled for responses
    $enabled_forms = get_option('responsefbf_webhooks', []);
    if (!array_key_exists($form_id, $enabled_forms)) {
        return new WP_REST_Response([
            'status' => 'error',
            'message' => 'This form is not configured for responses.',
        ], 400);
    }

    // Prepare response data
    $response_data = [
        'body' => $body_display && !empty($body) ? wp_kses_post($body) : null,
        'body_display' => $body_display,
        'link' => $has_link && $link_url ? [
            'url' => esc_url($link_url),
            'text' => esc_html($custom_link_text ?: 'Visit Link'),
        ] : null,
        'copy_button' => $copy_button,
        'image' => $has_image && $image_url ? [
            'html' => "<img src='" . esc_url($image_url) . "' alt='Response Image' />",
        ] : null,
        'pdf' => $has_pdf && $pdf_url ? [
            'html' => "<a href='" . esc_url($pdf_url) . "' target='_blank'>View PDF</a>",
        ] : null,
    ];

    // Store the response in a transient
    $transient_key = "responsefbf_{$session_id}_{$form_id}";
    set_transient($transient_key, $response_data, 300); // Store for 5 minutes

    return new WP_REST_Response([
        'status' => 'success',
        'message' => 'Response captured successfully.',
    ], 200);
}





/**
 * Fetch response data for a given session ID and form ID.
 */
function responsefbf_fetch_response(WP_REST_Request $request) {
    $form_id = $request->get_param('form_id');
    $session_id = $request->get_param('session_id');

    // Validate input
    if (!$form_id || !$session_id) {
        return new WP_REST_Response([
            'status' => 'error',
            'message' => 'Missing required parameters.',
        ], 400);
    }

    // Retrieve the stored response
    $transient_key = "responsefbf_{$session_id}_{$form_id}";
    $response_data = get_transient($transient_key);

    if (!$response_data) {
        return new WP_REST_Response([
            'status' => 'error',
            'message' => 'No response found for the provided session and form ID.',
        ], 404);
    }

    return new WP_REST_Response([
        'status' => 'success',
        'html' => $response_data,
    ], 200);
}

// Submitted Forms API
add_action('rest_api_init', function () {
    register_rest_route('responsefbf/v1', '/submitted-forms', [
        'methods' => 'GET',
        'callback' => 'responsefbf_get_submitted_forms',
        'permission_callback' => '__return_true', // Allow public access
    ]);
});

/**
 * Callback to fetch submitted forms.
 *
 * @return array
 */
function responsefbf_get_submitted_forms() {
    $submitted_forms = get_transient('responsefbf_submitted_forms') ?: [];

    // Log the current state of the transient
    //error_log("Submitted forms in REST API: " . print_r($submitted_forms, true));

    return $submitted_forms;
}

/**
 * Session ID linked to transient generated in webhook-handler
 *   
 */
add_action('rest_api_init', function () {
    register_rest_route('responsefbf/v1', '/session-id', [
        'methods'  => 'GET',
        'callback' => 'responsefbf_get_session_id',
        'permission_callback' => '__return_true',
        'args'     => [
            'entry_id' => [
                'required' => true,
                'validate_callback' => function ($param) {
                    return !empty($param);
                },
            ],
        ],
    ]);
});

function responsefbf_get_session_id($request) {
    $entry_id = $request->get_param('entry_id');
    $session_id = get_transient("responsefbf_{$entry_id}");

    if ($session_id) {
        return rest_ensure_response(['session_id' => $session_id]);
    } else {
        return new WP_Error('session_not_found', 'Session ID not found or expired.', ['status' => 404]);
    }
}
