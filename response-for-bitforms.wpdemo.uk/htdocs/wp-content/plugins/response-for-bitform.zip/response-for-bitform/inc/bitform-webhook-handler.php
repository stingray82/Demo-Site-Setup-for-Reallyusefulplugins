
<?php
// Exit if accessed directly.
defined('ABSPATH') || exit;

require_once plugin_dir_path(__FILE__) . 'toolbox.php';

/**
 * Trigger webhook on Bit Form submission success.
 *
 * @param int $formId ID of the submitted form.
 * @param int $entryId ID of the form entry.
 * @param array $formData Submitted form data.
 */
function responsefbf_trigger_webhook_on_bitform_submission($formId, $entryId, $formData) {
    //error_log('BitForm submission detected.');

    // Ensure the form ID is valid
    if ($formId) {
        $form_webhooks = get_option('responsefbf_webhooks', []);
        $webhook_url = $form_webhooks[$formId] ?? null;

        if ($webhook_url) {
            //error_log("Form ID $formId matched with webhook URL: $webhook_url");

// Generate a unique session ID
$session_id = uniqid('responsefbf_', true);
//error_log("Generated Session ID: $session_id for Entry ID: $entryId");

// Prepare data to send to the webhook
$callback_url = rest_url('/responsefbf/v1/bitform-response');
$data_to_send = [
    'session_id'   => $session_id,
    'form_id'      => $formId,
    'entry_id'     => $entryId,
    'form_data'    => $formData,
    'callback_url' => $callback_url,
];

// Save session ID as a transient tied to the entry ID
$transient_key = "responsefbf_{$entryId}";
set_transient($transient_key, $session_id, MINUTE_IN_SECONDS * 15);
//error_log("Saved transient: $transient_key with Session ID: $session_id");

// Send data to the webhook URL
$response = responsefbf_send_data_to_webhook($webhook_url, $data_to_send);

// Log response details
if (is_wp_error($response)) {
    //error_log('Error in webhook response: ' . $response->get_error_message());
} else {
    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = wp_remote_retrieve_body($response);
    //error_log("Webhook response: HTTP {$response_code} - Body: {$response_body}");
}

        } else {
            //error_log("No webhook URL configured for Form ID: $formId.");
        }
    } else {
        //error_log("Invalid Form ID submitted.");
    }
}


/**
 * Mark a form as submitted by adding it to the transient.
 *
 * @param int $formId The ID of the submitted form.
 * @param string $sessionId The unique session ID for the submission.
 */
function responsefbf_mark_form_submitted($formId, $sessionId) {
    $submitted_forms = get_transient('responsefbf_submitted_forms') ?: [];
    
    // Log current state of submitted forms
    //error_log("Before update, submitted forms: " . print_r($submitted_forms, true));

    // Add the new submission
    $submitted_forms[] = ['form_id' => $formId, 'session_id' => $sessionId];
    set_transient('responsefbf_submitted_forms', $submitted_forms, MINUTE_IN_SECONDS * 15);

    // Log after updating the transient
    //error_log("After update, submitted forms: " . print_r($submitted_forms, true));
}


/**
 * Send data to a webhook.
 *
 * @param string $url Webhook URL.
 * @param array $data Data to send to the webhook.
 * @return array|WP_Error Response from the webhook request.
 */
function responsefbf_send_data_to_webhook($url, $data) {
    // Check if the plugin is licensed and activated
    if (!responsefbf_is_activated_and_licensed()) {
        error_log("License not active. Data not sent to webhook at URL: $url");
        return [
            'error'   => true,
            'message' => 'Please activate your license to use this feature.',
        ];
    }

    // Send the data to the webhook
    $response = wp_remote_post($url, [
        'body'    => json_encode($data),
        'headers' => ['Content-Type' => 'application/json'],
    ]);

    return $response;
}

// Register the webhook trigger for BitForm submissions
add_action('bitform_submit_success', 'responsefbf_trigger_webhook_on_bitform_submission', 10, 3);

/**
 * REST API endpoint for retrieving form responses.
 */
add_action('rest_api_init', function () {
    register_rest_route('responsefbf/v1', '/bitform-response', [
        'methods'  => 'GET',
        'callback' => 'responsefbf_get_response',
        'permission_callback' => '__return_true',
        'args'     => [
            'session_id' => [
                'required' => true,
                'validate_callback' => function ($param) {
                    return !empty($param);
                },
            ],
        ],
    ]);
});


/**
 * Retrieve the stored response using session ID.
 *
 * @param WP_REST_Request $request REST API request.
 * @return WP_REST_Response|WP_Error
 */
function responsefbf_get_response($request) {
    $session_id = $request->get_param('session_id');

    // Fetch the stored response
    $response_data = get_transient("responsefbf_{$session_id}");

    if ($response_data) {
        return rest_ensure_response($response_data);
    } else {
        return new WP_Error('session_not_found', 'Session data not found or expired.', ['status' => 404]);
    }
}


