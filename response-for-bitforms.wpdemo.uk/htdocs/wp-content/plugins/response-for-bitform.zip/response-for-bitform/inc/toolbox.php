<?php
// Exit if accessed directly.
// toolbox and helper funcitons
defined('ABSPATH') || exit;


// Generates a session ID for responsefbf
function responsefbf_generate_session_id() {
    return uniqid('responsefbf_', true);
}

// Generates a response URL for responsefbf
function responsefbf_generate_response_url($session_id, $form_id) {
    return get_rest_url(null, "responsefbf/v1/response/{$session_id}/{$form_id}");
}

// Verifies the nonce for responsefbf token
// function version 26
function responsefbf_verify_nonce($nonce, $session_id) {
    // Retrieve the nonce from the transient, matching the storage key format
    $stored_nonce = get_transient("responsefbf_nonce_{$session_id}");
    return hash_equals($stored_nonce, $nonce);
}

// Sets result data in a transient
function responsefbf_set_result_transient($session_id, $form_id, $data) {
    set_transient("responsefbf_result_{$session_id}_{$form_id}", $data, HOUR_IN_SECONDS);
}

// Gets result data from a transient
function responsefbf_get_result_transient($session_id, $form_id) {
    return get_transient("responsefbf_result_{$session_id}_{$form_id}");
}

// Processes and retrieves attachment data for a given URL
function responsefbf_process_attachment($attachment_url) {
    if (empty($attachment_url)) {
        return [];
    }

    $attachment_res = wp_remote_head(esc_url_raw($attachment_url));
    if (!is_wp_error($attachment_res)) {
        return [
            'status' => wp_remote_retrieve_response_code($attachment_res),
            'type'   => wp_remote_retrieve_header($attachment_res, 'content-type'),
            'size'   => [
                'bytes'     => intval(wp_remote_retrieve_header($attachment_res, 'content-length')),
                'formatted' => size_format(wp_remote_retrieve_header($attachment_res, 'content-length')),
            ],
            'html'   => '<a href="' . esc_url($attachment_url) . '" download>Download Attachment</a>',
            'link'   => $attachment_url,
        ];
    }
    return [];
}

/**
 * Check if the plugin is activated and licensed.
 *
 * 
 */
function responsefbf_get_client() {
    static $client = null;

    if ( $client === null ) {
        $client = new \responsefbf\Licensing\Client( 'Response for Bitforms', 'pt_usTzCchJQpYtKWCoRCusHS5P', __FILE__ );
    }

    return $client;
}

function responsefbf_is_activated_and_licensed() {
    $client = responsefbf_get_client();

    if ( ! $client ) {
        return false;
    }

    // Retrieve license data from the database
    $license_options = get_option( 'responseforbitforms_license_options', [] );

    $license_key = $license_options['sc_license_key'] ?? null;
    $activation_id = $license_options['sc_activation_id'] ?? null;

    if ( empty( $license_key ) || empty( $activation_id ) ) {
        return false;
    }

    $activation = new \responsefbf\Licensing\Activation( $client );
    $license = new \responsefbf\Licensing\License( $client );

    $is_license_valid = $license->is_valid( $license_key );

    if ( ! $is_license_valid ) {
            return false;
    }


    $activation_data = $activation->get( $activation_id );

    if ( is_wp_error( $activation_data ) ) {
        return false;
    }

    if ( empty( $activation_data ) || ! isset( $activation_data->id ) ) {
        //error_log( '[responsefbf] Activation ID not found in activation data.' );
        return false;
    }

    return true;
}




?>
