<?php
/*
Plugin Name: Response for BitForm
Description: A plugin to get you inline responses to your BitForm forms (Using the respository version)
Version: 1.11
Author: Really Useful Plugins
Author URI: https://reallyusefulplugins.com
License: GPLv2 or later
*/
// Main Plugin File

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Define plugin constants
define( 'RESPONSEFBF_VERSION', '1.1' );
define( 'RESPONSEFBF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RESPONSEFBF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Load required files from the `inc` directory
function responsefbf_RESPONSEFBF_load_includes() {
    $includes = [
        //'load-custom-app.php',
        'custom-api-response.php',
        'admin.php',
        'bitform-webhook-handler.php',
        'toolbox.php',        
        //'dist/parsedown.php',

    ];

    foreach ( $includes as $file ) {
        $file_path = RESPONSEFBF_PLUGIN_DIR . 'inc/' . $file;
        
        if ( file_exists( $file_path ) ) {
            require_once $file_path;
        } else {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( "Returns Assured: Failed to load $file_path" );
            }
        }
    }
}
// function version 100
add_action( 'plugins_loaded', 'responsefbf_RESPONSEFBF_load_includes' );

// function version 90
// Enqueue the JavaScript file for form output
function responsefbf_enqueue_output_script() {
    if (!wp_script_is('responsefbf-script', 'enqueued')) {
    wp_enqueue_script(
        'responsefbf-output-form',
        plugin_dir_url(__FILE__) . 'inc/js/output-form.js',
        ['wp-api-fetch'], // Ensures wp-api-fetch is available
        null,
        true
    );

    // Pass REST URL to the script for use in AJAX requests
    wp_localize_script('responsefbf-output-form', 'responsefbfData', [
        'restUrl' => esc_url_raw(rest_url()),
        'base_url' => get_site_url(), // Fetch the base URL of the WordPress site
        'webhookForms' => array_map('strval', array_keys(get_option('responsefbf_webhooks', []))), // Convert to strings
        'restBase' => rest_url('responsefbf/v1/'),
    ]);
    
}}
add_action('wp_enqueue_scripts', 'responsefbf_enqueue_output_script');

// to disable stylesheets use, define('RUP_RS4BF_CUSTOMSTYLES', true); 
function responsefbf_enqueue_custom_styles() {   // Check if the variable is not declared or set to false
    if ( ! defined('RUP_RS4BF_CUSTOMSTYLES') || ! RUP_RS4F_CUSTOMSTYLES ) {
        // Enqueue the custom CSS file
        wp_enqueue_style(
            'responsefbf', // Handle for the stylesheet
            plugin_dir_url( __FILE__ ) . 'inc/css/responsefbf.css', // Path to the CSS file (relative to plugin directory)
            array(), // Dependencies (none in this case)
            null, // Version (optional)
            'all' // Media (optional, 'all' is the default)
        );
    }
}
add_action('wp_enqueue_scripts', 'responsefbf_enqueue_custom_styles');

function responsefbf_initialize_bitforms_licensing() {
    $client_path = plugin_dir_path( __FILE__ ) . 'inc/src/Client.php';

    if ( ! file_exists( $client_path ) ) {
        error_log( 'Client.php not found at: ' . $client_path );
        return;
    }

    if ( ! class_exists( 'responsefbf\Licensing\Client' ) ) {
        require_once $client_path;
    }

    // Initialize the SureCart Licensing Client
    $client = new \ResponseFBF\Licensing\Client( 'Response for BitForms', 'pt_usTzCchJQpYtKWCoRCusHS5P', __FILE__ );

    // Optionally set your plugin's textdomain for internationalization
    $client->set_textdomain( 'response-for-bitforms-textdomain' );

    // Add the license management settings page
    $client->settings()->add_page(
        [
            'type'        => 'submenu',
            'parent_slug' => 'responsefbf_settings', // Submenu under your plugin menu
            'page_title'  => 'Manage License',
            'menu_title'  => 'Manage License',
            'capability'  => 'manage_options',
            'menu_slug'   => 'responsefbf_license_settings',
        ]
    );
}
add_action( 'init', 'responsefbf_initialize_bitforms_licensing' );