<?php

namespace BitCode\BitForm\Admin\Form;

use BitCode\BitForm\Core\Cryptography\Cryptography;
use BitCode\BitForm\Core\Database\FormEntryModel;
use BitCode\BitForm\Core\Util\FileHandler;
use BitCode\BitForm\Core\Util\Log;
use BitCode\BitForm\Core\WorkFlow\WorkflowExecutor;
use Exception;
use WP_Error;

class Helpers
{
  private static $encryptEntryIds = [];

  public static $file_upload_types = ['file-up', 'advanced-file-up'];

  public static $repeated_array_type_data_fields = ['check', 'image-select'];

  public static function filterNullEntries($entries)
  {
    $filteredEntries = [];
    foreach ($entries as $entry) {
      foreach ($entry as $key => $value) {
        if (is_null($value)) {
          unset($entry->$key);
        }
      }
      if (count((array) $entry)) {
        $filteredEntries[] = $entry;
      }
    }
    return $filteredEntries;
  }

  public static function scriptLoader($src, $id, $instanceObj = null, $selector = '', $attrs = [], $integrity = null, $contentId = '')
  {
    $attributes = wp_json_encode($attrs);
    $instObj = '';
    if ($instanceObj) {
      $instObj .= sprintf(
        '
      script.onload = function () {
          bfSelect("#{%1$s}").querySelectorAll("{%2$s}").forEach(function(fld){
          %3$s;
         });
  }
      ',
        $contentId,
        $selector,
        $instanceObj
      );
    }
    return sprintf(
      '
    var script =  document.createElement("script"), integrity = "%1$s", attrs = %2$s, id = "%3$s";
        script.src = "%4$s";
        script.id = id;
        if(integrity){
          script.integrity = integrity;
          script.crossOrigin = "anonymous";
        }
        if(attrs){
          Object.entries(attrs).forEach(function([key, val]){
            script.setAttribute(key,val);
          })
        }
        $instObj;
        var bodyElm = document.body;
        var alreadyExistScriptElm = bodyElm ? bodyElm.querySelector("script#$id"):null;
        if(alreadyExistScriptElm){
          bodyElm.removeChild(alreadyExistScriptElm)
        }
        if(!(window.recaptcha && id === "g-recaptcha-script")){
          bodyElm.appendChild(script);
        }
    ',
      $integrity,
      $attributes,
      $id,
      $src,
    );
  }

  public static function minifyJs($input)
  {
    if ('' === trim($input)) {
      return $input;
    }
    // Line-boundary whitespace only. The previous regexes also rewrote the
    // inside of string and template literals, corrupting generated config and
    // custom JS. Inputs are already terser-minified, so the aggressive pass
    // saved ~0.1% anyway.
    return preg_replace(
      [
        '/^[ \t]+/m',      // leading indentation
        '/[ \t]+$/m',      // trailing whitespace
        '/(?:\r?\n){3,}/', // 3+ consecutive newlines -> 2
      ],
      ['', '', "\n\n"],
      $input
    );
  }

  public static function removeJsSingleLineComments($code)
  {
    $length = strlen($code);
    $result = '';
    $inString = false;
    $inTemplate = false;
    $inRegex = false;
    $escapeNext = false;
    $stringDelimiter = '';
    $i = 0;

    while ($i < $length) {
      $char = $code[$i];
      $nextChar = $i + 1 < $length ? $code[$i + 1] : '';

      if ($escapeNext) {
        $result .= $char;
        $escapeNext = false;
      } elseif ($inString) {
        $result .= $char;
        if ('\\' === $char) {
          $escapeNext = true;
        } elseif ($char === $stringDelimiter) {
          $inString = false;
        }
      } elseif ($inTemplate) {
        $result .= $char;
        if ('\\' === $char) {
          $escapeNext = true;
        } elseif ('`' === $char) {
          $inTemplate = false;
        }
      } elseif ($inRegex) {
        $result .= $char;
        if ('\\' === $char) {
          $escapeNext = true;
        } elseif ('/' === $char) {
          $inRegex = false;
        }
      } else {
        if ('"' === $char || "'" === $char) {
          $inString = true;
          $stringDelimiter = $char;
          $result .= $char;
        } elseif ('`' === $char) {
          $inTemplate = true;
          $result .= $char;
        } elseif ('/' === $char) {
          if ('/' === $nextChar) {
            // Single-line comment found
            while ($i < $length && "\n" !== $code[$i]) {
              $i++;
            }
            continue; // skip until newline
          } elseif ('*' === $nextChar) {
            // Block comment start, just copy it (optional, depending on need)
            $result .= $char;
          } else {
            // Assume division or regex
            $result .= $char;
          }
        } else {
          $result .= $char;
        }
      }
      $i++;
    }

    return $result;
  }

  /**
   * @method name : saveFile
   * @description : save js/css field to disk
   * @param  : $path => like(dirName/css), $fileName => main.css, $script
   * @return : boolean
   */
  public static function saveFile($path, $fileName, $script, $fileOpenMode = 'a')
  {
    try {
      $rootDir = BITFORMS_CONTENT_DIR . DIRECTORY_SEPARATOR;
      $path = trim($path, '/');
      $pathArr = explode('/', $path); // like "fieldname/user => [Fieldname, user]
      foreach ($pathArr as $d) {
        $rootDir .= $d . DIRECTORY_SEPARATOR;
        if (!realpath($rootDir)) {
          wp_mkdir_p($rootDir);
        }
      }
      $fullPath = $rootDir . $fileName;
      if ('a' === $fileOpenMode) {
        $result = FileHandler::appendFile($fullPath, $script);
      } else {
        $result = FileHandler::writeFile($fullPath, $script);
      }
      if (false === $result) {
        throw new Exception("Failed to write to file: $fullPath");
      }
      return true;
    } catch (\Exception $e) {
      Log::debug_log($e->getMessage());
      return false;
    }
  }

  /**
   * @method name : generatePathDirOrFile
   * @dscription : generate path for js/css file
   * @params : $path => like(dirName/css)
   * @return : a string of full path
   */
  public static function generatePathDirOrFile($path)
  {
    $rootDir = BITFORMS_CONTENT_DIR . DIRECTORY_SEPARATOR;
    $path = trim($path, '/');
    $pathArr = explode('/', $path); // like "fieldname/user => [Fieldname, user]
    foreach ($pathArr as $d) {
      $rootDir .= $d . DIRECTORY_SEPARATOR;
    }
    return rtrim($rootDir, DIRECTORY_SEPARATOR);
  }

  public static function fileRead($filePath)
  {
    return FileHandler::readFile($filePath);
  }

  public static function getDataFromNestedPath($data, $key)
  {
    $keys = explode('->', $key);
    $lastKey = array_pop($keys);
    $dataType = is_array($data) ? 'array' : (is_object($data) ? 'object' : '');
    if ('array' === $dataType) {
      return self::accessFromArray($data, $keys, $lastKey);
    }
    if ('object' === $dataType) {
      return self::accessFromObject($data, $keys, $lastKey);
    }
  }

  private static function accessFromObject($data, $keys, $lastKey)
  {
    foreach ($keys as $k) {
      if (!property_exists($data, $k)) {
        return null;
      }
      $data = $data->$k;
    }
    return isset($data->$lastKey) ? $data->$lastKey : null;
  }

  private static function accessFromArray($data, $keys, $lastKey)
  {
    foreach ($keys as $k) {
      if (!array_key_exists($k, $data)) {
        return null;
      }
      $data = $data[$k];
    }
    return isset($data[$lastKey]) ? $data[$lastKey] : null;
  }

  public static function setDataToNestedPath($data, $key, $value)
  {
    $keys = explode('->', $key);
    $lastKey = array_pop($keys);
    foreach ($keys as $k) {
      if (!array_key_exists($k, $data)) {
        $data->$k = (object) [];
      }
      $data = $data->$k;
    }
    $data->$lastKey = json_decode(wp_json_encode($value));
    return $data;
  }

  public static function property_exists_nested($obj, $path = '', $valToCheck = null, $checkNegativeVal = 0)
  {
    $path = explode('->', $path);
    $current = $obj;
    foreach ($path as $key) {
      if (is_object($current)) {
        if (property_exists($current, $key)) {
          $current = $current->{$key};
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
    if (isset($valToCheck)) {
      if ($checkNegativeVal) {
        return $current !== $valToCheck;
      }
      return $current === $valToCheck;
    }
    return true;
  }

  public static function validateEntryTokenAndUser($entryToken, $entryId)
  {
    // check if the user is logged in
    if (is_user_logged_in()) {
      $user = wp_get_current_user();
      if (in_array('administrator', $user->roles) || current_user_can('manage_bitform')) {
        return true;
      }
      $entryModel = new FormEntryModel();
      $entry = $entryModel->get(
        'id, user_id, form_id',
        [
          'id'      => $entryId,
          'user_id' => $user->ID
        ]
      );
      if (!is_wp_error($entry) && !empty($entry)) {
        return true;
      }
    }
    // check if the entry token is valid
    if (isset($entryToken) && $entryToken) {
      $decryptEntryId = Cryptography::decrypt($entryToken, self::getBitformSalt());
      if ($decryptEntryId === $entryId) {
        return true;
      }
    }

    return false;
  }

  /**
   * Validate workflow trigger token with proper input sanitization
   *
   * @param object $request The AJAX request object
   * @param string $formID The form ID (already sanitized)
   * @return array ['valid' => bool, 'error' => string, 'triggerData' => object|null, 'isAdminBypass' => bool]
   */
  public static function validateWorkflowTriggerToken($request, $formID)
  {
    // Sanitize and validate cronNotOk array
    if (!isset($request->cronNotOk) || !is_array($request->cronNotOk)) {
      return [
        'valid'         => false,
        'error'         => 'Missing or invalid cronNotOk data',
        'triggerData'   => null,
        'isAdminBypass' => false
      ];
    }

    // Validate and sanitize entry ID and log ID (must be integers)
    if (!isset($request->cronNotOk[0]) || !is_numeric($request->cronNotOk[0])) {
      Log::debug_log('Invalid entry ID in cronNotOk[0]');
      return ['valid' => false, 'error' => 'Invalid entry ID', 'triggerData' => null, 'isAdminBypass' => false];
    }

    if (!isset($request->cronNotOk[1]) || !is_numeric($request->cronNotOk[1])) {
      Log::debug_log('Invalid log ID in cronNotOk[1]');
      return ['valid' => false, 'error' => 'Invalid log ID', 'triggerData' => null, 'isAdminBypass' => false];
    }

    $entryID = absint($request->cronNotOk[0]);
    $logID = absint($request->cronNotOk[1]);

    // Check for administrator bypass
    $isAdminBypass = false;
    if (is_user_logged_in()) {
      $user = wp_get_current_user();
      if (in_array('administrator', $user->roles) || current_user_can('manage_bitform')) {
        Log::debug_log('Admin bypass: Workflow triggered by ' . $user->user_login . ' for entryID=' . $entryID);
        return [
          'valid'         => true,
          'error'         => '',
          'triggerData'   => null,
          'isAdminBypass' => true
        ];
      }

      // For logged-in non-admin users: verify nonce
      if (isset($request->token, $request->id)) {
        if (!wp_verify_nonce($request->token, $request->id)) {
          Log::debug_log('Nonce verification failed for logged-in user. FormID=' . $formID);
          return [
            'valid'         => false,
            'error'         => 'Invalid nonce for logged-in user',
            'triggerData'   => null,
            'isAdminBypass' => false
          ];
        }
      } else {
        Log::debug_log('Missing nonce for logged-in user. FormID=' . $formID);
        return [
          'valid'         => false,
          'error'         => 'Missing nonce',
          'triggerData'   => null,
          'isAdminBypass' => false
        ];
      }
    }

    // For non-admin users (both logged-in and anonymous): validate one-time trigger token
    if (!isset($request->cronNotOk[3]) || empty($request->cronNotOk[3])) {
      Log::debug_log('Missing trigger token for formID=' . $formID . ', entryID=' . $entryID);
      return [
        'valid'         => false,
        'error'         => 'Missing trigger token',
        'triggerData'   => null,
        'isAdminBypass' => false
      ];
    }

    $submittedToken = sanitize_text_field($request->cronNotOk[3]);

    // Validate trigger token from transient
    $transientData = get_transient("bitform_trigger_transient_{$entryID}");

    // Object caches (W3TC, SG Optimizer, Redis) can drop the transient before the
    // browser trigger arrives; the queue log row holds the same payload durably.
    if (empty($transientData)) {
      $queueLogId = isset($request->cronNotOk[2]) && is_numeric($request->cronNotOk[2]) ? absint($request->cronNotOk[2]) : 0;
      $transientData = WorkflowExecutor::loadTriggerDataFromLog($queueLogId);
      Log::debug_log('Trigger token transient missing for entryID=' . $entryID . ', logID=' . $logID . '; durable copy ' . (empty($transientData) ? 'not found' : 'used'));
    }

    if (empty($transientData)) {
      return [
        'valid'         => false,
        'error'         => 'Trigger token expired or missing',
        'triggerData'   => null,
        'isAdminBypass' => false
      ];
    }

    $triggerData = is_string($transientData) ? json_decode($transientData, true) : (array) $transientData;
    // Verify token matches and belongs to this entry/log
    if (
      !isset($triggerData['trigger_token'], $triggerData['entryID'], $triggerData['logID'])
      || !hash_equals($triggerData['trigger_token'], $submittedToken)
      || (int)$triggerData['entryID'] !== $entryID
      || (int)$triggerData['logID'] !== $logID
    ) {
      Log::debug_log('Invalid trigger token for entryID=' . $entryID . ', logID=' . $logID);
      return [
        'valid'         => false,
        'error'         => 'Invalid trigger token',
        'triggerData'   => null,
        'isAdminBypass' => false
      ];
    }

    // Token is valid - delete transient to prevent reuse (single-use token)
    delete_transient("bitform_trigger_transient_{$entryID}");
    Log::debug_log('Valid trigger token consumed for entryID=' . $entryID);

    return [
      'valid'         => true,
      'error'         => '',
      'triggerData'   => $triggerData,
      'isAdminBypass' => false
    ];
  }

  public static function validateFormEntryEditPermission($formId, $entryId)
  {
    if (is_user_logged_in()) {
      if (current_user_can('manage_bitform') || current_user_can('bitform_entry_edit') || current_user_can('edit_post')) {
        return true;
      }
    }
    return false;
  }

  public static function honeypotEncryptedToken($str)
  {
    $token = base64_encode(base64_encode($str));
    return $token;
  }

  public static function csrfEecrypted()
  {
    $secretKey = get_option('bitform_csrf_secret');
    if (!$secretKey) {
      $secretKey = 'bf-' . time();
      update_option('bitform_csrf_secret', $secretKey);
    }
    $tIdenty = base64_encode(\random_bytes(32));
    $csrf = \base64_encode(\hash_hmac('sha256', $tIdenty, $secretKey, true));
    return ['csrf' => $csrf, 't_identity' => $tIdenty];
  }

  public static function csrfDecrypted($identy, $token)
  {
    $secretKey = get_option('bitform_csrf_secret');
    return \hash_equals(
      \base64_encode(\hash_hmac('sha256', $identy, $secretKey, true)),
      $token
    );
  }

  public static function checkIsIntArr($arr)
  {
    $filteredArray = array_filter($arr, 'is_numeric');
    $intArray = array_map('intval', $filteredArray);
    $result = count($arr) === count($intArray);

    return $result;
  }

  public static function getTruncatedEncryptToken($str, $length = 20)
  {
    $token = hash_hmac('sha256', $str, self::getBitformSalt());
    return substr($token, 0, $length);
  }

  public static function getAuthSaltEncryptToken($str, $length = 20)
  {
    if (!$str) {
      return '';
    }
    if (!defined('AUTH_SALT')) {
      return '';
    }

    return substr(hash_hmac('sha256', $str, AUTH_SALT), 0, $length);
  }

  public static function getEncryptedEntryId($entryId)
  {
    if (!isset(self::$encryptEntryIds[$entryId])) {
      self::$encryptEntryIds[$entryId] = self::getTruncatedEncryptToken($entryId);
    }
    return self::$encryptEntryIds[$entryId];
  }

  public static function getFullPathWithEncryptedEntryId($formId, $entryId)
  {
    $uploadDir = rtrim(BITFORMS_UPLOAD_DIR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $formId . DIRECTORY_SEPARATOR;
    $encryptDirectoryId = Helpers::getEncryptedEntryId($entryId);
    $encryptDirectory = $uploadDir . $encryptDirectoryId;
    if (is_dir($encryptDirectory)) {
      return $encryptDirectory;
    }

    $oldEntriesFileUploadDir = Helpers::getOldEntriesFileUploadDir($uploadDir, $entryId);
    if (!empty($oldEntriesFileUploadDir) && is_dir($oldEntriesFileUploadDir)) {
      return $oldEntriesFileUploadDir;
    }

    return $encryptDirectory;
  }

  public static function getWebPathWithEncryptedEntryId($formId, $entryId)
  {
    $serverFileUploadDir = rtrim(BITFORMS_UPLOAD_DIR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $formId . DIRECTORY_SEPARATOR;
    $webFileDirectory = BITFORMS_UPLOAD_BASE_URL . '/' . 'uploads' . '/' . $formId . '/';
    $encryptDirectoryId = Helpers::getEncryptedEntryId($entryId);
    $encryptDirectory = $serverFileUploadDir . $encryptDirectoryId;
    if (is_dir($encryptDirectory)) {
      return  $webFileDirectory . $encryptDirectoryId;
    }

    $authSaltEncryptedEntryId = Helpers::getAuthSaltEncryptToken($entryId);
    $authSaltEncryptedDirectory = $serverFileUploadDir . $authSaltEncryptedEntryId;
    if (!empty($authSaltEncryptedEntryId) && is_dir($authSaltEncryptedDirectory)) {
      return $webFileDirectory . $authSaltEncryptedEntryId;
    }
    $previousEntryDirectory = $serverFileUploadDir . $entryId;
    if (!empty($previousEntryDirectory) && is_dir($previousEntryDirectory)) {
      return $webFileDirectory . $entryId;
    }

    return $webFileDirectory . $encryptDirectoryId;
  }

  public static function getOldEntriesFileUploadDir($uploadDir, $entry_id)
  {
    $authSaltEncryptedEntryId = Helpers::getAuthSaltEncryptToken($entry_id);
    $authSaltEncryptedDirectory = $uploadDir . $authSaltEncryptedEntryId;
    if (!empty($authSaltEncryptedEntryId) && is_dir($authSaltEncryptedDirectory)) {
      return $authSaltEncryptedDirectory;
    }
    $previousEntryDirectory = $uploadDir . $entry_id;
    if (!empty($previousEntryDirectory) && is_dir($previousEntryDirectory)) {
      return $previousEntryDirectory;
    }
    return '';
  }

  public static function PDFPassHash($entryId)
  {
    return abs(crc32($entryId));
  }

  public static function encryptBinaryData($plaintext)
  {
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt($plaintext, 'AES-256-CBC', BITFORMS_SECRET_KEY, OPENSSL_RAW_DATA, $iv);

    return bin2hex($iv . $encrypted);
  }

  public static function decryptBinaryData($encryptedHex)
  {
    $decoded = hex2bin($encryptedHex);
    $iv = substr($decoded, 0, 16);
    $cipherText = substr($decoded, 16);

    return openssl_decrypt($cipherText, 'AES-256-CBC', BITFORMS_SECRET_KEY, OPENSSL_RAW_DATA, $iv);
  }

  /**
   * Sanitize user-provided HTML content by removing dangerous JS code
   * while allowing all valid HTML/CSS.
   *
   * @param string $html Raw HTML from user input
   * @return string Sanitized safe HTML
   */
  public static function sanitizeUserHTML(string $html): string
  {
    // Remove <script> tags entirely
    $html = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $html);

    // Remove event handler attributes (like onclick, onload, etc.)
    $html = preg_replace_callback('/<[^>]+>/i', function ($matches) {
      return preg_replace('/\s*on\w+\s*=\s*"[^"]*"/i', '', $matches[0]); // on*=""
    }, $html);

    $html = preg_replace_callback('/<[^>]+>/i', function ($matches) {
      return preg_replace("/\s*on\w+\s*=\s*'[^']*'/i", '', $matches[0]); // on*=''
    }, $html);

    // Remove javascript: from href or src
    $html = preg_replace('/(href|src)\s*=\s*([\'"])\s*javascript:[^\'"]*\2/i', '', $html);

    return $html;
  }

  public static function sanitizeUrlParam($param)
  {
    if (preg_match('/\.\.?\//', $param)) {
      return new WP_Error('parameter_error', 'Invalid URL parameter');
    }

    $param = htmlspecialchars(trim($param), ENT_QUOTES, 'UTF-8');
    return sanitize_text_field($param);
  }

  public static function replaceFieldsDefaultErrorMsg($fields)
  {
    try {
      $appSettings = get_option('bitform_app_settings', (object) []);
      if (!isset($appSettings->globalMessages) || !isset($appSettings->globalMessages->err)) {
        return $fields;
      }

      $globalErrMsg = $appSettings->globalMessages->err;
      $templateCache = []; // [type_errKey] => compiled template

      foreach ($fields as $fieldKey => $field) {
        if (!isset($field->err) || !is_object($field->err)) {
          continue;
        }

        foreach ($field->err as $errKey => $errObj) {
          if (!isset($errObj->dflt)) {
            continue;
          }

          $cacheKey = $field->typ . '_' . $errKey;
          $template = null;

          // 1. Check Cache First
          if (isset($templateCache[$cacheKey])) {
            $template = $templateCache[$cacheKey];
          } else {
            // 2. Lookup from globalErrMsg
            if (isset($globalErrMsg->{$field->typ}->{$errKey})) {
              $template = $globalErrMsg->{$field->typ}->{$errKey};
            } elseif (isset($globalErrMsg->{$errKey}) && !is_object($globalErrMsg->{$errKey})) {
              $template = $globalErrMsg->{$errKey};
            }

            // 3. Cache it
            if ($template) {
              $templateCache[$cacheKey] = $template;
            }
          }

          // 4. Apply Template if Found
          if ($template) {
            $finalMsg = self::replaceShortcodeInErrorMsg($template, $field);
            // 5. Sanitize final output
            $field->err->{$errKey}->dflt = wp_kses_post($finalMsg);
          }
        }

        $fields->{$fieldKey} = $field;
      }
    } catch (Exception $e) {
      Log::debug_log('Error In Replacing Fields Default Error messages: ' . $e->getMessage());
    }
    return $fields;
  }

  //replace shortcode in error message
  public static function replaceShortcodeInErrorMsg($msg, $field)
  {
    $shortcodes = [
      '${field.label}'          => isset($field->lbl) ? $field->lbl : '',
      '${field.minimum}'        => isset($field->mn) ? self::readableRangeValue($field->mn, isset($field->typ) ? $field->typ : '') : '',
      '${field.maximum}'        => isset($field->mx) ? self::readableRangeValue($field->mx, isset($field->typ) ? $field->typ : '') : '',
      '${field.minimum_file}'   => isset($field->config->minFile) ? $field->config->minFile : '',
      '${field.maximum_file}'   => isset($field->config->maxFile) ? $field->config->maxFile : '',
      '${field.maximum_size}'   => isset($field->config->maxSize) ? $field->config->maxSize : '',
      '${field.minimum_amount}' => isset($field->config->minValue) ? $field->config->minValue : '',
      '${field.maximum_amount}' => isset($field->config->maxValue) ? $field->config->maxValue : '',
    ];
    $msg = str_replace(array_keys($shortcodes), array_values($shortcodes), $msg);
    return $msg;
  }

  /**
   * Date-like min/max are stored in the input's wire format (2026-10-01T09:00, 2026-W40); show
   * them to visitors in the site's date/time format instead. Anything else is returned as is.
   *
   * @param mixed  $value field mn/mx
   * @param string $type  field type
   *
   * @return mixed
   */
  public static function readableRangeValue($value, $type)
  {
    if (!is_string($value) || '' === $value) {
      return $value;
    }
    $dateFormat = (string) get_option('date_format', 'F j, Y');
    $timeFormat = (string) get_option('time_format', 'g:i a');
    $utc = new \DateTimeZone('UTC');
    $formatTimestamp = function ($format, $timestamp) use ($utc) {
      return function_exists('wp_date') ? wp_date($format, $timestamp, $utc) : gmdate($format, $timestamp);
    };

    switch ($type) {
      case 'date':
        $date = \DateTime::createFromFormat('!Y-m-d', $value, $utc);
        return $date ? $formatTimestamp($dateFormat, $date->getTimestamp()) : $value;

      case 'datetime-local':
        $date = \DateTime::createFromFormat('!Y-m-d\TH:i', substr($value, 0, 16), $utc);
        return $date ? $formatTimestamp($dateFormat . ' ' . $timeFormat, $date->getTimestamp()) : $value;

      case 'time':
        $date = \DateTime::createFromFormat('!H:i', substr($value, 0, 5), $utc);
        return $date ? $formatTimestamp($timeFormat, $date->getTimestamp()) : $value;

      case 'month':
        $date = \DateTime::createFromFormat('!Y-m', $value, $utc);
        return $date ? $formatTimestamp('F Y', $date->getTimestamp()) : $value;

      case 'week':
        if (1 === preg_match('/^(\d{4})-W(\d{1,2})$/i', $value, $match)) {
          // translators: 1: ISO week number, 2: year
          return sprintf(__('week %1$d of %2$d', 'bit-form'), (int) $match[2], (int) $match[1]);
        }
        return $value;

      default:
        return $value;
    }
  }

  public static function getDefaultGlobalMessages()
  {
    $defaultGlobalMessages = [
      'err' => [
        'req'   => '<p style="margin:0">' . __('This field is required', 'bit-form') . '</p>',
        'email' => [
          'invalid' => '<p style="margin:0">' . __('Please, enter a valid email address', 'bit-form') . '</p>',
        ],
        'url' => [
          'invalid' => '<p style="margin:0">' . __('Please, enter a valid URL', 'bit-form') . '</p>',
        ],
        'mn'     => '<p style="margin:0">' . __('Minimum ${field.minimum} is required', 'bit-form') . '</p>',
        'mx'     => '<p style="margin:0">' . __('Maximum ${field.maximum} is allowed', 'bit-form') . '</p>',
        'number' => [
          'invalid' => '<p style="margin:0">' . __('Please, enter only numbers', 'bit-form') . '</p>',
        ],
        'phone-number' => [
          'invalid' => '<p style="margin:0">' . __('Please, enter a valid phone number', 'bit-form') . '</p>',
        ],
        'check' => [
          'mn' => '<p style="margin:0">' . __('Select at least ${field.minimum} option(s)', 'bit-form') . '</p>',
          'mx' => '<p style="margin:0">' . __('Please, select no more than ${field.maximum} option(s)', 'bit-form') . '</p>',
        ],
        'select' => [
          'mn' => '<p style="margin:0">' . __('Select at least ${field.minimum} option(s)', 'bit-form') . '</p>',
          'mx' => '<p style="margin:0">' . __('Please, select no more than ${field.maximum} option(s)', 'bit-form') . '</p>',
        ],
        'image-select' => [
          'mn' => '<p style="margin:0">' . __('Select at least ${field.minimum} option(s)', 'bit-form') . '</p>',
          'mx' => '<p style="margin:0">' . __('Please, select no more than ${field.maximum} option(s)', 'bit-form') . '</p>',
        ],
        'inputMask'   => '<p style="margin:0">' . __('Input does not match the required pattern', 'bit-form') . '</p>',
        'regexr'      => '<p style="margin:0">' . __('Input does not match the required pattern', 'bit-form') . '</p>',
        'minFile'     => '<p style="margin:0">' . __('Minimum ${field.minimum_file} file(s) required', 'bit-form') . '</p>',
        'maxFile'     => '<p style="margin:0">' . __('Maximum ${field.maximum_file} file(s) allowed', 'bit-form') . '</p>',
        'maxSize'     => '<p style="margin:0">' . __('Maximum file size exceeded. (Max: ${field.maximum_size}MB)', 'bit-form') . '</p>',
        'fileType'    => '<p style="margin:0">' . __('File type is not supported', 'bit-form') . '</p>',
        'entryUnique' => '<p style="margin:0">' . __('This value is already taken. Please, choose a different one.', 'bit-form') . '</p>',
        'userUnique'  => '<p style="margin:0">' . __('This username or email is already registered. Please, use another.', 'bit-form') . '</p>',
        'otherOptReq' => '<p style="margin:0">' . __('Custom Option Required', 'bit-form') . '</p>',
        'minValue'    => '<p style="margin:0">' . __('Minimum amount of ${field.minimum_amount} is required', 'bit-form') . '</p>',
        'maxValue'    => '<p style="margin:0">' . __('Maximum amount of ${field.maximum_amount} is allowed', 'bit-form') . '</p>',
      ],
    ];

    // Convert array to object recursively
    return json_decode(json_encode($defaultGlobalMessages));
  }

  public static function getBitformSalt()
  {
    $salt = get_option('bitforms_salt');
    if (!$salt) {
      $salt = bin2hex(\random_bytes(32));
      update_option('bitforms_salt', $salt);
    }
    return $salt;
  }
}
