<?php

/**
 * MailerLite Integration
 */

namespace BitCode\BitForm\Core\Integration\MailerLite;

if (!defined('ABSPATH')) {
  exit;
}

use BitCode\BitForm\Core\Integration\IntegrationHandler;
use BitCode\BitForm\Core\Util\HttpHelper;
use BitCode\BitForm\GlobalHelper;
use WP_Error;

/**
 * Provide functionality for MailerLite integration
 */
class MailerLiteHandler
{
  private $_integrationID;
  private static $_baseUrlV1 = 'https://api.mailerlite.com/api/v2/';
  private static $_baseUrlV2 = 'https://connect.mailerlite.com/api/';
  protected $_defaultHeader;

  private $_formID;

  public function __construct($integrationID, $fromID)
  {
    $this->_integrationID = $integrationID;
    $this->_formID = $fromID;
  }

  public static function registerAjax()
  {
    add_action('wp_ajax_bitforms_mailerlite_fetch_all_groups', [__CLASS__, 'fetchAllGroups']);
    add_action('wp_ajax_bitforms_mailerlite_refresh_fields', [__CLASS__, 'mailerliteRefreshFields']);
  }

  public static function fetchAllGroups()
  {
    if (isset($_REQUEST['_ajax_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_ajax_nonce'])), 'bitforms_save')) {
      GlobalHelper::requirePostMethod();

      try {
        $requestParams = GlobalHelper::formatRequestData();
      } catch (\InvalidArgumentException $e) {
        wp_send_json_error($e->getMessage(), 400);
      }
      if (
        empty($requestParams->auth_token)
      ) {
        wp_send_json_error(
          __(
            'Requested parameter is empty',
            'bit-form'
          ),
          400
        );
      }

      if ('v2' === $requestParams->version) {
        $apiEndpoints = self::$_baseUrlV2 . 'groups';
        $apiKey = trim((string) $requestParams->auth_token);
        $header = [
          'Authorization' => "Bearer $apiKey",
        ];
        $formattedResponse = [];

        $httpArgs = [
          'headers'     => $header,
          'timeout'     => 30,
          'redirection' => 0,
          'httpversion' => '1.1',
          'user-agent'  => 'Bitforms/' . BITFORMS_VERSION . '; ' . get_bloginfo('url')
        ];

        $response = wp_remote_get($apiEndpoints, $httpArgs);

        if (is_wp_error($response)) {
          wp_send_json_error($response->get_error_message(), 400);
        }

        $responseCode = wp_remote_retrieve_response_code($response);
        $responseBody = wp_remote_retrieve_body($response);
        $responseObj = json_decode($responseBody);

        if (200 === $responseCode && isset($responseObj->data)) {
          foreach ($responseObj->data as $value) {
            $formattedResponse[] = [
              'group_id' => $value->id,
              'name'     => $value->name,
            ];
          }
        } elseif (isset($responseObj->message) && 'Unauthenticated.' === $responseObj->message) {
          wp_send_json_error(
            __(
              'Invalid API Token',
              'bit-form'
            ),
            401
          );
        } elseif (isset($responseObj->message)) {
          wp_send_json_error($responseObj->message, $responseCode ?: 400);
        } elseif (!empty($responseBody)) {
          wp_send_json_error($responseBody, $responseCode ?: 400);
        } else {
          wp_send_json_error(
            __(
              'Unable to fetch MailerLite groups',
              'bit-form'
            ),
            $responseCode ?: 400
          );
        }
      } else {
        $apiEndpoints = self::$_baseUrlV1 . 'groups/';

        $header = [
          'X-Mailerlite-Apikey' => $requestParams->auth_token,
        ];

        $response = HttpHelper::get($apiEndpoints, null, $header);
        $formattedResponse = [];

        foreach ($response as $value) {
          $formattedResponse[] =
              [
                'group_id' => (string)$value->id,
                'name'     => $value->name,
              ];
        }
      }

      wp_send_json_success($formattedResponse, 200);
    } else {
      wp_send_json_error(
        __(
          'Token expired',
          'bit-form'
        ),
        401
      );
    }
  }

  public static function mailerliteRefreshFields()
  {
    if (isset($_REQUEST['_ajax_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_ajax_nonce'])), 'bitforms_save')) {
      GlobalHelper::requirePostMethod();
      try {
        $requestParams = GlobalHelper::formatRequestData();
      } catch (\InvalidArgumentException $e) {
        wp_send_json_error($e->getMessage(), 400);
      }

      if (
        empty($requestParams->auth_token)
      ) {
        wp_send_json_error(
          __(
            'Requested parameter is empty',
            'bit-form'
          ),
          400
        );
      }

      if ('v2' === $requestParams->version) {
        $apiEndpoints = self::$_baseUrlV2 . 'fields';

        $apiKey = $requestParams->auth_token;
        $header = [
          'Authorization' => "Bearer $apiKey",
        ];

        $response = HttpHelper::get($apiEndpoints, null, $header);

        $newResponse = [];
        foreach ($response->data as $value) {
          if ('email' !== $value->key) {
            $newResponse[] = [
              'key'      => $value->key,
              'label'    => $value->name,
              'required' => 'email' === $value->key ? true : false,
            ];
          }
        }

        $email[] = [
          'key'      => 'email',
          'label'    => 'Email',
          'required' => true,
        ];

        $formattedResponse = array_merge($email, $newResponse);

        if (isset($response->data)) {
          wp_send_json_success($formattedResponse, 200);
        } elseif (isset($response->message) && 'Unauthenticated.' === $response->message) {
          wp_send_json_error(
            __(
              'Invalid API Token',
              'bit-form'
            ),
            401
          );
        }
      } else {
        $apiEndpoints = self::$_baseUrlV1 . 'fields';

        $apiKey = $requestParams->auth_token;
        $header = [
          'X-Mailerlite-Apikey' => $apiKey,
        ];

        $response = HttpHelper::get($apiEndpoints, null, $header);

        $formattedResponse = [];
        foreach ($response as $value) {
          $formattedResponse[] = [
            'key'      => $value->key,
            'label'    => $value->title,
            'required' => 'email' === $value->key ? true : false,
          ];
        }

        if (count($response) > 0) {
          wp_send_json_success($formattedResponse, 200);
        } elseif (isset($response->error->message) && 'Unauthorized' === $response->error->message) {
          wp_send_json_error(
            __(
              'Invalid API Token',
              'bit-form'
            ),
            401
          );
        }
      }
    } else {
      wp_send_json_error(
        __(
          'Token expired',
          'bit-form'
        ),
        401
      );
    }
  }

  public function execute(IntegrationHandler $integrationHandler, $integrationData, $fieldValues, $entryID, $logID)
  {
    $integrationDetails = is_string($integrationData->integration_details) ? json_decode($integrationData->integration_details) : $integrationData->integration_details;
    $auth_token = $integrationDetails->auth_token;
    $version = $integrationDetails->version;
    $groupIds = $integrationDetails->group_ids;
    $fieldMap = $integrationDetails->field_map;
    $type = $integrationDetails->mailer_lite_type;
    $actions = $integrationDetails->actions;

    if (
      empty($fieldMap)
       || empty($auth_token)
    ) {
      return new WP_Error('REQ_FIELD_EMPTY', __('module, fields are required for MailerLite api', 'bit-form'));
    }
    $recordApiHelper = new RecordApiHelper($auth_token, $this->_integrationID, $logID, $entryID, $actions, $version);
    $mailerliteApiResponse = $recordApiHelper->executeRecordApi(
      $groupIds,
      $type,
      $fieldValues,
      $fieldMap,
      $auth_token,
      $this->_formID
    );

    if (is_wp_error($mailerliteApiResponse)) {
      return $mailerliteApiResponse;
    }
    return $mailerliteApiResponse;
  }
}
