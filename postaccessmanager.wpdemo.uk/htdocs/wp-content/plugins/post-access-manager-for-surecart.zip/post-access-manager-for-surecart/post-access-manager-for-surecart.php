<?php
/**
 * Plugin Name:       Post Acccess Manager for SureCart
 * Description:       Sell Access to Certain Posts / Custom Posts Using SureCart.
 * Version:           2.2.1
 * Requires at least: 6.5
 * Tested up to:      7.1.3
 * Requires PHP:      8.0
 * Author:            ReallyUsefulPlugins.com
 * Author URI:        https://Reallyusefulplugins.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       post-access-manager-for-surecart
 * Website:           https://reallyusefulplugins.com
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path( __FILE__ ) . 'inc/setup.php';
require_once plugin_dir_path( __FILE__ ) . 'inc/admin.php';
require_once plugin_dir_path( __FILE__ ) . 'inc/shortcodes.php';
//require_once plugin_dir_path( __FILE__ ) . 'inc/suredash.php';

if ( ! defined( 'RUPPAMFSC_PLUGIN_FILE' ) ) {
	define( 'RUPPAMFSC_PLUGIN_FILE', __FILE__ );
}


function rup_sell_ind_posts_get_protected_post_types() {
    // Default post types: post and page
    $default_post_types = ['post', 'page'];

    // Allow customization through a filter
    return apply_filters('rup_sell_ind_posts_protected_post_types', $default_post_types);
}



// Add a checkbox to mark a post as protected
function rup_sell_ind_posts_wsc_add_protected_toggle_meta_box() {
     if ( ! rup_sell_ind_posts_is_activated_and_licensed() ) {
        // Output an error message using your debug function.
        rup_sell_ind_posts_log_debug( 'Error: Please activate license via the appropriate activation page.' );
        return; // Stop further execution.
    }
    add_meta_box(
        'protected_toggle_meta_box',
        'Post Access Protection',
        'rup_sell_ind_posts_wsc_render_protected_toggle_meta_box',
        rup_sell_ind_posts_get_protected_post_types(),
        'side',
        'high'
    );

}
add_action('add_meta_boxes', 'rup_sell_ind_posts_wsc_add_protected_toggle_meta_box');

// Render the checkbox meta box
function rup_sell_ind_posts_wsc_render_protected_toggle_meta_box($post) {
    $protected = get_post_meta($post->ID, '_post_access_protected', true);
    ?>
    <label for="post_access_protected_checkbox">
        <input type="checkbox" name="post_access_protected_checkbox" id="post_access_protected_checkbox" value="1" <?php checked($protected, '1'); ?> />
        Protect Post Access
    </label>
    <?php
}

// Save the checkbox meta box data
function rup_sell_ind_posts_wsc_save_protected_toggle_meta_box($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    if (isset($_POST['post_access_protected_checkbox'])) {
        update_post_meta($post_id, '_post_access_protected', '1');
    } else {
        delete_post_meta($post_id, '_post_access_protected');
    }
}
add_action('save_post', 'rup_sell_ind_posts_wsc_save_protected_toggle_meta_box');

// Add custom meta box for purchase link
function rup_sell_ind_posts_wsc_add_purchase_link_meta_box() {
    if ( ! rup_sell_ind_posts_is_activated_and_licensed() ) {
        // Output an error message using your debug function.
        rup_sell_ind_posts_log_debug( 'Error: Please activate license via the appropriate activation page.' );
        return; // Stop further execution.
    }
    add_meta_box(
        'purchase_link_meta_box',
        'Purchase Access Link',
        'rup_sell_ind_posts_wsc_render_purchase_link_meta_box',
        rup_sell_ind_posts_get_protected_post_types(),
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'rup_sell_ind_posts_wsc_add_purchase_link_meta_box');

// Render the purchase link meta box
function rup_sell_ind_posts_wsc_render_purchase_link_meta_box($post) {
    // Retrieve the raw purchase link
    $raw_purchase_link = get_post_meta($post->ID, '_purchase_access_link_raw', true);
    $parameter_key = apply_filters('rup_sell_ind_posts_param_key', 'post_id');
    $final_purchase_link = $raw_purchase_link ? add_query_arg($parameter_key, $post->ID, $raw_purchase_link) : '';

    ?>
    <label for="purchase_access_link_raw">
        Raw Purchase Link:
        <input type="url" name="purchase_access_link_raw" id="purchase_access_link_raw" value="<?php echo esc_url($raw_purchase_link); ?>" style="width:100%;" />
        <p class="description">Enter the base purchase link. The <code><?php echo esc_html($parameter_key); ?></code> parameter with the post ID will be appended automatically.</p>
    </label>
    <label for="purchase_access_link_final" style="margin-top: 10px; display: block;">
        Final Purchase Link:
        <input type="text" id="purchase_access_link_final" value="<?php echo esc_url($final_purchase_link); ?>" style="width:100%;" readonly />
        <p class="description">This is the final link with the post ID appended.</p>
    </label>
    <?php
}

// Save the raw purchase link data
function rup_sell_ind_posts_wsc_save_purchase_link_meta_box($post_id) {
    // Check autosave or invalid post type
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    // Save the raw purchase link
    if (isset($_POST['purchase_access_link_raw'])) {
        update_post_meta($post_id, '_purchase_access_link_raw', esc_url_raw($_POST['purchase_access_link_raw']));
    } else {
        delete_post_meta($post_id, '_purchase_access_link_raw');
    }
}
add_action('save_post', 'rup_sell_ind_posts_wsc_save_purchase_link_meta_box');

// Helper function: Get final purchase link
function rup_sell_ind_posts_wsc_get_final_purchase_link($post_id) {
    $raw_purchase_link = get_post_meta($post_id, '_purchase_access_link_raw', true);
    $parameter_key = apply_filters('rup_sell_ind_posts_param_key', 'post_id');

    if ($raw_purchase_link) {
        return add_query_arg($parameter_key, $post_id, $raw_purchase_link);
    }

    return '';
}


// Generic helper: ask integrations which (if any) post "protects" this one.
// Default is none (0). Integrations (SureDash etc.) hook the filter below.
if ( ! function_exists( 'rup_sell_ind_posts_find_protecting_parent' ) ) {
    function rup_sell_ind_posts_find_protecting_parent( int $post_id ): int {
        $post_id = absint( $post_id );
        if ( ! $post_id ) {
            return 0;
        }

        // Allow other code to define relationships: child → protecting parent.
        // E.g. SureDash: belong_to_course → Course ID.
        $parent_id = (int) apply_filters(
            'rup_sell_ind_posts_find_protecting_parent',
            0,
            $post_id
        );

        return $parent_id > 0 ? $parent_id : 0;
    }
}


// Filter post content to restrict access
add_filter( 'the_content', 'rup_sell_ind_posts_wsc_filter_protected_content' );
/**
 * Filter the post content to enforce protection, but allow “All-Access” users through.
 *
 * @param string $content The original (possibly already filtered) post content.
 * @return string Either the full content or the preview + purchase prompt.
 */
function rup_sell_ind_posts_wsc_filter_protected_content( string $content ): string {

    // Only protect on single views of our protected post types
    if ( ! is_singular( rup_sell_ind_posts_get_protected_post_types() ) ) {
        return $content;
    }

    $post_id = get_the_ID();
    if ( ! $post_id ) {
        return $content;
    }

    // Use central helper so parent/child rules apply.
    if ( ! function_exists( 'rup_sell_ind_posts_is_post_protected' ) ) {
        return $content;
    }

    $is_protected = rup_sell_ind_posts_is_post_protected( $post_id );
    if ( ! $is_protected ) {
        // Not protected in any way: show everything
        return $content;
    }


    $user_id = get_current_user_id();

    // 1) All-Access users bypass everything
    if ( function_exists( 'rup_sell_ind_posts_user_has_all_access' ) && rup_sell_ind_posts_user_has_all_access( $user_id ) ) {
        return $content;
    }

    // 2) Load the allowed_posts meta and normalize to ints
    $allowed_posts = get_user_meta( $user_id, 'allowed_posts', true );
    if ( ! is_array( $allowed_posts ) ) {
        $allowed_posts = [];
    }
    $allowed_posts = array_map( 'intval', $allowed_posts );

    // Debug — remove or comment out in production
    if ( function_exists( 'rup_sell_ind_posts_log_debug' ) ) {
        rup_sell_ind_posts_log_debug( sprintf(
            '[Filter] User %d allowed_posts = %s',
            $user_id,
            print_r( $allowed_posts, true )
        ) );
    }

        // 3) If they individually own this post OR a parent that secures it, show it.
    if ( function_exists( 'rup_sell_ind_posts_user_can_view' ) ) {
        if ( rup_sell_ind_posts_user_can_view( $user_id, $post_id ) ) {
            return $content;
        }
    } elseif ( in_array( (int) $post_id, $allowed_posts, true ) ) {
        // Fallback if helper is not available for some reason.
        return $content;
    }


    // 4) Otherwise show the preview + purchase prompt
    // Be tolerant of whitespace: <!-- protected -->, <!--protected -->, etc.
    $marker_regex = '/<!--\s*protected\s*-->/i';

    $preview = '';

    // First try to split the ALREADY rendered content
    if ( preg_match( $marker_regex, $content ) ) {
        $parts   = preg_split( $marker_regex, $content, 2 );
        $preview = $parts[0];
    } else {
        // If the marker isn't visible in $content (e.g. SureDash / blocks stripped it),
        // look in the raw post_content from the database.
        $raw_content = get_post_field( 'post_content', $post_id );

        if ( is_string( $raw_content ) && preg_match( $marker_regex, $raw_content ) ) {
            $raw_parts   = preg_split( $marker_regex, $raw_content, 2 );
            $raw_preview = $raw_parts[0];

            // Run the raw preview through the standard content filters EXCEPT this one
            // so it still gets shortcodes, autop, etc.
            remove_filter( 'the_content', 'rup_sell_ind_posts_wsc_filter_protected_content' );
            $preview = apply_filters( 'the_content', $raw_preview );
            add_filter( 'the_content', 'rup_sell_ind_posts_wsc_filter_protected_content' );
        } else {
            // No marker at all, fall back to empty preview
            $preview = '';
        }
    }

    if ( function_exists( 'rup_sell_ind_posts_get_effective_purchase_link' ) ) {
        $buy_link = rup_sell_ind_posts_get_effective_purchase_link( $post_id, '/buy-access' );
    } else {
        // Old behaviour fallback, just in case.
        $raw_link  = get_post_meta( $post_id, '_purchase_access_link_raw', true ) ?: '/buy-access';
        $param_key = apply_filters( 'rup_sell_ind_posts_param_key', 'post_id' );
        $buy_link  = add_query_arg( $param_key, $post_id, $raw_link );
    }


    $prompt_html = sprintf(
        '<div class="protected-content-message"><p>This content is protected. <a href="%s" class="purchase-link button">Purchase Access</a></p></div>',
        esc_url( $buy_link )
    );

    // NEW: allow custom filters (like your top-up message) to override this output
    $combined = $preview . $prompt_html;

    return apply_filters(
        'rup_sell_ind_posts_wsc_protected_content_output',
        $combined,
        $post_id,
        $buy_link
    );
}

// Add CSS
function rup_sell_ind_posts_wsc_add_hidden_post_id_css() {
    echo '<style>
        .hidden-post-id {
            display: none !important;
        }
    </style>';
}
add_action('wp_head', 'rup_sell_ind_posts_wsc_add_hidden_post_id_css');

// Display Custom Meta Fields in User Profile
function rup_sell_ind_posts_wsc_custom_user_meta_fields($user) {
    // Retrieve allowed posts from user meta
    $allowed_posts = get_user_meta($user->ID, 'allowed_posts', true);

    // Convert to comma-separated string for display
    $allowed_posts_list = is_array($allowed_posts) ? implode(',', $allowed_posts) : '';
    ?>
    <h3>Custom Post Access</h3>
    <table class="form-table">
        <tr>
            <th><label for="allowed_posts">Allowed Post IDs</label></th>
            <td>
                <input type="text" name="allowed_posts" id="allowed_posts" value="<?php echo esc_attr($allowed_posts_list); ?>" class="regular-text" />
                <p class="description">Enter post IDs separated by commas (e.g., 12,15,20).</p>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'rup_sell_ind_posts_wsc_custom_user_meta_fields'); // Own Profile
add_action('edit_user_profile', 'rup_sell_ind_posts_wsc_custom_user_meta_fields'); // Admin Editing Other Profiles

// Save Custom Meta Fields on User Update
function rup_sell_ind_posts_wsc_save_custom_user_meta_fields($user_id) {
    // Check for correct permissions
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    // Sanitize and process allowed post IDs
    $allowed_posts_input = isset($_POST['allowed_posts']) ? sanitize_text_field($_POST['allowed_posts']) : '';

    // Convert comma-separated string into an array of integers
    $allowed_posts = array_filter(array_map('intval', explode(',', $allowed_posts_input)));

    // Update user meta
    update_user_meta($user_id, 'allowed_posts', $allowed_posts);
}
add_action('personal_options_update', 'rup_sell_ind_posts_wsc_save_custom_user_meta_fields'); // Own Profile
add_action('edit_user_profile_update', 'rup_sell_ind_posts_wsc_save_custom_user_meta_fields'); // Admin Editing Other Profiles

// Admin Improvements
// Authorised Product ID Begin
// Save Authorized Price ID Meta Box Data
function rup_sell_ind_posts_wsc_save_authorized_price_meta_box($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    if (isset($_POST['authorized_price_id'])) {
        update_post_meta($post_id, '_authorized_price_id', sanitize_text_field($_POST['authorized_price_id']));
    } else {
        delete_post_meta($post_id, '_authorized_price_id');
    }
}
add_action('save_post', 'rup_sell_ind_posts_wsc_save_authorized_price_meta_box');

// Add Authorized Price ID Meta Box
function rup_sell_ind_posts_wsc_add_authorized_price_meta_box() {
    if ( ! rup_sell_ind_posts_is_activated_and_licensed() ) {
        // Output an error message using your debug function.
        rup_sell_ind_posts_log_debug( 'Error: Please activate license via the appropriate activation page.' );
        return; // Stop further execution.
    }
    add_meta_box(
        'authorized_price_meta_box',
        'Authorized Price ID',
        'rup_sell_ind_posts_wsc_render_authorized_price_meta_box',
        rup_sell_ind_posts_get_protected_post_types(),
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'rup_sell_ind_posts_wsc_add_authorized_price_meta_box');

// Render Authorized Price ID Meta Box
function rup_sell_ind_posts_wsc_render_authorized_price_meta_box($post) {
    $authorized_price_id = get_post_meta($post->ID, '_authorized_price_id', true);
    ?>
    <label for="authorized_price_id">
        Authorized Price ID:
        <input type="text" name="authorized_price_id" id="authorized_price_id" value="<?php echo esc_attr($authorized_price_id); ?>" class="regular-text" />
        <p class="description">Enter the SureCart Price ID associated with this post.</p>
    </label>
    <?php
}


// Authorised Product ID End

// Add Admin Column for Post ID
function rup_sell_ind_posts_wsc_add_post_id_column($columns) {
    $columns['post_id'] = 'Post ID'; // Add a new column for Post ID
    return $columns;
}
add_filter('manage_posts_columns', 'rup_sell_ind_posts_wsc_add_post_id_column');
add_filter('manage_pages_columns', 'rup_sell_ind_posts_wsc_add_post_id_column');

// Populate Post ID in Admin Column
function rup_sell_ind_posts_wsc_show_post_id_column_content($column_name, $post_id) {
    if ($column_name === 'post_id' && !did_action("show_post_id_{$post_id}")) {
        // Output the Post ID securely
        echo esc_html($post_id);
        
        // Set an action to ensure this is only run once per post ID
        do_action("show_post_id_{$post_id}");
    }
}
add_action('manage_posts_custom_column', 'rup_sell_ind_posts_wsc_show_post_id_column_content', 10, 2);
add_action('manage_pages_custom_column', 'rup_sell_ind_posts_wsc_show_post_id_column_content', 10, 2);

// Show Post ID on Post Edit Screen
function rup_sell_ind_posts_wsc_display_post_id_meta_box($post) {
    $post_id = $post->ID;
    // Output the Post ID within the meta box
    echo '<p><strong>Post ID:</strong> ' . esc_html($post_id) . '</p>';
}

// Add Post ID Meta Box in Edit Screen
function rup_sell_ind_posts_wsc_add_post_id_meta_box() {
    add_meta_box(
        'post_id_meta_box', // Meta box ID
        'Post Information', // Title
        'rup_sell_ind_posts_wsc_display_post_id_meta_box', // Callback function
        rup_sell_ind_posts_get_protected_post_types(),
        'side', // Context: side, normal, or advanced
        'high' // Priority
    );
}
add_action('add_meta_boxes', 'rup_sell_ind_posts_wsc_add_post_id_meta_box');

// Apply Access and check Post ID, Price ID and matching information
/**
 * After SureCart checkout confirmation, grant either All‑Access or single‑post access.
 *
 * @param \SureCart\Models\Checkout $checkout The checkout object.
 * @param mixed                     $request  Optional webhook/request data.
 */
function rup_sell_ind_posts_wsc_addCustomData( $checkout, $request ) {
    // Ensure plugin is licensed
    if ( ! rup_sell_ind_posts_is_activated_and_licensed() ) {
        rup_sell_ind_posts_log_debug( 'Checkout handler: license not active' );
        return;
    }

    // Determine purchased Price ID
    $lineItems         = $checkout->line_items->data ?? [];
    $firstLineItem     = reset( $lineItems );
    $purchasedPriceId  = $firstLineItem->price_id ?? '';
    if ( ! $purchasedPriceId ) {
        rup_sell_ind_posts_log_debug( 'Checkout handler: no price_id found' );
        return;
    }

    // Identify or create the WP_User
    $userId = get_current_user_id();
    if ( ! $userId ) {
        $email = $checkout->email ?? '';
        if ( ! $email ) {
            rup_sell_ind_posts_log_debug( 'Checkout handler: no user ID and no email' );
            return;
        }
        $user = get_user_by( 'email', $email );
        if ( $user ) {
            $userId = $user->ID;
        } else {
            $password = wp_generate_password();
            $userId   = wp_create_user( $email, $password, $email );
            if ( is_wp_error( $userId ) ) {
                rup_sell_ind_posts_log_debug( 'Checkout handler: failed to create user for email ' . $email );
                return;
            }
        }
    }

    // Check if this is an All‑Access purchase BEFORE doing metadata lookup
    $allAccessEnabled  = get_option( 'pae_all_access_enabled', '0' );
    $allAccessPriceIds = (array) get_option( 'pae_all_access_price_ids', ['', '', ''] );
    if ( '1' === $allAccessEnabled && in_array( $purchasedPriceId, $allAccessPriceIds, true ) ) {
        update_user_meta( $userId, 'all_access_granted', '1' );
        do_action( 'rup_sell_ind_posts_access_granted', [
            'user_id'  => $userId,
            'post_id'  => 'all',
            'order_id' => $checkout->id,
            'price_id' => $purchasedPriceId,
        ] );
        return;
    }

    // Prepare array of valid metadata keys (current + legacy)
    $primary_key = apply_filters('rup_sell_ind_posts_param_key', 'post_id');
    $legacy_keys = apply_filters('rup_sell_ind_posts_legacy_param_keys', []);
    $all_keys    = array_merge( [ $primary_key ], $legacy_keys );

    // Find first matching key in metadata
    $postId = null;
    foreach ( $all_keys as $key ) {
        if ( isset( $checkout->metadata->{$key} ) ) {
            $postId = $checkout->metadata->{$key};
            break;
        }
    }
    if ( ! $postId ) {
        rup_sell_ind_posts_log_debug( "Checkout handler: none of keys [" . implode(',', $all_keys) . "] found" );
        return;
    }

    // Grant individual post access
    $allowedPosts = get_user_meta( $userId, 'allowed_posts', true );
    $allowedPosts = is_array( $allowedPosts ) ? $allowedPosts : [];
    if ( ! in_array( $postId, $allowedPosts, true ) ) {
        $allowedPosts[] = $postId;
        update_user_meta( $userId, 'allowed_posts', $allowedPosts );
    }

    do_action( 'rup_sell_ind_posts_access_granted', [
        'user_id'  => $userId,
        'post_id'  => $postId,
        'order_id' => $checkout->id,
        'price_id' => $purchasedPriceId,
    ] );
}
add_action( 'surecart/checkout_confirmed', 'rup_sell_ind_posts_wsc_addCustomData', 10, 2 );


/**
 * When SureCart revokes a purchase, remove that post_id from the user’s allowed_posts.
 */
function rup_sell_ind_posts_revoke_access( $purchase, $webhook_data = null ) {
    $purchase_data = \SureCart\Models\Purchase::with([ 'initial_order', 'order.checkout' ])
        ->find( $purchase->id );
    $checkout = $purchase_data->initial_order->checkout ?? null;
    if ( ! $checkout ) {
        rup_sell_ind_posts_log_debug( "Revoke: no checkout on purchase {$purchase->id}" );
        return;
    }

    // Determine price ID purchased
    $firstItem      = $checkout->line_items->data[0] ?? null;
    $purchasedPrice = $firstItem->price_id ?? '';

    // All‑Access revoke
    $allAccessEnabled  = get_option( 'pae_all_access_enabled', '0' );
    $allAccessPriceIds = (array) get_option( 'pae_all_access_price_ids', ['', '', ''] );
    if ( '1' === $allAccessEnabled && in_array( $purchasedPrice, $allAccessPriceIds, true ) ) {
        $userId = get_current_user_id();
        if ( ! $userId && ! empty( $checkout->email ) ) {
            $user = get_user_by( 'email', $checkout->email );
            $userId = $user ? $user->ID : null;
        }
        if ( $userId ) {
            rup_sell_ind_posts_revoke_all_access_from_user( $userId );
            do_action( 'rup_sell_ind_posts_access_revoked', [ 'user_id' => $userId, 'post_id' => 'all' ] );
        }
        return;
    }

    // Single‑post revoke: check all keys
    $primary_key = apply_filters('rup_sell_ind_posts_param_key', 'post_id');
    $legacy_keys = apply_filters('rup_sell_ind_posts_legacy_param_keys', []);
    $all_keys    = array_merge( [ $primary_key ], $legacy_keys );

    $postId = null;
    foreach ( $all_keys as $key ) {
        if ( isset( $checkout->metadata->{$key} ) ) {
            $postId = $checkout->metadata->{$key};
            break;
        }
    }
    if ( ! $postId ) {
        rup_sell_ind_posts_log_debug( "Revoke: none of keys [" . implode(',', $all_keys) . "] found" );
        return;
    }

    $userId = get_current_user_id();
    if ( ! $userId && ! empty( $checkout->email ) ) {
        $u = get_user_by( 'email', $checkout->email );
        $userId = $u ? $u->ID : null;
    }
    if ( ! $userId ) {
        rup_sell_ind_posts_log_debug( "Revoke: cannot identify user for purchase {$purchase->id}" );
        return;
    }

    $allowed = get_user_meta( $userId, 'allowed_posts', true ) ?: [];
    if ( in_array( $postId, $allowed, true ) ) {
        $allowed = array_diff( $allowed, [ $postId ] );
        update_user_meta( $userId, 'allowed_posts', $allowed );
    }
}
add_action( 'surecart/purchase_revoked', 'rup_sell_ind_posts_revoke_access', 10, 2 );


/**
 * When a revoked subscription is restored, re-grant access exactly like a fresh checkout.
 */
add_action( 'surecart/purchase_invoked', 'rup_sell_ind_posts_handle_purchase_invoked', 10, 2 );
function rup_sell_ind_posts_handle_purchase_invoked( $purchase, $webhook_data = null ) {
    static $has_run = false;
    if ( $has_run ) {
        return;
    }
    $has_run = true;

    $purchase_data = \SureCart\Models\Purchase::with( [ 'initial_order' ] )
                        ->find( $purchase->id );
    if ( empty( $purchase_data->initial_order ) ) {
        rup_sell_ind_posts_log_debug( "Invoke: no initial_order on purchase {$purchase->id}" );
        return;
    }

    $rawCheckout = $purchase_data->initial_order->checkout;
    if ( $rawCheckout instanceof \SureCart\Models\Checkout ) {
        $checkout = $rawCheckout;
    } else {
        $checkout = \SureCart\Models\Checkout::with( [ 'metadata', 'line_items', 'line_items.price' ] )
                        ->find( (string) $rawCheckout );
    }
    if ( ! $checkout ) {
        rup_sell_ind_posts_log_debug( "Invoke: could not load Checkout {$rawCheckout}" );
        return;
    }

    // Determine purchased Price ID
    $lineItems        = $checkout->line_items->data ?? [];
    $firstItem        = reset( $lineItems );
    $purchasedPriceId = $firstItem->price_id ?? null;
    if ( ! $purchasedPriceId ) {
        rup_sell_ind_posts_log_debug( "Invoke: no price_id on restored purchase {$purchase->id}" );
        return;
    }

    // All‑Access restore
    $allAccessEnabled  = get_option( 'pae_all_access_enabled', '0' );
    $allAccessPriceIds = get_option( 'pae_all_access_price_ids', ['', '', ''] );
    if ( '1' === $allAccessEnabled && in_array( $purchasedPriceId, (array) $allAccessPriceIds, true ) ) {
        $userId = get_current_user_id();
        if ( ! $userId && ! empty( $checkout->email ) ) {
            $user = get_user_by( 'email', $checkout->email );
            $userId = $user ? $user->ID : null;
        }
        if ( $userId ) {
            rup_sell_ind_posts_grant_all_access_to_user( $userId );
            do_action( 'rup_sell_ind_posts_access_granted', [
                'user_id'  => $userId,
                'post_id'  => 'all',
                'order_id' => $purchase->id,
                'price_id' => $purchasedPriceId,
            ] );
        }
        return;
    }

    // Delegate to checkout handler which handles legacy keys
    rup_sell_ind_posts_wsc_addCustomData( $checkout, $webhook_data );
}



/* --------------------------------------------------
   SDK Inclusion - V1.12
-------------------------------------------------- */

function rup_sell_ind_posts_initialize_licensing() {
	$client_path = plugin_dir_path( __FILE__ ) . 'inc/ConfigAwareClient.php';

	if ( ! file_exists( $client_path ) ) {
		error_log( 'ConfigAwareClient.php not found at: ' . $client_path );
		return;
	}

	if ( ! class_exists( 'RUPPAMFSC\\Licensing\\ConfigAwareClient' ) ) {
		require_once $client_path;
	}

	// Initialize the SureCart Licensing Client.
	$client = new \RUPPAMFSC\Licensing\ConfigAwareClient(
		'Post Access Manager For SureCart',
		'pt_usTzCchJQpYtKWCoRCusHS5P',
		__FILE__
	);

	$client->set_textdomain( 'post-access-manager-for-surecart-textdomain' );

	// wp-config.php constant support.
	$client->set_license_constant( 'RUPPAMFSC_LICENSE_KEY' );
	$client->infer_license_constant( true );
	$client->allow_db_fallback( true );

	// Add the license management settings page.
	$client->settings()->add_page( [
		'type'        => 'submenu',
		'parent_slug' => 'post-access-expiry-settings',
		'page_title'  => 'Post Access Manager Licence',
		'menu_title'  => 'Activate Licence',
		'capability'  => 'manage_options',
		'menu_slug'   => 'ruppamfsc-post-access-manager',
	] );
}
add_action( 'init', 'rup_sell_ind_posts_initialize_licensing' );


//Javascript Custom Field
function rup_sell_ind_posts_inline_script() {
   $param_key = esc_js(apply_filters('rup_sell_ind_posts_param_key', 'post_id'));

   $script = <<<JS
   document.addEventListener("DOMContentLoaded", function () {
       const param_key = "{$param_key}";  // Define the variable here

       const urlParams = new URLSearchParams(window.location.search);
       const postId = urlParams.get(param_key);

       if (postId) {
           const scInput = document.querySelector("sc-input[name='" + param_key + "']");

           if (scInput) {
               scInput.setAttribute("value", postId);

               const inputEvent = new Event("input", { bubbles: true });
               scInput.dispatchEvent(inputEvent);

               console.log("Injected Post ID:", postId);
           } else {
               console.error("Hidden Post ID field not found.");
           }
       } else {
           console.error("Post ID not found in URL.");
       }
   });
   JS;

   wp_register_script('rup-custom-js', '', [], false, true);
   wp_enqueue_script('rup-custom-js');
   wp_add_inline_script('rup-custom-js', $script);
}
add_action('wp_enqueue_scripts', 'rup_sell_ind_posts_inline_script');


/* --------------------------------------------------
   DEBUGGING HELPER FUNCTION
   define( 'rup_sell_ind_posts_debug', true );
-------------------------------------------------- */
function rup_sell_ind_posts_log_debug( $message ) {
    if ( defined( 'rup_sell_ind_posts_debug' ) && rup_sell_ind_posts_debug === true ) {
        error_log( $message );
    }
}


//----------------------------------------------------------------------
// Helper Function -  Add user‑meta helpers for “All‑Access”
//----------------------------------------------------------------------

/**
 * Grant “all‑access” to a user.
 *
 * @param int $user_id WP_User ID.
 */
function rup_sell_ind_posts_grant_all_access_to_user( int $user_id ): void {
    update_user_meta( $user_id, 'all_access_granted', '1' );
}

/**
 * Remove “all‑access” flag from a user.
 *
 * @param int $user_id WP_User ID.
 */
function rup_sell_ind_posts_revoke_all_access_from_user( int $user_id ): void {
    delete_user_meta( $user_id, 'all_access_granted' );
}

/**
 * Check whether a user has “all‑access”.
 *
 * @param int $user_id WP_User ID.
 * @return bool True if user has all‑access, false otherwise.
 */
function rup_sell_ind_posts_user_has_all_access( int $user_id ): bool {
    return get_user_meta( $user_id, 'all_access_granted', true ) === '1';
}

//----------------------------------------------------------------------
// Allow admins to view & edit the “all_access_granted” flag on user profiles
//----------------------------------------------------------------------

// 1) Show checkbox on the profile page
add_action( 'show_user_profile',    'rup_sell_ind_posts_show_all_access_field' );
add_action( 'edit_user_profile',    'rup_sell_ind_posts_show_all_access_field' );
function rup_sell_ind_posts_show_all_access_field( WP_User $user ) {
    // Only allow admins (or the user themselves) to edit
    if ( ! current_user_can( 'edit_users', $user->ID ) ) {
        return;
    }

    $has_all_access = get_user_meta( $user->ID, 'all_access_granted', true ) === '1';
    ?>
    <h3>All‑Access Control</h3>
    <table class="form-table">
      <tr>
        <th><label for="all_access_granted">All‑Access Granted</label></th>
        <td>
          <input
            type="checkbox"
            name="all_access_granted"
            id="all_access_granted"
            value="1" <?php checked( $has_all_access, true ); ?> 
          />
          <span class="description">
            Check this to give the user “All‑Access” (bypass all post protections).
          </span>
        </td>
      </tr>
    </table>
    <?php
}

// 2) Save the field when profile is updated
add_action( 'personal_options_update', 'rup_sell_ind_posts_save_all_access_field' );
add_action( 'edit_user_profile_update', 'rup_sell_ind_posts_save_all_access_field' );
function rup_sell_ind_posts_save_all_access_field( int $user_id ) {
    // Only allow if current user can edit this user
    if ( ! current_user_can( 'edit_users', $user_id ) ) {
        return;
    }

    // Update or delete the meta
    if ( isset( $_POST['all_access_granted'] ) && $_POST['all_access_granted'] === '1' ) {
        update_user_meta( $user_id, 'all_access_granted', '1' );
    } else {
        delete_user_meta( $user_id, 'all_access_granted' );
    }
}


// Centralised "is this post protected?" helper.
//  - True if the post itself is flagged protected.
//  - OR if a protecting parent is protected + "secures children".
if ( ! function_exists( 'rup_sell_ind_posts_is_post_protected' ) ) {
    function rup_sell_ind_posts_is_post_protected( int $post_id ): bool {
        $post_id = absint( $post_id );
        if ( ! $post_id ) {
            return false;
        }

        // Direct per-post checkbox
        $is_protected = ( get_post_meta( $post_id, '_post_access_protected', true ) === '1' );

        // If not directly protected, check for an effective protecting parent
        // (which may be a Space OR a Portal that owns that Space).
        if ( ! $is_protected ) {
            $parent_id = 0;

            if ( function_exists( 'rup_sell_ind_posts_get_effective_protecting_parent' ) ) {
                $parent_id = rup_sell_ind_posts_get_effective_protecting_parent( $post_id );
            } elseif ( function_exists( 'rup_sell_ind_posts_find_protecting_parent' ) ) {
                // Fallback to the old behaviour if needed.
                $parent_id = (int) rup_sell_ind_posts_find_protecting_parent( $post_id );
            }

            if ( $parent_id ) {
                $secures_children    = ( get_post_meta( $parent_id, '_post_access_parent_secures_children', true ) === '1' );
                $parent_is_protected = ( get_post_meta( $parent_id, '_post_access_protected', true ) === '1' );

                if ( $secures_children && $parent_is_protected ) {
                    $is_protected = true;
                }
            }
        }


        return (bool) apply_filters(
            'rup_sell_ind_posts_is_post_protected',
            $is_protected,
            $post_id
        );
    }
}



/**
 * Filter hook: add legacy metadata keys for backwards compatibility.
 *
 * Usage (in your theme or custom plugin):
 * add_filter('rup_sell_ind_posts_legacy_param_keys', function($keys) {
 *     // e.g. previously used "old_post_id" and "legacy_id"
 *     $keys[] = 'old_post_id';
 *     $keys[] = 'legacy_id';
 *     return $keys;
 * });
 */
