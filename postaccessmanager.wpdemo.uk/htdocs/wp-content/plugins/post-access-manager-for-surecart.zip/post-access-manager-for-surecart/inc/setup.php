<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* --------------------------------------------------
   SDK Helper Function - Plugin
-------------------------------------------------- */
function rup_sell_ind_posts_get_client() {
	static $client = null;

	if ( null === $client ) {
		$client = new \RUPPAMFSC\Licensing\ConfigAwareClient(
			'Post Access Manager For SureCart',
			'pt_usTzCchJQpYtKWCoRCusHS5P',
			RUPPAMFSC_PLUGIN_FILE
		);

		$client->set_textdomain( 'post-access-manager-for-surecart-textdomain' );
		$client->set_license_constant( 'RUPPAMFSC_LICENSE_KEY' );
		$client->infer_license_constant( true );
		$client->allow_db_fallback( true );
	}

	return $client;
}

/* --------------------------------------------------
   SDK Helper Function - Activation
-------------------------------------------------- */
function rup_sell_ind_posts_is_activated_and_licensed() {
	try {
		$client = rup_sell_ind_posts_get_client();
	} catch ( \Throwable $e ) {
		return false;
	}

	if ( ! $client ) {
		return false;
	}

	try {
		$settings   = $client->settings();
		$license    = $client->license();
		$activation = $client->activation();
	} catch ( \Throwable $e ) {
		return false;
	}

	$license_key   = $settings->license_key;
	$activation_id = $settings->activation_id;

	if ( empty( $license_key ) || empty( $activation_id ) ) {
		return false;
	}

	$is_license_valid = $license->is_valid( $license_key );

	if ( is_wp_error( $is_license_valid ) || ! $is_license_valid ) {
		return false;
	}

	$activation_data = $activation->get( $activation_id );

	if ( is_wp_error( $activation_data ) ) {
		return false;
	}

	if ( empty( $activation_data ) || empty( $activation_data->id ) ) {
		return false;
	}

	return true;
}
