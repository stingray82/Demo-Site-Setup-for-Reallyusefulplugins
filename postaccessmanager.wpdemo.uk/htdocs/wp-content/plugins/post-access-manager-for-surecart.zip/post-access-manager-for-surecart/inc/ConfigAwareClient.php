<?php
namespace RUPPAMFSC\Licensing;

if ( ! class_exists( __NAMESPACE__ . '\\Client' ) ) {
	require_once __DIR__ . '/Client.php';
}

/**
 * Config-aware SureCart Client.
 */
class ConfigAwareClient extends Client {
	protected $license_constant = null;
	protected $infer_license_constant = true;
	protected $allow_db_fallback = true;
	private $config_settings;
	private $config_license;

	public function set_license_constant( $constant ) {
		$this->license_constant = is_string( $constant ) ? trim( $constant ) : null;
		return $this;
	}

	public function infer_license_constant( $enabled = true ) {
		$this->infer_license_constant = (bool) $enabled;
		return $this;
	}

	public function allow_db_fallback( $enabled = true ) {
		$this->allow_db_fallback = (bool) $enabled;
		return $this;
	}

	public function get_license_constant() {
		return $this->license_constant;
	}

	public function should_infer_license_constant() {
		return $this->infer_license_constant;
	}

	public function should_allow_db_fallback() {
		return $this->allow_db_fallback;
	}

	public function get_inferred_license_constant() {
		$slug = strtoupper( preg_replace( '/[^A-Za-z0-9]+/', '_', $this->slug ) );
		$slug = trim( $slug, '_' );
		return $slug . '_LICENSE_KEY';
	}

	public function settings() {
		if ( ! class_exists( __NAMESPACE__ . '\\ConfigAwareSettings' ) ) {
			require_once __DIR__ . '/ConfigAwareSettings.php';
		}

		$this->config_settings = $this->config_settings ? $this->config_settings : new ConfigAwareSettings( $this );

		return $this->config_settings;
	}

	public function license() {
		if ( ! class_exists( __NAMESPACE__ . '\\ConfigAwareLicense' ) ) {
			require_once __DIR__ . '/ConfigAwareLicense.php';
		}

		$this->config_license = $this->config_license ? $this->config_license : new ConfigAwareLicense( $this );

		return $this->config_license;
	}
}
