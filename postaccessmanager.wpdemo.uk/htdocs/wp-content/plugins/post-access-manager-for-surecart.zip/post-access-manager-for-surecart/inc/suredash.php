<?php
/**
 * Plugin Name:       SureDash Addon For Post Acccess Manager for SureCart
 * Description:       Sell Access to SureDash Courses/Resources/ Discussions.
 * Version:           0.6
 * Requires at least: 6.5
 * Tested up to:      6.8.3
 * Requires PHP:      8.0
 * Author:            ReallyUsefulPlugins.com
 * Author URI:        https://Reallyusefulplugins.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       suredash-post-access-manager-for-surecart
 * Website:           https://reallyusefulplugins.com
 */
/**
 * SureDash Integration
 *
 * This file connects Post Access Manager for SureCart with SureDash:
 *
 * - Provides a "parent lookup" helper for resources/attachments.
 * - Provides a "can this user view this post or its parent?" helper.
 * - Guards direct /resource/{slug} URLs and runs them through your normal
 *   `the_content` paywall logic (e.g. rup_sell_ind_posts_wsc_filter_protected_content).
 * - Hooks the native SureDash `suredash_get_excerpt` filter so that discussion /
 *   feed cards respect protection and the <!--protected--> marker.
 *
 * Assumes these helpers exist elsewhere in your plugin:
 * - rup_sell_ind_posts_get_protected_post_types()
 * - rup_sell_ind_posts_user_has_all_access()
 * - rup_sell_ind_posts_wsc_filter_protected_content() via `the_content`
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * SureDash: map children (lessons, discussions, resources etc.) to their
 * top-level Course using the belong_to_course meta key.
 *
 * This hooks into the generic rup_sell_ind_posts_find_protecting_parent()
 * helper in the main plugin.
 */
function rup_sell_ind_posts_suredash_find_protecting_parent( int $parent_id, int $post_id ): int {
    // If some other integration already set a parent, respect it.
    if ( $parent_id ) {
        return $parent_id;
    }

    // SureDash children store a course reference in belong_to_course.
    $course_id = (int) get_post_meta( $post_id, 'belong_to_course', true );
    if ( $course_id ) {
        return $course_id;
    }

    return $parent_id;
}
add_filter(
    'rup_sell_ind_posts_find_protecting_parent',
    'rup_sell_ind_posts_suredash_find_protecting_parent',
    10,
    2
);

/**
 * Try to find the "parent" post for a resource/attachment.
 *
 * - If it's a normal WP attachment and has post_parent, use that.
 * - Otherwise, look for a post which has postmeta attachment_id = $post_id
 *   (the SureDash way of linking uploads/resources).
 *
 * This is used by rup_sell_ind_posts_user_can_view() so that:
 *  - If a user owns the parent lesson/resource, they also effectively
 *    "own" the attached file/resource.
 */
if ( ! function_exists( 'rup_sell_ind_posts_find_parent_for_resource' ) ) {
    function rup_sell_ind_posts_find_parent_for_resource( int $post_id ): int {
        $post_id = absint( $post_id );
        if ( ! $post_id ) {
            return 0;
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            return 0;
        }

        // 1) Standard WP attachment parent.
        if ( 'attachment' === $post->post_type && $post->post_parent ) {
            return (int) $post->post_parent;
        }

        // 2) SureDash-style: parent has meta attachment_id = this post ID.
        $protected_types = function_exists( 'rup_sell_ind_posts_get_protected_post_types' )
            ? rup_sell_ind_posts_get_protected_post_types()
            : [];

        $parents = get_posts(
            [
                'post_type'      => $protected_types,
                'meta_key'       => 'attachment_id',
                'meta_value'     => $post_id,
                'posts_per_page' => 1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'post_status'    => 'any',
            ]
        );

        if ( ! empty( $parents ) ) {
            return (int) $parents[0];
        }

        return 0;
    }
}

/**
 * Check if a user can view a post OR a resource whose parent is allowed.
 *
 * This is the core access helper used throughout:
 * - by SureDash excerpt override (for discussions/feed cards),
 * - by the /resource guard (for modal view),
 * - and can be re-used anywhere else.
 *
 * It looks for:
 * - direct access in user_meta 'allowed_posts',
 * - or access via a parent resource/lesson, via rup_sell_ind_posts_find_parent_for_resource().
 */
if ( ! function_exists( 'rup_sell_ind_posts_user_can_view' ) ) {
    function rup_sell_ind_posts_user_can_view( $user_id, $post_id ): bool {
        $user_id = absint( $user_id );
        $post_id = absint( $post_id );

        if ( ! $user_id || ! $post_id ) {
            return false;
        }

        $allowed = get_user_meta( $user_id, 'allowed_posts', true );
        if ( ! is_array( $allowed ) ) {
            $allowed = [];
        }
        $allowed = array_map( 'intval', $allowed );

        // 1) Direct access to this post.
        if ( in_array( $post_id, $allowed, true ) ) {
            return true;
        }

        // 2) Attachments/resources: parent via post_parent or attachment_id meta.
        $parent_id = rup_sell_ind_posts_find_parent_for_resource( $post_id );
        if ( $parent_id && in_array( $parent_id, $allowed, true ) ) {
            return true;
        }

        // 3) Generic protecting parent (Course / Space / Portal etc.).
        $protecting_parent_id = 0;

        if ( function_exists( 'rup_sell_ind_posts_get_effective_protecting_parent' ) ) {
            $protecting_parent_id = rup_sell_ind_posts_get_effective_protecting_parent( $post_id );
        } elseif ( function_exists( 'rup_sell_ind_posts_find_protecting_parent' ) ) {
            $protecting_parent_id = (int) rup_sell_ind_posts_find_protecting_parent( $post_id );
        }

        if ( $protecting_parent_id && in_array( $protecting_parent_id, $allowed, true ) ) {
            // Only grant access if the parent is configured to secure children.
            $secures_children = ( get_post_meta(
                $protecting_parent_id,
                '_post_access_parent_secures_children',
                true
            ) === '1' );

            if ( $secures_children ) {
                return true;
            }
        }

        return false;
    }
}



/**
 * Guard SureDash resource pages like /resource/{slug}.
 *
 * For users WITHOUT access:
 *  - Find the underlying protected WP post (lesson/resource/etc.).
 *  - Render that post's content through the normal `the_content` filter
 *    (which includes your paywall logic: e.g. rup_sell_ind_posts_wsc_filter_protected_content),
 *  - Output it inside a minimal HTML shell – this works nicely when SureDash opens
 *    the URL inside a modal/iframe.
 *
 * For users WITH access:
 *  - Do nothing, SureDash handles the resource normally.
 *
 * WordPress hook used:
 * - template_redirect (core WP) – see WP core for origin.
 */
function rup_sell_ind_posts_guard_resource_page() {
    if ( is_admin() ) {
        return;
    }

    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    if ( false === strpos( $request_uri, '/resource/' ) ) {
        // Not a SureDash resource URL; do nothing.
        return;
    }

    // Extract the slug after /resource/.
    $path     = parse_url( $request_uri, PHP_URL_PATH );
    $segments = explode( '/', trim( (string) $path, '/' ) );
    $slug     = '';

    foreach ( $segments as $idx => $segment ) {
        if ( 'resource' === $segment && isset( $segments[ $idx + 1 ] ) ) {
            $slug = sanitize_title( $segments[ $idx + 1 ] );
            break;
        }
    }

    if ( '' === $slug ) {
        return;
    }

    // Find the underlying WP post that represents this resource/lesson/event/etc.
    $protected_types = function_exists( 'rup_sell_ind_posts_get_protected_post_types' )
        ? rup_sell_ind_posts_get_protected_post_types()
        : [];

    $post_obj = get_page_by_path( $slug, OBJECT, $protected_types );

    if ( ! $post_obj ) {
        // No matching post – allow SureDash to handle as usual.
        return;
    }

        $post_id = (int) $post_obj->ID;

    if ( function_exists( 'rup_sell_ind_posts_is_post_protected' ) ) {
        $is_protected = rup_sell_ind_posts_is_post_protected( $post_id );
    } else {
        $is_protected = ( get_post_meta( $post_id, '_post_access_protected', true ) === '1' );
    }

    if ( ! $is_protected ) {
        // Underlying post is not protected in any way – let it through.
        return;
    }


    $user_id = get_current_user_id();

    // All-access users always allowed (e.g. managers / all-access pass).
    if ( function_exists( 'rup_sell_ind_posts_user_has_all_access' ) && rup_sell_ind_posts_user_has_all_access( $user_id ) ) {
        return;
    }

    // If user can view this post via our helper, let SureDash handle normally.
    if ( rup_sell_ind_posts_user_can_view( $user_id, $post_id ) ) {
        return;
    }

    // ----------------------------------------------------------------------
    // At this point: resource page is protected AND user does not have access.
    //
    // We now:
    //   - pretend the parent lesson/resource is the current post,
    //   - run its content through the normal `the_content` filter
    //     (which triggers your paywall logic for posts, lessons, events, etc.),
    //   - output that inside a simple HTML shell (great for SureDash modals).
    // ----------------------------------------------------------------------

    global $post, $wp_query;

    $old_post    = $post ?? null;
    $old_query   = $wp_query ?? null;
    $lesson_post = get_post( $post_id );

    if ( ! $lesson_post ) {
        return;
    }

    // Fake a singular context for the filter.
    $post = $lesson_post;
    setup_postdata( $post );

    if ( $wp_query instanceof WP_Query ) {
        $wp_query->is_singular = true;
    }

    // This will call your `the_content` paywall filter(s)
    // plus any theme/plugin content filters.
    $rendered_content = apply_filters( 'the_content', $lesson_post->post_content );

    // Reset globals.
    wp_reset_postdata();
    $post     = $old_post;
    $wp_query = $old_query;

    nocache_headers();
    ?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <title><?php esc_html_e( 'Access required', 'post-access-manager-for-surecart' ); ?></title>
        <style>
            body {
                margin: 0;
                padding: 24px;
                font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                background: #f7f7f9;
                color: #222;
            }
            .pam-lock-wrapper {
                max-width: 720px;
                margin: 0 auto;
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.06);
                padding: 20px 24px;
            }
            .pam-lock-wrapper .protected-content-message {
                margin-top: 16px;
            }
        </style>
    </head>
    <body>
        <div class="pam-lock-wrapper">
            <?php
            // This includes your preview + purchase prompt from the normal filter.
            echo $rendered_content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            ?>
        </div>
    </body>
    </html>
    <?php
    exit;
}
add_action(
    'template_redirect',
    'rup_sell_ind_posts_guard_resource_page',
    8
); // WordPress core action: see WP core template_redirect docs.

/**
 * For protected posts in SureDash discussions / feeds:
 *
 * Hooks the native SureDash excerpt filter:
 *   - Defined in suredash/inc/functions/functions.php:
 *       function suredash_get_excerpt( $post_id, $length = 20 ) { ... }
 *       return apply_filters( 'suredash_get_excerpt', $text, $post_id );
 *
 * Behaviour:
 *  - If user has access → keep SureDash's excerpt.
 *  - If post is protected + has <!-- protected --> → show only text before marker.
 *  - If post is protected + NO marker          → show a filterable locked message.
 */
function rup_sell_ind_posts_override_suredash_excerpt( $text, $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id ) {
        return $text;
    }

    $post = get_post( $post_id );
    if ( ! $post ) {
        return $text;
    }

        // Respect per-post OR parent-based protection.
    if ( function_exists( 'rup_sell_ind_posts_is_post_protected' ) ) {
        $is_protected = rup_sell_ind_posts_is_post_protected( $post_id );
    } else {
        $is_protected = ( get_post_meta( $post_id, '_post_access_protected', true ) === '1' );
    }

    if ( ! $is_protected ) {
        // Not protected in any way → leave SureDash's excerpt alone.
        return $text;
    }


    $user_id = get_current_user_id();

    // Owners / all-access still see the normal excerpt.
    if (
        rup_sell_ind_posts_user_can_view( $user_id, $post_id ) ||
        ( function_exists( 'rup_sell_ind_posts_user_has_all_access' ) && rup_sell_ind_posts_user_has_all_access( $user_id ) )
    ) {
        return $text;
    }

    // User does NOT have full access → apply <!-- protected --> logic.
    $raw_content = (string) $post->post_content;

    // Tolerant match: <!--protected-->, <!-- protected -->, <!--  Protected  -->, etc.
    $marker_regex = '/<!--\s*protected\s*-->/i';

    if ( ! preg_match( $marker_regex, $raw_content ) ) {
        // No marker = fully protected → show locked message (filterable).
        $locked_message = apply_filters(
            'rup_sell_ind_posts_locked_suredash_excerpt_message',
            'This Post is locked. Click to upgrade for full access.',
            $post_id
        );

        return esc_html( $locked_message );
    }

    // Marker exists: use only the content BEFORE it as the preview.
    $parts   = preg_split( $marker_regex, $raw_content, 2 );
    $preview = isset( $parts[0] ) ? $parts[0] : '';

    // Clean and trim for card display.
    $preview = wp_strip_all_tags( $preview );
    $preview = wp_trim_words( $preview, 20, '…' );

    return $preview;
}
add_filter(
    'suredash_get_excerpt',
    'rup_sell_ind_posts_override_suredash_excerpt',
    10,
    2
);
; // SureDash filter from suredash/inc/functions/functions.php :: suredash_get_excerpt().



/**
 * Protect SureDash single EVENT views.
 *
 * For locked users:
 *  - FIRST call (header): strip the "Join virtual event" link (target="_blank")
 *    but KEEP the "Return to Events" link and other header content.
 *  - SECOND call (main content): show your paywall box using the REAL
 *    Purchase Access URL (same logic as the main paywall filter).
 *
 * Origin of the filter:
 * - suredash/Core/Shortcodes/single-endpoint-content.php
 *   render_single_endpoint_content() and render_single_content() both end with:
 *       return apply_filters( 'suredashboard_single_view_content', $content );
 */
function rup_sell_ind_posts_protect_suredash_single_view_content( $content ) {
    static $event_view_call_count = 0;

    if ( is_admin() ) {
        return $content;
    }

    $post_id = get_the_ID();
    if ( ! $post_id ) {
        return $content;
    }

    /**
     * 🔍 Only run on EVENT endpoints
     *
     * From SureDash:
     *   suredash_get_community_content_slug( 'event' ) returns the slug
     *   used in URLs (eg. /portal/.../event/...).
     */
    $event_slug = function_exists( 'suredash_get_community_content_slug' )
        ? suredash_get_community_content_slug( 'event' )
        : 'event';

    $path = isset( $_SERVER['REQUEST_URI'] )
        ? (string) parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH )
        : '';

    if ( $event_slug && $path ) {
        $event_slug = trim( $event_slug, '/' );
        if ( false === strpos( $path, '/' . $event_slug . '/' ) ) {
            // Not an event URL → leave everything alone.
            return $content;
        }
    } else {
        // Can't reliably detect context → bail.
        return $content;
    }

    // From here on: EVENT views only.
    // Respect protection flag.
        if ( ! function_exists( 'rup_sell_ind_posts_is_post_protected' ) ) {
        return $content;
    }

    $is_protected = rup_sell_ind_posts_is_post_protected( $post_id );
    if ( ! $is_protected ) {
        // Not protected in any way: show everything
        return $content;
    }

    $user_id = get_current_user_id();

    // Owners / all-access users still see full event layout.
    if (
        rup_sell_ind_posts_user_can_view( $user_id, $post_id ) ||
        ( function_exists( 'rup_sell_ind_posts_user_has_all_access' )
          && rup_sell_ind_posts_user_has_all_access( $user_id ) )
    ) {
        return $content;
    }

    // Count how many times SureDash asks for single view content.
    $event_view_call_count++;

    /**
     * FIRST CALL: HEADER AREA
     * -----------------------
     * Remove the "Join virtual event" link, identified by target="_blank",
     * but keep the "Return to Events" link and the rest of the header.
     */
    if ( 1 === $event_view_call_count ) {

        // Optional debug: log header HTML once while tweaking.
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $log_snippet = substr( $content, 0, 8000 );
            //error_log( "=== PAM EVENT HEADER RAW (post {$post_id}) ===\n" . $log_snippet . "\n=== END HEADER RAW ===" );
        }

        // Remove ANY <a> tag with target="_blank" (language-independent).
        $clean = preg_replace(
            '#<a\b[^>]*target\s*=\s*["\']_blank["\'][^>]*>.*?</a>#is',
            '',
            $content
        );

        // Tidy up extra whitespace if the removed link left gaps.
        $clean = preg_replace( '/\s{2,}/', ' ', $clean );
        $clean = trim( $clean );

        return $clean;
    }

    /**
     * SECOND (and later) CALLS: MAIN CONTENT AREA
     * -------------------------------------------
     * Replace the SureDash event body with a single lock box that uses
     * the SAME purchase URL as your main paywall, and then pass that
     * through the rup_sell_ind_posts_wsc_protected_content_output filter.
     */

    $event_post = get_post( $post_id );
    if ( ! $event_post ) {
        return $content;
    }

    // Build the REAL purchase URL exactly like the main paywall does.
    $raw_link = get_post_meta( $post_id, '_purchase_access_link_raw', true );
    if ( ! $raw_link ) {
        $raw_link = '/buy-access'; // Fallback if no custom link is set.
    }

    $param_key    = apply_filters( 'rup_sell_ind_posts_param_key', 'post_id' );
    $purchase_url = add_query_arg( $param_key, $post_id, $raw_link );
    $purchase_url = esc_url( $purchase_url );

    if ( $purchase_url ) {
        $link_html = sprintf(
            '<a href="%s" style="color:#2563eb; text-decoration:underline;">%s</a>',
            $purchase_url,
            esc_html__( 'Purchase Access', 'post-access-manager-for-surecart' )
        );
    } else {
        // Should rarely happen, but keep a graceful fallback.
        $link_html = esc_html__( 'Purchase Access', 'post-access-manager-for-surecart' );
    }

    // Simple default locked box (used as a fallback / base for the filter).
    $locked_box = sprintf(
        '<div class="pam-locked-event" style="max-width:720px;margin:24px auto;padding:24px 20px;border-radius:8px;border:1px solid #e5e7eb;background:#f9fafb;text-align:left;">
            <p style="margin:0;font-size:clamp(14px, 0.875rem + ((1vw - 3.2px) * 0.392), 18px);line-height:1.6;color:#111827;">
                %s %s
            </p>
        </div>',
        esc_html__( 'This content is protected.', 'post-access-manager-for-surecart' ),
        $link_html
    );
    

    /**
     * 🔁 NEW: Run this through the same protected-content filter as posts.
     *
     * This lets selective_custom_protected_content_output (or any other
     * callbacks on rup_sell_ind_posts_wsc_protected_content_output)
     * completely override or enhance the locked box.
     */
    $locked_box = apply_filters(
        'rup_sell_ind_posts_wsc_protected_content_output',
        $locked_box,   // Default/fallback HTML.
        $post_id,
        $purchase_url  // Same as $purchase_link in your other filter.
    );
    
    return $locked_box;
    
}



add_filter(
    'suredashboard_single_view_content',
    'rup_sell_ind_posts_protect_suredash_single_view_content',
    10,
    1
);


/* Clear the Comment / Like and Share Bar if you can't do it
*/

/**
 * Check whether a user should be allowed to "interact" with a post:
 * comment, like, etc.
 *
 * Rules:
 *  - If post is not protected (directly OR via a securing parent) -> true
 *  - If user has All Access -> true
 *  - If user can view the post (via your helper) -> true
 *  - Otherwise -> false
 */
if ( ! function_exists( 'rup_sell_ind_posts_user_can_interact' ) ) {
    function rup_sell_ind_posts_user_can_interact( int $post_id, int $user_id = 0 ): bool {
        $post_id = absint( $post_id );
        if ( ! $post_id ) {
            return false;
        }

        $user_id = $user_id ?: get_current_user_id();

        // If not a protected post type, allow interaction.
        $post            = get_post( $post_id );
        $protected_types = rup_sell_ind_posts_get_protected_post_types();

        if ( ! $post || ! in_array( $post->post_type, $protected_types, true ) ) {
            return true;
        }

        // Use central helper so parent-secured children are treated as protected too.
        if ( function_exists( 'rup_sell_ind_posts_is_post_protected' ) ) {
            $is_protected = rup_sell_ind_posts_is_post_protected( $post_id );
        } else {
            // Fallback to direct meta check if helper isn't available for some reason.
            $is_protected = ( get_post_meta( $post_id, '_post_access_protected', true ) === '1' );
        }

        // If this post is not protected in any way, allow interaction.
        if ( ! $is_protected ) {
            return true;
        }

        // All-access bypass.
        if (
            function_exists( 'rup_sell_ind_posts_user_has_all_access' )
            && rup_sell_ind_posts_user_has_all_access( $user_id )
        ) {
            return true;
        }

        // If they can view the post (owns it / securing parent, etc.), allow interaction.
        if ( rup_sell_ind_posts_user_can_view( $user_id, $post_id ) ) {
            return true;
        }

        // Otherwise, they should not be able to interact.
        return false;
    }
}





/**
 * Close comments on protected posts for users who don't have access.
 */
function rup_sell_ind_posts_restrict_comments_open( $open, $post_id ) {
    // If comments are already closed, respect that.
    if ( ! $open ) {
        return $open;
    }

    if ( ! rup_sell_ind_posts_user_can_interact( (int) $post_id ) ) {
        // Mark this post as "locked" for interactions too.
        $post_id = (int) $post_id;
        if ( ! isset( $GLOBALS['rup_sell_ind_posts_hide_interactions'] ) ) {
            $GLOBALS['rup_sell_ind_posts_hide_interactions'] = [];
        }
        $GLOBALS['rup_sell_ind_posts_hide_interactions'][ $post_id ] = true;

        return false;
    }

    return $open;
}
add_filter( 'comments_open', 'rup_sell_ind_posts_restrict_comments_open', 10, 2 );


/**
 * Hide comments list from users who don't have access.
 */
function rup_sell_ind_posts_hide_comments_for_locked_users( array $comments, $post_id ): array {
    if ( ! rup_sell_ind_posts_user_can_interact( (int) $post_id ) ) {
        // Mark this post as "locked" for interactions too.
        $post_id = (int) $post_id;
        if ( ! isset( $GLOBALS['rup_sell_ind_posts_hide_interactions'] ) ) {
            $GLOBALS['rup_sell_ind_posts_hide_interactions'] = [];
        }
        $GLOBALS['rup_sell_ind_posts_hide_interactions'][ $post_id ] = true;

        return []; // no comments visible
    }

    return $comments;
}
add_filter( 'comments_array', 'rup_sell_ind_posts_hide_comments_for_locked_users', 10, 2 );



/**
 * Hide the entire SureDash interaction bar (likes / comments / share / bookmark)
 * on any post where there is NO comment button rendered.
 *
 * SureDash already decides when to show the comment button, so this piggy-backs
 * 
 * on that logic: if the button isn't there, we hide the whole bar.
 */
function rup_sell_ind_posts_hide_portal_comment_for_locked_users() {
    if ( is_admin() ) {
        return;
    }

    ?>
    <style>
        /* 
         * If a portal-comments-wrapper does NOT contain a comment reaction button,
         * hide the whole interaction bar.
         *
         * Works on feed cards and single views.
         */
        .portal-comments-wrapper:not(:has(button[data-reaction_type="comment"])) {
            display: none !important;
        }
    </style>
    <?php
}
add_action( 'wp_head', 'rup_sell_ind_posts_hide_portal_comment_for_locked_users', 99 );





/**
 * Rewire SureDash event list "Join Now" buttons ONLY for
 * events that are protected AND that this user cannot view.
 *
 * For those locked events:
 *   - "Join Now" sends user to the internal event page
 *     (the card's <a href="...">), which is paywalled.
 *
 * For open events:
 *   - "Join Now" continues to use SureDash's normal
 *     external join behaviour.
 */
function rup_sell_ind_posts_fix_event_list_join_button() {
    if ( is_admin() ) {
        return;
    }

    $user_id = get_current_user_id();

    // Build a list of locked post IDs for this user.
    $locked_ids = [];

    if ( function_exists( 'rup_sell_ind_posts_get_protected_post_types' ) ) {
        $protected_types = (array) rup_sell_ind_posts_get_protected_post_types();
    } else {
        $protected_types = get_post_types( [ 'public' => true ] );
    }

    if ( ! empty( $protected_types ) ) {
        $maybe_locked = get_posts(
            [
                'post_type'      => $protected_types,
                'post_status'    => 'any',
                'meta_key'       => '_post_access_protected',
                'meta_value'     => '1',
                'fields'         => 'ids',
                'posts_per_page' => -1,
                'no_found_rows'  => true,
            ]
        );

        if ( ! empty( $maybe_locked ) ) {
            foreach ( $maybe_locked as $pid ) {
                $pid = (int) $pid;

                // If user has all-access, skip – it's not "locked" for them.
                if (
                    function_exists( 'rup_sell_ind_posts_user_has_all_access' )
                    && rup_sell_ind_posts_user_has_all_access( $user_id )
                ) {
                    break; // user can see everything anyway
                }

                // If user can view this post (owns it / parent etc.), skip.
                if ( function_exists( 'rup_sell_ind_posts_user_can_view' ) &&
                     rup_sell_ind_posts_user_can_view( $user_id, $pid ) ) {
                    continue;
                }

                $locked_ids[] = $pid;
            }
        }
    }

    $locked_ids = array_values( array_unique( array_map( 'intval', $locked_ids ) ) );
    $json_ids   = wp_json_encode( $locked_ids );
    ?>
    <script>
    (function () {
        // IDs of posts that are protected AND not viewable for this user.
        var pamLockedEventIds = <?php echo $json_ids ? $json_ids : '[]'; ?>;

        function isLockedEventId(id) {
            id = parseInt(id, 10);
            if (!id || !Array.isArray(pamLockedEventIds)) return false;
            return pamLockedEventIds.indexOf(id) !== -1;
        }

        function wireEventJoinButtons(root) {
            var scope   = root || document;
            var buttons = scope.querySelectorAll(
                'button.portal-button[data-integration="events"][data-post_id]'
            );

            buttons.forEach(function (btn) {
                var postId = parseInt(btn.getAttribute('data-post_id') || '0', 10);
                if (!postId || !isLockedEventId(postId)) {
                    // Not a locked event for THIS user → leave default behaviour.
                    return;
                }

                // Already patched?
                if (btn.dataset.pamJoinPatched === '1') {
                    return;
                }

                var wrapper = btn.closest('a.portal-list-wrapper');
                if (!wrapper || !wrapper.href) {
                    return;
                }

                btn.dataset.pamJoinPatched = '1';

                // Remove external join behaviour.
                btn.removeAttribute('data-href');
                btn.removeAttribute('data-target');

                // New behaviour: go to internal event page (paywalled).
                btn.addEventListener('click', function (ev) {
                    ev.preventDefault();
                    if (typeof ev.stopImmediatePropagation === 'function') {
                        ev.stopImmediatePropagation();
                    }
                    window.location.href = wrapper.href;
                });
            });
        }

        document.addEventListener('DOMContentLoaded', function () {
            wireEventJoinButtons(document);
        });

        // Optional hook if SureDash re-renders via JS:
        document.addEventListener('pam_rewire_event_buttons', function () {
            wireEventJoinButtons(document);
        });
    })();
    </script>
    <?php
}
add_action( 'wp_footer', 'rup_sell_ind_posts_fix_event_list_join_button', 20 );

// Now We Secure Discussions This allows us to protect Parents 

/**
 * Find a "protecting parent" via term meta.
 *
 * For any term attached to the post:
 *  - If it has _post_access_parent_post_id, use that.
 *  - Otherwise, if it has space_id, use that.
 *
 * This plugs into the generic rup_sell_ind_posts_find_protecting_parent()
 * system, alongside belong_to_course etc.
 */
function rup_sell_ind_posts_term_based_protecting_parent( int $parent_id, int $post_id ): int {
    // If some other integration already found a parent, respect it.
    if ( $parent_id ) {
        return $parent_id;
    }

    $post_id = absint( $post_id );
    if ( ! $post_id ) {
        return 0;
    }

    $post = get_post( $post_id );
    if ( ! $post ) {
        return 0;
    }

    // Get all taxonomies attached to this post type.
    $taxonomies = get_object_taxonomies( $post->post_type, 'names' );
    if ( empty( $taxonomies ) ) {
        return 0;
    }

    foreach ( $taxonomies as $taxonomy ) {
        $terms = get_the_terms( $post_id, $taxonomy );

        if ( empty( $terms ) || is_wp_error( $terms ) ) {
            continue;
        }

        foreach ( $terms as $term ) {
            // 1st: explicit override if you ever want it
            $maybe_parent = (int) get_term_meta( $term->term_id, '_post_access_parent_post_id', true );

            // Fallback: SureDash "space" mapping
            if ( ! $maybe_parent ) {
                $maybe_parent = (int) get_term_meta( $term->term_id, 'space_id', true );
            }

            if ( $maybe_parent > 0 ) {
                return $maybe_parent;
            }
        }
    }

    return 0;
}
add_filter(
    'rup_sell_ind_posts_find_protecting_parent',
    'rup_sell_ind_posts_term_based_protecting_parent',
    20,
    2
);

// Now we protect Resouces / Events / etc
// I expect there to be additional customisation here:

/**
 * Space-based protecting parent for content inside a Space.
 *
 * Any post with:
 *  - content_type = resource | event | ...
 *  - space_id     = {space post ID}
 *
 * will treat that space_id as its protecting parent.
 */
function rup_sell_ind_posts_space_content_protecting_parent( int $parent_id, int $post_id ): int {
    // If another integration already provided a parent, respect it.
    if ( $parent_id ) {
        return $parent_id;
    }

    $post_id = absint( $post_id );
    if ( ! $post_id ) {
        return 0;
    }

    // Only act on specific content types that live inside a space.
    $content_type   = get_post_meta( $post_id, 'content_type', true );
    $handled_types  = array( 'resource', 'event' ); // add more if needed

    if ( ! in_array( $content_type, $handled_types, true ) ) {
        return 0;
    }

    // Use space_id as the protecting parent post
    $space_id = (int) get_post_meta( $post_id, 'space_id', true );
    if ( $space_id > 0 ) {
        return $space_id;
    }

    return 0;
}
add_filter(
    'rup_sell_ind_posts_find_protecting_parent',
    'rup_sell_ind_posts_space_content_protecting_parent',
    15, // after belong_to_course (10), before term-based (20)
    2
);



//Now we need to work on Collections
// We need to protect there children and grandchildren

/**
 * Get the "effective" protecting parent for a post.
 *
 * Debug version with extensive error_log output.
 */
if ( ! function_exists( 'rup_sell_ind_posts_get_effective_protecting_parent' ) ) {
    function rup_sell_ind_posts_get_effective_protecting_parent( int $post_id ): int {

        $post_id = absint( $post_id );
        error_log("---- EFFECTIVE PARENT CHECK for Post {$post_id} ----");

        if ( ! $post_id ) {
            error_log(" ❌ Invalid post ID");
            return 0;
        }

        $base_parent_id = 0;

        // 1) Ask all built-in resolvers first
        if ( function_exists( 'rup_sell_ind_posts_find_protecting_parent' ) ) {
            $base_parent_id = (int) rup_sell_ind_posts_find_protecting_parent( $post_id );
            error_log(" ✔ Base parent from resolver: {$base_parent_id}");
        } else {
            error_log(" ⚠ Parent resolver function rup_sell_ind_posts_find_protecting_parent() missing");
        }

        // 2) If we already have a parent, see if that parent is inside ANY Portal's collection_space_ids
        if ( $base_parent_id && function_exists( 'rup_sell_ind_posts_find_portal_for_space' ) ) {

            error_log(" → Checking if base parent {$base_parent_id} lives inside a Portal");

            $portal_id = (int) rup_sell_ind_posts_find_portal_for_space( $base_parent_id );

            if ( $portal_id ) {
                error_log(" ✔ Parent {$base_parent_id} belongs to Portal {$portal_id} → promoting parent to Portal");
                return $portal_id;
            }

            error_log(" ❌ Base parent {$base_parent_id} does NOT belong to any portal → returning base parent");
            return $base_parent_id;
        }

        if ( $base_parent_id ) {
            error_log(" ⚠ Base parent {$base_parent_id} exists but portal lookup function missing");
            return $base_parent_id;
        }

        // 3) No base parent → maybe THIS POST itself is inside a Portal's collection_space_ids
        error_log(" → No base parent, checking if this post {$post_id} belongs directly to a Portal");

        if ( function_exists( 'rup_sell_ind_posts_find_portal_for_space' ) ) {

            $portal_id = (int) rup_sell_ind_posts_find_portal_for_space( $post_id );

            if ( $portal_id ) {
                error_log(" ✔ Post {$post_id} belongs to Portal {$portal_id} → using Portal as parent");
                return $portal_id;
            }

            error_log(" ❌ Post {$post_id} does NOT belong to any Portal");
        } else {
            error_log(" ⚠ Portal lookup function rup_sell_ind_posts_find_portal_for_space() missing");
        }

        // 4) Nothing found
        error_log(" ❌ No effective parent found. Returning {$base_parent_id}");
        return $base_parent_id;
    }
}


/**
 * Find a Portal (collection) that contains a given space.
 *
 * Portal meta example:
 *  - integration          = collection
 *  - collection_space_ids = a:2:{i:0;s:2:"64";i:1;s:2:"32";}
 *
 * We look for a 'portal' post where collection_space_ids contains "SPACE_ID".
 */
if ( ! function_exists( 'rup_sell_ind_posts_find_portal_for_space' ) ) {
    function rup_sell_ind_posts_find_portal_for_space( int $space_id ): int {
        $space_id = absint( $space_id );
        if ( ! $space_id ) {
            error_log( 'find_portal_for_space: invalid space_id ' . $space_id );
            return 0;
        }

        // Simple object cache so we don't query repeatedly in a single request
        $cache_key = 'portal_for_space_' . $space_id;
        $cached    = wp_cache_get( $cache_key, 'rup_pam' );
        if ( false !== $cached ) {
            error_log( "find_portal_for_space: cache hit for space {$space_id} → portal {$cached}" );
            return (int) $cached;
        }

        error_log( "find_portal_for_space: querying portal for space {$space_id}" );

        // Search for a portal that is a "collection" and contains this space ID.
        $posts = get_posts(
            array(
                'post_type'      => 'portal',
                'post_status'    => 'publish',
                'posts_per_page' => 1,
                'fields'         => 'ids',
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key'   => 'integration',
                        'value' => 'collection',
                    ),
                    array(
                        'key'     => 'collection_space_ids',
                        // collection_space_ids is a serialized array; match the quoted ID
                        'value'   => '"' . $space_id . '"',
                        'compare' => 'LIKE',
                    ),
                ),
            )
        );

        $portal_id = $posts ? (int) $posts[0] : 0;

        if ( $portal_id ) {
            error_log( "find_portal_for_space: found portal {$portal_id} for space {$space_id}" );
        } else {
            error_log( "find_portal_for_space: no portal found for space {$space_id}" );
        }

        wp_cache_set( $cache_key, $portal_id, 'rup_pam', MINUTE_IN_SECONDS );

        return $portal_id;
    }
}

/**
 * Get the effective purchase link for a post with strict priority:
 *   1) This post (self)
 *   2) Direct protecting parent (e.g. Course)
 *   3) Grandparent / Portal (if any)
 *
 * "Purchaseable" here means: has _purchase_access_link_raw set.
 */
function rup_sell_ind_posts_get_effective_purchase_link( int $post_id, string $default = '/buy-access' ): string {
    $post_id   = absint( $post_id );
    $param_key = apply_filters( 'rup_sell_ind_posts_param_key', 'post_id' );

    if ( ! $post_id ) {
        return esc_url( add_query_arg( $param_key, 0, $default ) );
    }

    // --------------------------------------------------
    // 1) SELF – if this post has a raw link, it always wins.
    // --------------------------------------------------
    $raw_self = trim( (string) get_post_meta( $post_id, '_purchase_access_link_raw', true ) );
    if ( $raw_self !== '' ) {
        $url = add_query_arg( $param_key, $post_id, $raw_self );
        return esc_url( $url );
    }

    // --------------------------------------------------
    // 2) DIRECT PARENT – one level up (e.g. Course for Lesson).
    // --------------------------------------------------
    $parent_id = 0;

    if ( function_exists( 'rup_sell_ind_posts_find_protecting_parent' ) ) {
        // Core helper: child → protecting parent (Course etc.).
        $parent_id = (int) rup_sell_ind_posts_find_protecting_parent( $post_id );
    }

    if ( $parent_id && $parent_id !== $post_id ) {
        $raw_parent = trim( (string) get_post_meta( $parent_id, '_purchase_access_link_raw', true ) );

        if ( $raw_parent !== '' ) {
            // Parent is individually purchaseable → wins over any Portal.
            $url = add_query_arg( $param_key, $parent_id, $raw_parent );
            return esc_url( $url );
        }
    }

    // --------------------------------------------------
    // 3) GRANDPARENT / PORTAL – only after parent has had its chance.
    //    We try to find "one level above the parent" OR a Portal
    //    using the existing effective-parent helper.
    // --------------------------------------------------
    $grandparent_id = 0;

    // 3a) If we have a parent, see if THAT has a parent (grandparent).
    if ( $parent_id && function_exists( 'rup_sell_ind_posts_find_protecting_parent' ) ) {
        $maybe_gp = (int) rup_sell_ind_posts_find_protecting_parent( $parent_id );
        if ( $maybe_gp && $maybe_gp !== $parent_id && $maybe_gp !== $post_id ) {
            $grandparent_id = $maybe_gp;
        }
    }

    // 3b) If still nothing, fall back to the "effective" helper,
    //     but treat it ONLY as a grandparent candidate.
    if ( ! $grandparent_id && function_exists( 'rup_sell_ind_posts_get_effective_protecting_parent' ) ) {
        $maybe_gp = (int) rup_sell_ind_posts_get_effective_protecting_parent( $parent_id ?: $post_id );
        if ( $maybe_gp && $maybe_gp !== $parent_id && $maybe_gp !== $post_id ) {
            $grandparent_id = $maybe_gp;
        }
    }

    if ( $grandparent_id ) {
        $raw_gp = trim( (string) get_post_meta( $grandparent_id, '_purchase_access_link_raw', true ) );

        if ( $raw_gp !== '' ) {
            $url = add_query_arg( $param_key, $grandparent_id, $raw_gp );
            return esc_url( $url );
        }
    }

    // --------------------------------------------------
    // 4) Fallback: use the "best context" we know with the default URL.
    //    - Prefer grandparent if one exists,
    //    - else parent,
    //    - else self.
    // --------------------------------------------------
    $owner_id = $grandparent_id ?: ( $parent_id ?: $post_id );

    $url = add_query_arg( $param_key, $owner_id, $default );
    return esc_url( $url );
}




if ( ! function_exists( 'rup_sell_ind_posts_get_layout_map' ) ) {
    /**
     * Central layout registry.
     *
     * Returns an array like:
     *  [
     *      123 => [ 'type' => 'pattern',   'value' => 'my-pattern-slug' ],
     *      456 => [ 'type' => 'shortcode', 'value' => '[bricks_template id="86"]' ],
     *      789 => [ 'type' => 'raw',       'value' => '<div>…</div>' ],
     *  ]
     *
     * Core itself doesn’t add anything here – site code & addons do it
     * via the `rup_sell_ind_posts_layout_map` filter.
     */
    function rup_sell_ind_posts_get_layout_map(): array {
        $map = [];

        /**
         * Allow addons & snippets to register custom layouts.
         *
         * This is ONLY for display (which template/HTML to show), not link logic.
         *
         * @param array $map Layout map keyed by post ID.
         */
        $map = apply_filters( 'rup_sell_ind_posts_layout_map', $map );

        return is_array( $map ) ? $map : [];
    }
}


// ---------------------------------------------------------------------
// Meta box: "Parent secures children"
// When checked on a parent post (e.g. Course), owning that post can
// unlock any children that point to it via rup_sell_ind_posts_find_protecting_parent().
// ---------------------------------------------------------------------

function rup_sell_ind_posts_add_parent_secures_children_meta_box() {
    if ( ! function_exists( 'rup_sell_ind_posts_is_activated_and_licensed' )
        || ! rup_sell_ind_posts_is_activated_and_licensed()
    ) {
        if ( function_exists( 'rup_sell_ind_posts_log_debug' ) ) {
            rup_sell_ind_posts_log_debug( 'Error: Please activate license via the appropriate activation page.' );
        }
        return;
    }

    add_meta_box(
        'parent_secures_children_meta_box',
        __( 'Parent Secures Children', 'post-access-manager-for-surecart' ),
        'rup_sell_ind_posts_render_parent_secures_children_meta_box',
        rup_sell_ind_posts_get_protected_post_types(),
        'side',
        'default'
    );
}
add_action( 'add_meta_boxes', 'rup_sell_ind_posts_add_parent_secures_children_meta_box' );

function rup_sell_ind_posts_render_parent_secures_children_meta_box( $post ) {
    $value = get_post_meta( $post->ID, '_post_access_parent_secures_children', true );
    ?>
    <p>
        <label for="post_access_parent_secures_children_checkbox">
            <input type="checkbox"
                   name="post_access_parent_secures_children_checkbox"
                   id="post_access_parent_secures_children_checkbox"
                   value="1" <?php checked( $value, '1' ); ?> />
            <?php esc_html_e( 'Owning this post also unlocks its linked children.', 'post-access-manager-for-surecart' ); ?>
        </label>
    </p>
    <p class="description">
        <?php esc_html_e( 'Used by integrations (e.g. SureDash) where children reference this post via a meta field like belong_to_course.', 'post-access-manager-for-surecart' ); ?>
    </p>
    <?php
}

function rup_sell_ind_posts_save_parent_secures_children_meta_box( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( isset( $_POST['post_access_parent_secures_children_checkbox'] ) ) {
        update_post_meta( $post_id, '_post_access_parent_secures_children', '1' );
    } else {
        delete_post_meta( $post_id, '_post_access_parent_secures_children' );
    }
}
add_action( 'save_post', 'rup_sell_ind_posts_save_parent_secures_children_meta_box' );
