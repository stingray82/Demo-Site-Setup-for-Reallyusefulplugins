<?php


if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



/**
 * Shortcode to list posts a user has purchased access to (or show All Access status).
 * Usage: place `[user_access_list]` in any page or post.
 */
function rup_shortcode_user_access_list( $atts ) {
    if ( ! is_user_logged_in() ) {
        return '<p>Please <a href="' . wp_login_url( get_permalink() ) . '">log in</a> to view your purchased content.</p>';
    }

    $user_id = get_current_user_id();

    // Query allowed posts
    $allowed = get_user_meta( $user_id, 'allowed_posts', true );
    $has_individual = ! empty( $allowed ) && is_array( $allowed );

    // Start output with title
    $output  = '<h2 class="rup-access-title">Purchased Post Access</h2>';

    // All-Access users
    if ( get_user_meta( $user_id, 'all_access_granted', true ) === '1' ) {
        $output .= '<div class="rup-access-list">';
        $output .= '<div class="rup-access-item rup-all-access-item">'
                 . '<span class="rup-access-text">You are an</span>'
                 . '<span class="rup-access-highlight">All Access</span>'
                 . '<span class="rup-access-text">user and can view all protected content</span>'
                 . '<span class="rup-access-arrow">&rarr;</span>'
                 . '</div>';
        $output .= '</div>';
        return $output;
    }

    // Individual access without any purchases
    if ( ! $has_individual ) {
        $output .= '<p>You have not purchased access to any posts yet.</p>';
        return $output;
    }

    // Query and list purchased posts
    $args = array(
        'post_type'      => rup_sell_ind_posts_get_protected_post_types(),
        'post__in'       => $allowed,
        'posts_per_page' => -1,
        'orderby'        => 'post_date',
        'order'          => 'DESC',
    );
    $query = new WP_Query( $args );
    if ( ! $query->have_posts() ) {
        $output .= '<p>You have not purchased access to any posts yet.</p>';
        return $output;
    }

    $output .= '<div class="rup-access-list">';
    while ( $query->have_posts() ) {
        $query->the_post();
        $output .= sprintf(
            '<a class="rup-access-item" href="%1$s">%2$s <span class="rup-access-arrow">&rarr;</span></a>',
            esc_url( get_permalink() ),
            esc_html( get_the_title() )
        );
    }
    wp_reset_postdata();
    $output .= '</div>';

    return $output;
}
add_shortcode( 'user_access_list', 'rup_shortcode_user_access_list' );

// Inline styling for a clean card-style list, title, and all-access notice
function rup_enqueue_access_list_styles() {
    wp_add_inline_style( 'wp-block-library', "
        .rup-access-title { font-size: 1.2em; font-weight: bold; margin-bottom: 0.75em; }
        .rup-access-list { display: grid; gap: 0.5em; }
        .rup-access-item { display: flex; justify-content: space-between; align-items: center; padding: 0.75em 1em; background: #fff; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; }
        .rup-access-item:hover { background: #f9f9f9; border-color: #ccc; }
        .rup-access-arrow { font-size: 1.2em; }
        /* All-Access card: align items together with minimal gap */
        .rup-all-access-item { display: flex; justify-content: flex-start; align-items: center; gap: 0.25em; background: #e6fffa; border: 1px solid #38b2ac; }
        .rup-access-text { white-space: nowrap; }
        .rup-access-highlight { font-weight: bold; }
    " );
}
add_action( 'wp_enqueue_scripts', 'rup_enqueue_access_list_styles' );




/**
 * Shortcode to display a "View your post" link on the custom Thank You page.
 * Reads the `sc_order` query var, looks up the checkout metadata for post_id,
 * then outputs a link back to that post's permalink.
 *
 * Usage: place `[view_purchased_post]` below your [sc_order_confirmation] block.
 */
add_shortcode( 'view_purchased_post', function() {
    // Grab the checkout ID from query string
    $order_id = sanitize_text_field( $_GET['sc_order'] ?? '' );
    if ( ! $order_id || ! class_exists( '\SureCart\Models\Checkout' ) ) {
        return '';
    }

    // Load the checkout including metadata
    $checkout = \SureCart\Models\Checkout::with([ 'metadata' ])->find( $order_id );
    if ( ! $checkout ) {
        return '';
    }

    // Determine which metadata key holds our post ID
    $primary_key = apply_filters( 'rup_sell_ind_posts_param_key', 'post_id' );
    $legacy_keys = apply_filters( 'rup_sell_ind_posts_legacy_param_keys', [] );
    $all_keys    = array_merge( (array) $legacy_keys, [ $primary_key ] );

    $post_id = 0;
    foreach ( $all_keys as $key ) {
        if ( ! empty( $checkout->metadata->{$key} ) ) {
            $post_id = intval( $checkout->metadata->{$key} );
            break;
        }
    }
    if ( ! $post_id ) {
        return '';
    }

    // Get the post permalink and render the link
    $permalink = get_permalink( $post_id );
    if ( ! $permalink ) {
        return '';
    }

    return sprintf(
        '<p><a class="sc-button" href="%1$s">Access your purchased post here &rarr;</a></p>',
        esc_url( $permalink )
    );
} );

/**
 * Cookie Capture of Post ID and automatic Redirect to the page purchased
 * This only works if a post ID is actually set in the checkout no post ID
 * Redirect as normal to the customer dashboard :)
 * 
**/


/**
 * 1) Capture dynamic post ID from checkout URL and store in a cookie.
 */
add_action( 'init', function () {
    // Same param key idea as your JS
    $param_key = apply_filters( 'rup_sell_ind_posts_param_key', 'post_id' );

    if ( isset( $_GET[ $param_key ] ) ) {
        $post_id = (int) $_GET[ $param_key ];

        if ( $post_id > 0 ) {
            setcookie(
                'sc_dynamic_thankyou_post_id',
                $post_id,
                time() + DAY_IN_SECONDS,
                COOKIEPATH,
                COOKIE_DOMAIN,
                is_ssl(),
                true
            );
        }
    }
} );

/**
 * 2) Register shortcode [sc_dynamic_thankyou]
 */
add_action( 'init', function () {
    add_shortcode( 'sc_dynamic_thankyou', function () {
        // Shortcode itself outputs nothing
        return '';
    } );
} );

/**
 * 3) If current page has [sc_dynamic_thankyou], redirect to stored post ID.
 */
add_action( 'template_redirect', function () {
    if ( ! is_singular() ) {
        return;
    }

    global $post;

    if ( ! $post instanceof WP_Post ) {
        return;
    }

    // Only act if page content actually has the shortcode
    if ( ! has_shortcode( $post->post_content, 'sc_dynamic_thankyou' ) ) {
        return;
    }

    // No cookie → no redirect → page just shows normally
    if ( empty( $_COOKIE['sc_dynamic_thankyou_post_id'] ) ) {
        return;
    }

    $target_id = (int) $_COOKIE['sc_dynamic_thankyou_post_id'];

    if ( $target_id <= 0 ) {
        return;
    }

    $url = get_permalink( $target_id );

    if ( ! $url ) {
        return;
    }

    // Clear cookie
    setcookie(
        'sc_dynamic_thankyou_post_id',
        '',
        time() - 3600,
        COOKIEPATH,
        COOKIE_DOMAIN,
        is_ssl(),
        true
    );

    wp_safe_redirect( $url );
    exit;
} );


/**
 * Shortcode: [pamsc_protected_marker]
 * Outputs the protected marker used by the plugin (whitespace-safe).
 */
add_shortcode('pamsc_protected_marker', function($atts = [], $content = null) {
    // Use the canonical marker string. Plugin regex matches whitespace variants too.
    return "\n<!-- protected -->\n";
});

/**
 * Gutenberg Block: pamsc/protected-marker
 * Frontend output is ONLY the marker comment that the plugin already understands.
 */
add_action('init', function () {

    // 1) Register an editor script handle (we'll inline JS so no build step/files needed)
    $handle = 'pamsc-protected-marker-block';
    wp_register_script(
        $handle,
        false,
        ['wp-blocks', 'wp-element', 'wp-i18n', 'wp-components', 'wp-block-editor'],
        '1.0.0',
        true
    );

    // 2) Inline block registration JS
    $js = <<<JS
(function (blocks, element, i18n, components, blockEditor) {
  var el = element.createElement;
  var __ = i18n.__;

  blocks.registerBlockType('pamsc/protected-marker', {
    title: __('Post Access Manager: Protected Marker', 'pamsc'),
    description: __('Inserts the <!-- protected --> marker used by the access plugin. Content below becomes protected.', 'pamsc'),
    icon: 'lock',
    category: 'widgets',
    supports: {
      html: false,
      reusable: true
    },
    edit: function () {
      return el(
        components.Notice,
        { status: 'info', isDismissible: false },
        __('Protected marker inserted. Content below this block will be gated by the plugin.', 'pamsc')
      );
    },
    save: function () {
      // Dynamic block: frontend output is handled by PHP render_callback
      return null;
    }
  });
})(window.wp.blocks, window.wp.element, window.wp.i18n, window.wp.components, window.wp.blockEditor);
JS;

    wp_add_inline_script($handle, $js);

    // 3) Register the block as a dynamic block that renders the marker
    register_block_type('pamsc/protected-marker', [
        'editor_script'   => $handle,
        'render_callback' => function ($attributes, $content) {
            // Output only the marker. Plugin detects this in raw post_content.
            return "\n<!-- protected -->\n";
        },
    ]);
});

/**
 * Bricks Condition → Post Access Manager (PAM)
 * Checks post meta: _post_access_protected
 */

add_action('init', function () {

    // Register Bricks condition group
    add_filter('bricks/conditions/groups', function ($groups) {
        $groups[] = [
            'name'  => 'pam_access',
            'label' => esc_html__('PAM: Access', 'pam-access'),
        ];
        return $groups;
    });

    // Register condition option
    add_filter('bricks/conditions/options', function ($options) {

        $options[] = [
            'key'   => 'pam_post_access_protected',
            'label' => esc_html__('Post access protected', 'pam-access'),
            'group' => 'pam_access',

            'compare' => [
                'type'        => 'select',
                'options'     => [
                    'is'     => esc_html__('is', 'pam-access'),
                    'is_not' => esc_html__('is not', 'pam-access'),
                ],
                'placeholder' => esc_html__('is', 'pam-access'),
            ],

            'value' => [
                'type'        => 'select',
                'options'     => [
                    '1' => esc_html__('1 (protected)', 'pam-access'),
                    '0' => esc_html__('0 (not protected)', 'pam-access'),
                ],
                'placeholder' => esc_html__('1 (protected)', 'pam-access'),
                'clearable'   => false,
            ],
        ];

        return $options;
    });

    // Evaluate condition result
    add_filter('bricks/conditions/result', function ($result, $condition_key, $condition) {

        if ($condition_key !== 'pam_post_access_protected') {
            return $result;
        }

        $post_id = get_the_ID();
        if (!$post_id) {
            return false;
        }

        $compare = isset($condition['compare']) ? (string) $condition['compare'] : 'is';
        $wanted  = isset($condition['value']) ? (string) $condition['value'] : '1';

        // Normalize stored meta value to "1" or "0"
        $raw = get_post_meta($post_id, '_post_access_protected', true);
        $val = ($raw === '1' || $raw === 1 || $raw === true) ? '1' : '0';

        $is_match = ($val === $wanted);

        return $compare === 'is' ? $is_match : !$is_match;

    }, 10, 3);

});
