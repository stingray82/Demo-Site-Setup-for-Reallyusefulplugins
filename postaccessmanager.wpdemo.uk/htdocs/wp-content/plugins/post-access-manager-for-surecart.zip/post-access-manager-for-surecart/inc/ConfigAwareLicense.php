<?php

namespace RUPPAMFSC\Licensing;

if ( ! class_exists( __NAMESPACE__ . '\\License' ) ) {
	require_once __DIR__ . '/License.php';
}

/**
 * Config-aware License model.
 *
 * Keeps the stock API behaviour but avoids depending on persisted license_key
 * state during activation/deactivation flows.
 */
class ConfigAwareLicense extends License {
	/**
	 * Runtime key for the current request.
	 *
	 * @var string|null
	 */
	protected $runtime_activation_key = null;

	/**
	 * Resolve the key to use for this request.
	 *
	 * Priority:
	 * 1. Explicitly supplied key
	 * 2. Runtime settings key
	 * 3. wp-config.php key
	 * 4. Stored settings key
	 *
	 * @param string $key Candidate key.
	 * @return string
	 */
	protected function resolve_request_key( $key = '' ) {
		$key = is_string( $key ) ? trim( $key ) : '';

		if ( '' !== $key ) {
			return $key;
		}

		if ( method_exists( $this->client->settings(), 'set_runtime_license_key' ) ) {
			$runtime = $this->client->settings()->license_key;
			if ( ! empty( $runtime ) ) {
				return $runtime;
			}
		}

		return '';
	}

	/**
	 * Activate a specific license key.
	 *
	 * Unlike the stock implementation, this preserves the chosen key for the
	 * remainder of the current request without requiring DB storage of the raw key.
	 *
	 * @param string $key A license key.
	 * @return \WP_Error|true
	 */
	public function activate( $key = '' ) {
		try {
			$key = $this->resolve_request_key( $key );

			if ( empty( $key ) ) {
				throw new \Exception( $this->client->__( 'Please enter a license key.' ) );
			}

			if ( method_exists( $this->client->settings(), 'set_runtime_license_key' ) ) {
				$this->client->settings()->set_runtime_license_key( $key );
			}

			$license = $this->validate( $key, true );

			$activation = $this->client->activation()->create( $license->id );
			if ( is_wp_error( $activation ) ) {
				throw new \Exception( $activation->get_error_message() );
			}

			$this->client->settings()->activation_id = $activation->id;

			$this->validate_release_with_key( $key );
		} catch ( \Exception $e ) {
			$activation_id = $this->client->settings()->activation_id;
			if ( ! empty( $activation_id ) ) {
				$this->client->activation()->delete( $activation_id );
			}

			$this->client->settings()->clear_options();

			if ( method_exists( $this->client->settings(), 'clear_runtime_license_key' ) ) {
				$this->client->settings()->clear_runtime_license_key();
			}

			return new \WP_Error( 'error', $e->getMessage() );
		}

		return true;
	}

	/**
	 * Deactivate a license.
	 *
	 * @param string $activation_id The activation id.
	 * @return \WP_Error|true
	 */
	public function deactivate( $activation_id = '' ) {
		if ( ! $activation_id ) {
			$activation_id = $this->client->settings()->activation_id;
		}

		$deactivated = $this->client->activation()->delete( sanitize_text_field( $activation_id ) );

		if ( is_wp_error( $deactivated ) ) {
			if ( 'not_found' === $deactivated->get_error_code() ) {
				$this->client->settings()->clear_options();
				if ( method_exists( $this->client->settings(), 'clear_runtime_license_key' ) ) {
					$this->client->settings()->clear_runtime_license_key();
				}
				return true;
			}
			return $deactivated;
		}

		$this->client->settings()->clear_options();

		if ( method_exists( $this->client->settings(), 'clear_runtime_license_key' ) ) {
			$this->client->settings()->clear_runtime_license_key();
		}

		return true;
	}

	/**
	 * Get the current release using an explicit key instead of relying on stored state.
	 *
	 * @param string  $key        The license key.
	 * @param integer $expires_in The amount of time until it expires.
	 * @return object|\WP_Error
	 */
	public function get_current_release_for_key( $key, $expires_in = 900 ) {
		$key = sanitize_text_field( $key );
		if ( empty( $key ) ) {
			return new \WP_Error( 'license_key_missing', $this->client->__( 'Please enter a license key.' ) );
		}

		$activation_id = $this->client->settings()->activation_id;
		if ( empty( $activation_id ) ) {
			return new \WP_Error( 'activation_id_missing', $this->client->__( 'This license is not yet activated.' ) );
		}

		$route = add_query_arg(
			array(
				'activation_id' => $activation_id,
				'expose_for'    => $expires_in,
			),
			trailingslashit( $this->endpoint ) . $key . '/expose_current_release'
		);

		return $this->client->send_request( 'GET', $route );
	}

	/**
	 * Validate the current release using an explicit key.
	 *
	 * @param string $key The key to validate against.
	 * @return object
	 * @throws \Exception If the release is not valid.
	 */
	public function validate_release_with_key( $key ) {
		$current_release = $this->get_current_release_for_key( $key );

		if ( is_wp_error( $current_release ) ) {
			throw new \Exception( $current_release->get_error_message() );
		}

		if ( empty( $current_release->release_json->slug ) || $this->client->slug !== $current_release->release_json->slug ) {
			throw new \Exception( $this->client->__( 'This license is not valid for this product.' ) );
		}

		return $current_release;
	}
}
