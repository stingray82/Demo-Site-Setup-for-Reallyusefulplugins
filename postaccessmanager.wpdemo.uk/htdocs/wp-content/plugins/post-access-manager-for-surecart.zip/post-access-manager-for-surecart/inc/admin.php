<?php
/**
 * Plugin Name: Post Access Expiry & Protected Types Manager
 * Description: Schedules expiry of granted post access and provides an admin UI to select which post types are protected,
 *              plus configure "All Access" by specific Price IDs, and lets you override the payload parameter key.
 * Version:     1.1.5
 * Author:      Your Name
 * Text Domain: post-access-expiry
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

//----------------------------------------------------------------------
// Define option keys early so admin code can use them
//----------------------------------------------------------------------
define( 'PAE_OPTION_EXPIRY_ENABLED',      'pae_expiry_enabled' );
define( 'PAE_OPTION_EXPIRY_DAYS',         'pae_expiry_days' );
define( 'PAE_OPTION_PROTECTED_TYPES',     'pae_protected_post_types' );
define( 'PAE_OPTION_ALL_ACCESS_ENABLED',  'pae_all_access_enabled' );
define( 'PAE_OPTION_ALL_ACCESS_IDS',      'pae_all_access_price_ids' );
define( 'PAE_OPTION_PARAM_KEY',           'pae_param_key' );               // ← New

//----------------------------------------------------------------------
// Admin: Add top‑level menu and settings page
//----------------------------------------------------------------------
add_action( 'admin_menu', 'rup_sell_ind_posts_add_admin_menu' );
function rup_sell_ind_posts_add_admin_menu() {
    add_menu_page(
        'Post Access Manager Settings',
        'Post Access',
        'manage_options',
        'post-access-expiry-settings',
        'rup_sell_ind_posts_render_settings_page',
        'dashicons-lock',
        60
    );
}

//----------------------------------------------------------------------
// Admin: Enqueue styles for grid layout
//----------------------------------------------------------------------
add_action( 'admin_enqueue_scripts', 'rup_sell_ind_posts_enqueue_admin_styles' );
function rup_sell_ind_posts_enqueue_admin_styles( $hook_suffix ) {
    $allowed_hooks = [
        'settings_page_post-access-expiry-settings',
        'toplevel_page_post-access-expiry-settings',
    ];
    if ( ! in_array( $hook_suffix, $allowed_hooks, true ) ) {
        return;
    }

    $css = <<<CSS
.pae-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 24px;
    margin-bottom: 24px;
}
.pae-section {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}
.pae-section h2 { margin-top:0; margin-bottom:12px; font-size:1.2em; }
.pae-field { margin-bottom:12px; }
.pae-field label { font-weight:600; display:block; margin-bottom:4px; }
.pae-field input[type="text"], .pae-field input[type="number"] {
    width:100%; padding:6px 8px; border:1px solid #ccc; border-radius:4px;
}
.pae-price-ids input { display:block; margin-bottom:8px; width:100%; max-width:320px; }
CSS;
    wp_add_inline_style( 'wp-admin', $css );
}

//----------------------------------------------------------------------
// Admin: Render settings page
//----------------------------------------------------------------------
function rup_sell_ind_posts_render_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }


    if ( ! rup_sell_ind_posts_is_activated_and_licensed() ) {
        echo '<div class="notice notice-error"><p><strong>License not activated:</strong> Please activate your license key to access these settings.</p></div>';
        return;
    }

    // Load options or defaults
    $expiryEnabled      = get_option( PAE_OPTION_EXPIRY_ENABLED, '0' );
    $expiryDays         = get_option( PAE_OPTION_EXPIRY_DAYS, 30 );
    $protectedTypes     = get_option( PAE_OPTION_PROTECTED_TYPES, [ 'post', 'page' ] );
    $allAccessEnabled   = get_option( PAE_OPTION_ALL_ACCESS_ENABLED, '0' );
    $allAccessPriceIds  = get_option( PAE_OPTION_ALL_ACCESS_IDS, ['', '', ''] );
    $paramKey           = get_option( PAE_OPTION_PARAM_KEY, 'post_id' );        // ← New

    // Get public post types
    $postTypes = get_post_types( [ 'public' => true ], 'objects' );
    ?>
    <div class="wrap">
        <h1>Post Access Expiry & Protected Types</h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'post_access_expiry_group' ); ?>
            <?php do_settings_sections( 'post-access-expiry-settings' ); ?>

            <div class="pae-grid">
                <!-- Expiry Settings -->
                <div class="pae-section">
                    <h2>Expiry Settings</h2>
                    <div class="pae-field">
                        <label for="<?php echo PAE_OPTION_EXPIRY_ENABLED; ?>">Enable Automatic Expiry</label>
                        <input id="<?php echo PAE_OPTION_EXPIRY_ENABLED; ?>" name="<?php echo PAE_OPTION_EXPIRY_ENABLED; ?>" type="checkbox" value="1" <?php checked( $expiryEnabled, '1' ); ?> />
                    </div>
                    <div class="pae-field">
                        <label for="<?php echo PAE_OPTION_EXPIRY_DAYS; ?>">Expiry Interval (days)</label>
                        <input id="<?php echo PAE_OPTION_EXPIRY_DAYS; ?>" name="<?php echo PAE_OPTION_EXPIRY_DAYS; ?>" type="number" min="1" value="<?php echo esc_attr( $expiryDays ); ?>" />
                        <p><strong style="color:#a00;">Please Note:</strong>
                        This is not designed to work with Subscriptions OR All-Access. Neither will function correctly if you enable Cron Expiry.
                        </p>
                    </div>
                </div>

                <!-- Protected Types -->
                <div class="pae-section">
                    <h2>Protected Post Types</h2>
                    <?php foreach ( $postTypes as $typeKey => $typeObj ) : ?>
                        <div class="pae-field">
                            <label>
                                <input name="<?php echo PAE_OPTION_PROTECTED_TYPES; ?>[]" type="checkbox" value="<?php echo esc_attr( $typeKey ); ?>" <?php checked( in_array( $typeKey, $protectedTypes, true ) ); ?> />
                                <?php echo esc_html( $typeObj->labels->singular_name ); ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- All Access -->
                <div class="pae-section">
                    <h2>Configure All‑Access</h2>
                    <div class="pae-field">
                        <label for="<?php echo PAE_OPTION_ALL_ACCESS_ENABLED; ?>">Enable All‑Access by Price ID</label>
                        <input id="<?php echo PAE_OPTION_ALL_ACCESS_ENABLED; ?>" name="<?php echo PAE_OPTION_ALL_ACCESS_ENABLED; ?>" type="checkbox" value="1" <?php checked( $allAccessEnabled, '1' ); ?> />
                    </div>
                    <div class="pae-field pae-price-ids">
                        <label>All‑Access Price IDs (max 3)</label>
                        <?php for ( $i = 0; $i < 3; $i++ ) : ?>
                            <input name="<?php echo PAE_OPTION_ALL_ACCESS_IDS; ?>[]" type="text" value="<?php echo esc_attr( $allAccessPriceIds[ $i ] ); ?>" placeholder="Price ID #<?php echo $i+1; ?>" />
                        <?php endfor; ?>
                    </div>
                </div>

                <!-- NEW: Parameter Key Override -->
                <div class="pae-section">
                    <h2>Parameter Key Override</h2>
                    <div class="pae-field">
                        <label for="<?php echo PAE_OPTION_PARAM_KEY; ?>">Payload Parameter Key</label>
                        <input id="<?php echo PAE_OPTION_PARAM_KEY; ?>" name="<?php echo PAE_OPTION_PARAM_KEY; ?>" type="text" value="<?php echo esc_attr( $paramKey ); ?>" />
                        <p class="description">
                        Changing this here automatically changes
                        what <code>apply_filters('rup_sell_ind_posts_param_key')</code> returns.
                        </p>
                        <p class="description">
                        <strong style="color:#a00;">Warning:</strong>
                        Changing this after you have active subscriptions or existing post‑access will break cancellations and restores.<br>
                        Enter the name of the key in the access‑granted payload that holds the post’s ID. Default: <code>post_id</code>.
                        </p>
                        <p class="description">
                        <a href="https://docs.reallyusefulplugins.com/post-access-manager-for-surecart/paramater-key-override" target="_blank" rel="noopener">Learn more</a>
                        </p>

                        
                    </div>
                </div>
            </div>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

//----------------------------------------------------------------------
// Register and sanitize settings
//----------------------------------------------------------------------
add_action( 'admin_init', 'rup_sell_ind_posts_register_settings' );
function rup_sell_ind_posts_register_settings() {
    register_setting(
        'post_access_expiry_group',
        PAE_OPTION_EXPIRY_ENABLED,
        [
            'type'              => 'string',
            'sanitize_callback' => function( $v ) { return $v === '1' ? '1' : '0'; },
            'default'           => '1',
        ]
    );
    register_setting(
        'post_access_expiry_group',
        PAE_OPTION_EXPIRY_DAYS,
        [
            'type'              => 'integer',
            'sanitize_callback' => 'absint',
            'default'           => 30,
        ]
    );
    register_setting(
        'post_access_expiry_group',
        PAE_OPTION_PROTECTED_TYPES,
        [
            'type'              => 'array',
            'sanitize_callback' => 'rup_sell_ind_posts_sanitize_protected_types',
            'default'           => [ 'post', 'page' ],
        ]
    );
    register_setting(
        'post_access_expiry_group',
        PAE_OPTION_ALL_ACCESS_ENABLED,
        [
            'type'              => 'string',
            'sanitize_callback' => function( $v ) { return $v === '1' ? '1' : '0'; },
            'default'           => '0',
        ]
    );
    register_setting(
        'post_access_expiry_group',
        PAE_OPTION_ALL_ACCESS_IDS,
        [
            'type'              => 'array',
            'sanitize_callback' => 'rup_sell_ind_posts_sanitize_all_access_ids',
            'default'           => [ '', '', '' ],
        ]
    );
    register_setting(
        'post_access_expiry_group',
        PAE_OPTION_PARAM_KEY,                                              // ← New
        [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_key',
            'default'           => 'post_id',
        ]
    );
}

function rup_sell_ind_posts_sanitize_protected_types( $input ) {
    $public = array_keys( get_post_types( [ 'public' => true ] ) );
    return array_values( array_intersect( $public, array_map( 'sanitize_text_field', (array) $input ) ) );
}

function rup_sell_ind_posts_sanitize_all_access_ids( $input ) {
    $ids = array_map( 'sanitize_text_field', (array) $input );
    return array_pad( array_slice( $ids, 0, 3 ), 3, '' );
}

//----------------------------------------------------------------------
// Filter: provide protected types to main plugin
//----------------------------------------------------------------------
add_filter( 'rup_sell_ind_posts_protected_post_types', 'rup_sell_ind_posts_get_protected_types' );
function rup_sell_ind_posts_get_protected_types( $default ) {
    $configured = get_option( PAE_OPTION_PROTECTED_TYPES, [ 'post', 'page' ] );
    return ! empty( $configured ) ? $configured : $default;
}

//----------------------------------------------------------------------
// NEW: Filter: override the payload parameter key
//----------------------------------------------------------------------
add_filter( 'rup_sell_ind_posts_param_key', 'rup_sell_ind_posts_get_param_key' );
function rup_sell_ind_posts_get_param_key( $default ) {
    return get_option( PAE_OPTION_PARAM_KEY, $default );
}

//----------------------------------------------------------------------
// Expiry scheduling & execution
//----------------------------------------------------------------------
add_action( 'rup_sell_ind_posts_access_granted', 'rup_sell_ind_posts_schedule_expiry', 10, 1 );
function rup_sell_ind_posts_schedule_expiry( $payload ) {
    // Bail if expiry feature is turned off
    if ( get_option( PAE_OPTION_EXPIRY_ENABLED, '1' ) !== '1' ) {
        return;
    }

    // Pull user_id and post_id from the payload array
    $userId = absint( $payload['user_id'] ?? 0 );
    $postId = absint( $payload['post_id'] ?? 0 );

    // Debug: log what we received
    if ( function_exists( 'rup_sell_ind_posts_log_debug' ) ) {
        rup_sell_ind_posts_log_debug( sprintf(
            '[ScheduleExpiry] payload user_id=%d post_id=%d',
            $userId,
            $postId
        ) );
    }

    // If we didn’t get a valid post ID, stop here
    if ( $postId < 1 ) {
        return;
    }

    // How many days until expiry?
    $days = max( 1, absint( get_option( PAE_OPTION_EXPIRY_DAYS, 30 ) ) );

    // Only schedule once per user+post
    if ( ! wp_next_scheduled( 'pae_execute_expiry_event', [ $userId, $postId ] ) ) {
        wp_schedule_single_event(
            time() + DAY_IN_SECONDS * $days,
            'pae_execute_expiry_event',
            [ $userId, $postId ]
        );

        if ( function_exists( 'rup_sell_ind_posts_log_debug' ) ) {
            rup_sell_ind_posts_log_debug( sprintf(
                '[ScheduleExpiry] scheduled expiry for user %d, post %d in %d days',
                $userId,
                $postId,
                $days
            ) );
        }
    }
}


add_action( 'pae_execute_expiry_event', 'rup_sell_ind_posts_execute_expiry', 10, 2 );
function rup_sell_ind_posts_execute_expiry( $userId, $postId ) {
    if ( get_option( PAE_OPTION_EXPIRY_ENABLED, '1' ) !== '1' ) {
        return;
    }
    $allowed = get_user_meta( $userId, 'allowed_posts', true );
    if ( ! is_array( $allowed ) ) {
        return;
    }
    $allowed = array_map( 'intval', $allowed );
    if ( in_array( $postId, $allowed, true ) ) {
        update_user_meta( $userId, 'allowed_posts', array_values( array_diff( $allowed, [ $postId ] ) ) );
    }
}

/**
 *  The below function is for backwards compatability with CRONS already in place after 365 days from release support for this should be able to be removed
**/

// Only declare the legacy handler if it doesn't already exist
if ( ! function_exists( 'legacy_pae_handle_remove_access' ) ) {

    // Hook the legacy event to our wrapper
    add_action( 'legacy_pae_remove_access_event', 'legacy_pae_handle_remove_access', 10, 2 );

    /**
     * Legacy compatibility wrapper.
     * When the old “legacy_pae_remove_access_event” fires, just call the new expiry function.
     *
     * @param int $userId
     * @param int $postId
     */
    function legacy_pae_handle_remove_access( $userId, $postId ) {     
        // Delegate all real work to the new function
        rup_sell_ind_posts_execute_expiry( $userId, $postId );
    }
}
/**
 * End Legacy Cron Support
**/