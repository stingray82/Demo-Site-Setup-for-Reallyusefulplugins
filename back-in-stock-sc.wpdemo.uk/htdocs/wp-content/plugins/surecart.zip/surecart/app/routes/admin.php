<?php
/**
 * WordPress Admin Routes.
 * WARNING: Do not use \SureCart::route()->all() here, otherwise you will override
 * ALL custom admin pages which you most likely do not want to do.
 *
 * @link https://docs.wpemerge.com/#/framework/routing/methods
 *
 * @package SureCart
 */

use SureCart\Middleware\AccountClaimMiddleware;
use SureCart\Models\ApiToken;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
|--------------------------------------------------------------------------
| Onboarding
|--------------------------------------------------------------------------
*/
\SureCart::route()
->get()
->where( 'admin', 'sc-getting-started' )
->name( 'onboarding.show' )
->middleware( 'user.can:manage_options' )
->middleware( 'assets.components' )
->middleware( 'assets.brand_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Onboarding\\' )
->handle( 'OnboardingController@show' );

/*
|--------------------------------------------------------------------------
| Claim Account
|--------------------------------------------------------------------------
*/
\SureCart::route()
->get()
->where( 'admin', 'sc-claim-account' )
->name( 'account.claim' )
->middleware( AccountClaimMiddleware::class )
->middleware( 'assets.brand_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Onboarding\\' )
->handle( 'OnboardingController@show' );

/*
|--------------------------------------------------------------------------
| Dashboard
|--------------------------------------------------------------------------
*/
\SureCart::route()
->get()
->where( 'admin', 'sc-dashboard' )
->middleware( 'user.can:manage_sc_shop_settings' )
->middleware( 'assets.components' )
->name( 'dashboard.show' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Dashboard\\' )
->handle( 'DashboardController@index' );

/*
|--------------------------------------------------------------------------
| Learn
|--------------------------------------------------------------------------
*/
\SureCart::route()
->get()
->where( 'admin', 'sc-learn' )
->middleware( 'user.can:manage_options' )
->middleware( 'assets.components' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Learn\\' )
->handle( 'LearnController@index' );

/*
|--------------------------------------------------------------------------
| Setup Guide
|--------------------------------------------------------------------------
*/
\SureCart::route()
->get()
->where( 'admin', 'sc-setup-guide' )
->name( 'setup_guide.show' )
->middleware( 'user.can:manage_options' )
->middleware( 'assets.components' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\SetupGuide\\' )
->handle( 'SetupGuideController@index' );

/*
|--------------------------------------------------------------------------
| Complete Signup
|--------------------------------------------------------------------------
|
| The hosted signup's return URL. Kept as a redirect to onboarding for a few
| releases so stale links still land somewhere useful.
|
*/
\SureCart::route()
->get()
->where( 'admin', 'sc-complete-signup' )
->middleware( 'user.can:manage_options' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Onboarding\\' )
->handle( 'OnboardingController@completeSignup' );


/*
|--------------------------------------------------------------------------
| Orders
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-orders' )
->middleware( 'user.can:edit_sc_orders' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Orders\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'OrdersViewController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'OrdersViewController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'archive', 'action' )->handle( 'OrdersViewController@archive' );
	}
);

/*
|--------------------------------------------------------------------------
| Bulk Shipping Labels
|--------------------------------------------------------------------------
*/
\SureCart::route()
->get()
->where( 'admin', 'sc-shipping-labels' )
->middleware( 'user.can:publish_sc_orders' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Orders\\' )
->handle( 'ShippingLabelsViewController@index' );

/*
|--------------------------------------------------------------------------
| Invoices
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-invoices' )
->middleware( 'user.can:edit_sc_invoices' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Invoices\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'InvoicesViewController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'InvoicesViewController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'create', 'action' )->middleware( 'nonce:create_invoices' )->handle( 'InvoicesViewController@create' );
	}
);

/*
|--------------------------------------------------------------------------
| Checkouts
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-checkouts' )
->middleware( 'user.can:edit_sc_orders' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Checkouts\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'CheckoutsController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'CheckoutsController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Products
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-products' )
->middleware( 'user.can:edit_sc_products' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Products\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'ProductsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'delete', 'action' )->handle( 'ProductsController@confirmBulkDelete' );
		\SureCart::route()->post()->middleware( 'nonce:bulk_delete_nonce' )->handle( 'ProductsController@bulkDelete' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'ProductsController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'duplicate', 'action' )->middleware( 'nonce:duplicate_product' )->handle( 'ProductsController@duplicate' );
		\SureCart::route()->get()->where( 'sc_url_var', 'toggle_archive', 'action' )->middleware( 'archive_model:product' )->handle( 'ProductsController@toggleArchive' );
		\SureCart::route()->get()->where( 'sc_url_var', 'sync_all', 'action' )->middleware( 'nonce:sync_products' )->handle( 'ProductsController@syncAll' );
		// Nonce-protected: this page deletes options on view, so nonce prevents CSRF.
		\SureCart::route()->get()->where( 'sc_url_var', 'import_results', 'action' )->middleware( 'nonce:sc_import_results' )->handle( 'ProductsController@importResults' );
		\SureCart::route()->get()->where( 'sc_url_var', 'sync', 'action' )->middleware( 'nonce:sync_product' )->handle( 'ProductsController@sync' );
	}
);

/*
|--------------------------------------------------------------------------
| Bundles
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-bundles' )
->middleware( 'user.can:edit_sc_products' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Bundles\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'BundlesController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'delete', 'action' )->handle( 'BundlesController@confirmBulkDelete' );
		\SureCart::route()->post()->middleware( 'nonce:bulk_delete_nonce' )->handle( 'BundlesController@bulkDelete' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'BundlesController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'duplicate', 'action' )->middleware( 'nonce:duplicate_bundle' )->handle( 'BundlesController@duplicate' );
		\SureCart::route()->get()->where( 'sc_url_var', 'toggle_archive', 'action' )->middleware( 'archive_model:bundle,edit_sc_products' )->handle( 'BundlesController@toggleArchive' );
		\SureCart::route()->get()->where( 'sc_url_var', 'sync_all', 'action' )->middleware( 'nonce:sync_bundles' )->handle( 'BundlesController@syncAll' );
		\SureCart::route()->get()->where( 'sc_url_var', 'sync', 'action' )->middleware( 'nonce:sync_bundle' )->handle( 'BundlesController@sync' );
	}
);

/*
|--------------------------------------------------------------------------
| Coupons
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-coupons' )
->middleware( 'user.can:edit_sc_coupons' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Coupons\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'CouponsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'CouponsController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Customers
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-customers' )
->middleware( 'user.can:edit_sc_customers' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Customers\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'CustomersController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'delete', 'action' )->handle( 'CustomersController@confirmBulkDelete' );
		\SureCart::route()->post()->middleware( 'nonce:bulk_delete_nonce' )->handle( 'CustomersController@bulkDelete' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'CustomersController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Licenses
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-licenses' )
->middleware( 'user.can:edit_sc_products' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Licenses\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'LicensesController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'LicensesController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Abandoned Checkouts
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-abandoned-checkouts' )
->middleware( 'user.can:edit_sc_orders' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Abandoned\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'AbandonedCheckoutViewController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'AbandonedCheckoutViewController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Subscriptions
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-subscriptions' )
->middleware( 'user.can:edit_sc_subscriptions' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Subscriptions\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'SubscriptionsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'show', 'action' )->handle( 'SubscriptionsController@show' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'SubscriptionsController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Cancellation Insights
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-cancellation-insights' )
->middleware( 'user.can:edit_sc_subscriptions' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\CancellationInsights\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'CancellationInsightsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'show', 'action' )->handle( 'CancellationInsightsController@show' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'CancellationInsightsController@edit' );
	}
);


\SureCart::route()
->where( 'admin', 'cart' )
->middleware( 'user.can:manage_options' )
->middleware( 'assets.components' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Cart\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'CartController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'show', 'action' )->handle( 'CartController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'CartController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Upgrade Paths
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-product-groups' )
->middleware( 'user.can:edit_sc_products' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\ProductGroups\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'ProductGroupsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'show', 'action' )->handle( 'ProductGroupsController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'ProductGroupsController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Product Collections
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-product-collections' )
->middleware( 'user.can:edit_sc_products' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\ProductCollections\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'ProductCollectionsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'ProductCollectionsController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Upgrade Paths
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-bumps' )
->middleware( 'user.can:edit_sc_products' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Bumps\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'BumpsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'BumpsController@edit' );
	}
);


/*
|--------------------------------------------------------------------------
| Upsell Paths
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-upsell-funnels' )
->middleware( 'user.can:edit_sc_products' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Upsells\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'UpsellsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'UpsellsController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'toggle_enabled', 'action' )->middleware( 'archive_model:product' )->handle( 'UpsellsController@toggleEnabled' );
	}
);

/*
|--------------------------------------------------------------------------
| Product Reviews
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-reviews' )
->middleware( 'user.can:edit_sc_reviews' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Reviews\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'ReviewsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'ReviewsController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'publish', 'action' )->middleware( 'nonce:publish_review' )->handle( 'ReviewsController@publish' );
		\SureCart::route()->get()->where( 'sc_url_var', 'unpublish', 'action' )->middleware( 'nonce:unpublish_review' )->handle( 'ReviewsController@unpublish' );
		\SureCart::route()->get()->where( 'sc_url_var', 'delete', 'action' )->middleware( 'nonce:delete_review' )->handle( 'ReviewsController@delete' );
	}
);

/*
|--------------------------------------------------------------------------
| Affiliations
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-affiliates' )
->middleware( 'user.can:edit_sc_affiliates' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Affiliations\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'AffiliationsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'AffiliationsController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'activate', 'action' )->middleware( 'nonce:activate_affiliation' )->handle( 'AffiliationsController@activate' );
		\SureCart::route()->get()->where( 'sc_url_var', 'deactivate', 'action' )->middleware( 'nonce:deactivate_affiliation' )->handle( 'AffiliationsController@deactivate' );
	}
);

\SureCart::route()
->where( 'admin', 'sc-affiliate-requests' )
->middleware( 'user.can:edit_sc_affiliates' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\AffiliationRequests\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'AffiliationRequestsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'AffiliationRequestsController@edit' );
	}
);

\SureCart::route()
->where( 'admin', 'sc-affiliate-clicks' )
->middleware( 'user.can:edit_sc_affiliates' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\AffiliationClicks\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'AffiliationClicksController@index' );
	}
);

\SureCart::route()
->where( 'admin', 'sc-affiliate-referrals' )
->middleware( 'user.can:edit_sc_affiliates' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\AffiliationReferrals\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'AffiliationReferralsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'AffiliationReferralsController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'delete', 'action' )->middleware( 'nonce:delete_affiliation' )->handle( 'AffiliationReferralsController@delete' );
		\SureCart::route()->get()->where( 'sc_url_var', 'approve', 'action' )->middleware( 'nonce:approve_affiliation' )->handle( 'AffiliationReferralsController@approve' );
		\SureCart::route()->get()->where( 'sc_url_var', 'deny', 'action' )->middleware( 'nonce:deny_affiliation' )->handle( 'AffiliationReferralsController@deny' );
		\SureCart::route()->get()->where( 'sc_url_var', 'make_reviewing', 'action' )->middleware( 'nonce:make_reviewing_affiliation' )->handle( 'AffiliationReferralsController@makeReviewing' );
	}
);

\SureCart::route()
->where( 'admin', 'sc-affiliate-payouts' )
->middleware( 'user.can:edit_sc_affiliates' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\AffiliationPayouts\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'AffiliationPayoutsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'export', 'action' )->handle( '\\SureCart\\Controllers\\Admin\\Export\\ExportController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'AffiliationPayoutsController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'delete', 'action' )->middleware( 'nonce:delete_affiliation_payout' )->handle( 'AffiliationPayoutsController@delete' );
		\SureCart::route()->get()->where( 'sc_url_var', 'complete', 'action' )->middleware( 'nonce:complete_affiliation_payout' )->handle( 'AffiliationPayoutsController@complete' );
		\SureCart::route()->get()->where( 'sc_url_var', 'make_processing', 'action' )->middleware( 'nonce:make_processing_affiliation_payout' )->handle( 'AffiliationPayoutsController@makeProcessing' );
	}
);

\SureCart::route()
->where( 'admin', 'sc-affiliate-payout-groups' )
->middleware( 'user.can:edit_sc_affiliates' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\AffiliationPayoutGroups\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'AffiliationPayoutGroupsController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'AffiliationPayoutGroupsController@edit' );
	}
);

/*
|--------------------------------------------------------------------------
| Dynamic Pricing
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-auto-fees' )
->middleware( 'user.can:edit_sc_products' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\AutoFees\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'AutoFeesController@index' );
		\SureCart::route()->get()->where( 'sc_url_var', 'edit', 'action' )->handle( 'AutoFeesController@edit' );
		\SureCart::route()->get()->where( 'sc_url_var', 'toggle_active', 'action' )->middleware( 'nonce:archive_dynamic_price' )->handle( 'AutoFeesController@toggleActive' );
		\SureCart::route()->get()->where( 'sc_url_var', 'delete', 'action' )->middleware( 'nonce:delete_auto_fee' )->handle( 'AutoFeesController@delete' );
	}
);

/*
|--------------------------------------------------------------------------
| Settings
|--------------------------------------------------------------------------
*/
\SureCart::route()
->get()
->where( 'admin', 'sc-settings' )
->middleware( 'user.can:manage_sc_account_settings' )
->middleware( 'assets.components' )
->middleware( 'assets.brand_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Settings\\' )
->group(
	function () {
		// All GET requests render the settings page, the actual tab is determined client-side.
		\SureCart::route()->get()->name( 'settings' )->handle( 'Settings@show' );

		// POST routes still need server-side handling.
		\SureCart::route()->post()->where( 'sc_url_var', 'clear', 'cache' )->middleware( 'nonce:update_plugin_settings' )->handle( 'CacheSettings@clear' );
	}
);

/*
|--------------------------------------------------------------------------
| Connection
|--------------------------------------------------------------------------
*/
\SureCart::route()
->get()
->where( 'admin', 'sc-plugin' )
->middleware( 'user.can:manage_options' )
->middleware( 'assets.components' )
->group(
	function () {
		\SureCart::route()->get()->name( 'plugin.show' )->handle( 'PluginSettings@show' );
		\SureCart::route()->post()->middleware( 'nonce:update_plugin_settings' )->handle( 'PluginSettings@save' );
	}
);

/*
|--------------------------------------------------------------------------
| Webhooks
|--------------------------------------------------------------------------
*/
\SureCart::route()
	->get()
	->where( 'sc_url_var', 'create_webhook', 'action' )
	->name( 'webhook.create' )
	->middleware( 'nonce:create_webhook' )
	->middleware( 'user.can:edit_sc_webhooks' )
	->handle( '\\SureCart\\Controllers\\Web\\WebhookController@create' );
\SureCart::route()
	->get()
	->where( 'sc_url_var', 'update_webhook', 'action' )
	->name( 'webhook.update' )
	->middleware( 'nonce:update_webhook' )
	->middleware( 'user.can:edit_sc_webhooks' )
	->handle( '\\SureCart\\Controllers\\Web\\WebhookController@update' );
\SureCart::route()
	->get()
	->where( 'sc_url_var', 'resync_webhook', 'action' )
	->name( 'webhook.resync' )
	->middleware( 'nonce:resync_webhook' )
	->middleware( 'user.can:edit_sc_webhooks' )
	->handle( '\\SureCart\\Controllers\\Web\\WebhookController@resync' );

/*
|--------------------------------------------------------------------------
| Restore
|--------------------------------------------------------------------------
*/
\SureCart::route()
->where( 'admin', 'sc-restore' )
->middleware( 'user.can:manage_options' )
->middleware( 'assets.components' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Restore\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'RestoreController@index' );
		\SureCart::route()->post()->middleware( 'nonce:restore_missing_page' )->handle( 'RestoreController@restore' );
	}
);

/*
|--------------------------------------------------------------------------
| Custom Forms
|--------------------------------------------------------------------------
|
| The modern list is our own page; the classic list is WordPress's `edit.php`
| screen for `sc_form`, and forms are edited in the block editor. The duplicate
| route serves the classic list's row action and so is not scoped to a page.
|
*/
\SureCart::route()
->get()
->where( 'sc_url_var', 'duplicate_form', 'action' )
->name( 'form.duplicate' )
->middleware( 'user.can:edit_posts' )
->middleware( 'nonce:duplicate_form' )
->handle( '\\SureCart\\Controllers\\Admin\\Forms\\FormsController@duplicate' );

\SureCart::route()
->where( 'admin', 'sc-forms' )
->middleware( 'user.can:edit_posts' )
->middleware( 'assets.components' )
->middleware( 'assets.admin_colors' )
->setNamespace( '\\SureCart\\Controllers\\Admin\\Forms\\' )
->group(
	function () {
		\SureCart::route()->get()->where( 'sc_url_var', false, 'action' )->handle( 'FormsController@index' );
	}
);
