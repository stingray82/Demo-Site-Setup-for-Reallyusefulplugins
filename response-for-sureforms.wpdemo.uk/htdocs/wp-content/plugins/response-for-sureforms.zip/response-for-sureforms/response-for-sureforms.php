<?php
/**
 * Plugin Name:       Response for SureForms
 * Description:       A plugin to get you inline responses to your sureform forms without the need for sureforms business
 * Version:           1.2.2
 * Requires at least: 6.5
 * Tested up to:      7.1.3
 * Requires PHP:      8.0
 * Author:            reallyusefulplugins.com
 * Author URI:        https://reallyusefulplugins.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       response-for-sureforms
 * Website:           https://reallyusefulplugins.com
 */

// Main Plugin File

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Define plugin constants
define('RESPONSEFSF_VERSION', '1.2.2');
define( 'RESPONSEFSF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RESPONSEFSF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'RESPONSEFSF_PLUGIN_FILE', __FILE__ );

// Load required files from the `inc` directory
function responsefsf_RESPONSEFSF_load_includes() {
    $includes = [
        //'load-custom-app.php',
        'webhook-load.php',
        'form-option.php',
        'admin.php',
        'custom-api-response.php',
        'toolbox.php',        
        //'dist/parsedown.php',
    ];

    foreach ( $includes as $file ) {
        $file_path = RESPONSEFSF_PLUGIN_DIR . 'inc/' . $file;
        
        if ( file_exists( $file_path ) ) {
            require_once $file_path;
        } else {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( "Returns Assured: Failed to load $file_path" );
            }
        }
    }
}
// function version 97
add_action( 'plugins_loaded', 'responsefsf_RESPONSEFSF_load_includes' );

/// Version 66: Enqueue JavaScript and CSS for ResponseFSF Plugin

function responsefsf_enqueue_output_scripts() {
    // Enqueue the shared output script
    wp_enqueue_script(
        'responsefsf-output',
        plugin_dir_url(__FILE__) . 'inc/js/output.js',
        ['wp-api-fetch'], // Ensure wp-api-fetch is available
        null,
        true
    );

    // Enqueue the below-form specific script
    wp_enqueue_script(
        'responsefsf-belowform',
        plugin_dir_url(__FILE__) . 'inc/js/belowform.js',
        ['responsefsf-output'], // Depends on the shared output script
        null,
        true
    );

    // Enqueue the confirmation-specific script
    wp_enqueue_script(
        'responsefsf-confirmation',
        plugin_dir_url(__FILE__) . 'inc/js/confirmation.js',
        ['responsefsf-output'], // Depends on the shared output script
        null,
        true
    );


     // Enqueue the redirect-specific script
    wp_enqueue_script(
        'responsefsf-redirect',
        plugin_dir_url(__FILE__) . 'inc/js/redirect.js',
        null,
        true
    );

    // Pass REST URL and other localized data to the shared output script
    wp_localize_script('responsefsf-output', 'responsefsfData', [
        'restUrl' => esc_url_raw(rest_url()),
        'base_url' => get_site_url(),
        'webhookForms' => array_map('strval', array_keys(get_option('responsefsf_webhooks', []))),
    ]);
}

add_action('wp_enqueue_scripts', 'responsefsf_enqueue_output_scripts');

// to disable stylesheets use, define('RUP_RS4F_CUSTOMSTYLES', true); 
function responsefsf_enqueue_custom_styles() {
    // Check if the variable is not declared or set to false
    if ( ! defined('RUP_RS4F_CUSTOMSTYLES') || ! RUP_RS4F_CUSTOMSTYLES ) {
        // Enqueue the custom CSS file
        wp_enqueue_style(
            'responsefsf', // Handle for the stylesheet
            plugin_dir_url( __FILE__ ) . 'inc/css/output.css', // Path to the CSS file (relative to plugin directory)
            array(), // Dependencies (none in this case)
            null, // Version (optional)
            'all' // Media (optional, 'all' is the default)
        );
    }
}
add_action('wp_enqueue_scripts', 'responsefsf_enqueue_custom_styles');


function responsefsf_initialize_sureforms_licensing() {
    $client_path = plugin_dir_path( __FILE__ ) . 'inc/src/ConfigAwareClient.php';

    if ( ! file_exists( $client_path ) ) {
        error_log( 'ConfigAwareClient.php not found at: ' . $client_path );
        return;
    }

    if ( ! class_exists( 'ResponseFSF\\Licensing\\ConfigAwareClient' ) ) {
        require_once $client_path;
    }

    $client = new \ResponseFSF\Licensing\ConfigAwareClient(
        'Response for SureForms',
        'pt_usTzCchJQpYtKWCoRCusHS5P',
        RESPONSEFSF_PLUGIN_FILE
    );

    $client->set_textdomain( 'response-for-sureforms-textdomain' );
    $client->set_license_constant( 'RESPONSEFSF_LICENSE_KEY' );
    $client->infer_license_constant( true );
    $client->allow_db_fallback( true );

    $client->settings()->add_page(
        [
            'type'        => 'submenu',
            'parent_slug' => 'responsefsf_settings',
            'page_title'  => 'Manage License',
            'menu_title'  => 'Manage License',
            'capability'  => 'manage_options',
            'menu_slug'   => 'responsefsf_license_settings',
        ]
    );
}
add_action( 'init', 'responsefsf_initialize_sureforms_licensing' );
