<?php
// Exit if accessed directly.
// This file adds teh Webhook below form tag and also gives us the responsefsf Response
defined( 'ABSPATH' ) || exit;


function add_inline_webhook_response_snippet() {
    wp_enqueue_script('wp-hooks');
    wp_enqueue_script('wp-i18n');

    // Generate session ID
    $session_id = responsefsf_generate_session_id();
    $nonce = wp_create_nonce("responsefsf_nonce_{$session_id}");

    // Ensure the translations for the text domain are loaded
    
    $inline_script = <<<JS
    document.addEventListener("DOMContentLoaded", function() {
        const r = window.wp.hooks,
        o = window.wp.i18n;

        // Add "Webhook Response" to the confirmation options
        r.addFilter("srfm.formConfirmation.confirmationType.inputs", "responsefsf/form-confirmation", (inputs) => {
            const webhookOption = {
                label: o.__("Response For SureForms", "responsefsf"),
                value: "responsefsf_below_form",
                subOptionLabel: o.__("Response for SureForms", "responsefsf"),
                subOptions: [
                    {
                        label: o.__("Below Form", "responsefsf"),
                        value: "responsefsf_below_form"
                    },
                    {
                        label: o.__("Confirmation Page", "responsefsf"),
                        value: "responsefsf_confirmation_page"
                    },
                   {
                        label: o.__("Custom Redirect Page", "responsefsf"),
                        value: "responsefsf_redirect_page"
                    }
                ]
            };
            
            inputs.push(webhookOption);
            console.log("Webhook Response option added:", webhookOption);
            return inputs;
        });

        // Add session_id and nonce to forms dynamically
        document.querySelectorAll("form.srfm-form").forEach((form) => {
            form.setAttribute("data-session-id", "{$session_id}");
            form.setAttribute("data-nonce", "{$nonce}");
            console.log("Session ID and nonce added to form:", form);
        });
    });
    JS;

    wp_add_inline_script('wp-i18n', $inline_script);
}
add_action('admin_enqueue_scripts', 'add_inline_webhook_response_snippet');
