<?php
/** Admin management of SureForms form-to-webhook mappings. */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', 'responsefsf_admin_menu' );
function responsefsf_admin_menu() {
    add_menu_page( 'Response for SureForms Settings', 'Response 4 SF', 'manage_options', 'responsefsf_settings', 'render_responsefsf_admin_page', 'dashicons-feedback', 25 );
}

/** Load forms from SureForms' WordPress custom post type, not an entries table. */
function responsefsf_get_forms() {
    $post_type = defined( 'SRFM_FORMS_POST_TYPE' ) ? SRFM_FORMS_POST_TYPE : 'sureforms_form';
    $forms = get_posts( [
        'post_type'              => $post_type,
        'post_status'            => [ 'publish', 'draft', 'private', 'pending', 'future' ],
        'posts_per_page'         => -1,
        'orderby'                => 'title',
        'order'                  => 'ASC',
        'suppress_filters'       => false,
    ] );
    return is_array( $forms ) ? $forms : [];
}

function render_responsefsf_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'You do not have permission to manage these settings.', 'response-for-sureforms' ) );
    }
    echo '<div class="wrap"><h1>Response for SureForms Settings</h1>';
    if ( ! responsefsf_is_activated_and_licensed() ) {
        echo '<p>Please activate your license to access these settings.</p></div>';
        return;
    }

    $forms = responsefsf_get_forms();
    $form_names = [];
    foreach ( $forms as $form ) {
        $form_names[ (string) $form->ID ] = $form->post_title !== '' ? $form->post_title : sprintf( 'Untitled form #%d', $form->ID );
    }
    $form_webhooks = get_option( 'responsefsf_webhooks', [] );
    if ( ! is_array( $form_webhooks ) ) {
        $form_webhooks = [];
    }
    if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['responsefsf_save_mapping'] ) ) {
        check_admin_referer( 'save_responsefsf_settings', 'responsefsf_nonce' );
        $form_id = isset( $_POST['form_id'] ) ? absint( wp_unslash( $_POST['form_id'] ) ) : 0;
        $url = isset( $_POST['webhook_url'] ) ? esc_url_raw( wp_unslash( $_POST['webhook_url'] ) ) : '';
        // The strict wp_http_validate_url() check is for outbound requests, not saving settings.
        // It can reject otherwise valid endpoints (such as intranet or local test webhooks).
        $scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
        $host   = wp_parse_url( $url, PHP_URL_HOST );
        $valid_url = in_array( $scheme, [ 'http', 'https' ], true ) && is_string( $host ) && '' !== $host;
        if ( ! $form_id || ! isset( $form_names[ (string) $form_id ] ) ) {
            echo '<div class="notice notice-error"><p>Please select a valid SureForms form.</p></div>';
        } elseif ( ! $valid_url ) {
            echo '<div class="notice notice-error"><p>Please enter a full HTTP(S) webhook URL including its hostname.</p></div>';
        } else {
            $form_webhooks[ (string) $form_id ] = $url;
            update_option( 'responsefsf_webhooks', $form_webhooks );
            // WordPress returns false when the option is unchanged, so verify the stored value.
            $saved = get_option( 'responsefsf_webhooks', [] );
            if ( is_array( $saved ) && isset( $saved[ (string) $form_id ] ) && $saved[ (string) $form_id ] === $url ) {
                echo '<div class="notice notice-success"><p>Webhook mapping saved.</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>Mapping could not be saved. Please check your WordPress database permissions.</p></div>';
            }
        }
    }
    if ( isset( $_GET['delete_form_id'] ) ) {
        $delete_id = absint( wp_unslash( $_GET['delete_form_id'] ) );
        check_admin_referer( 'responsefsf_delete_' . $delete_id );
        if ( $delete_id && isset( $form_webhooks[ (string) $delete_id ] ) ) {
            unset( $form_webhooks[ (string) $delete_id ] );
            update_option( 'responsefsf_webhooks', $form_webhooks );
            echo '<div class="notice notice-success"><p>Webhook mapping deleted.</p></div>';
        }
    }
    if ( ! post_type_exists( defined( 'SRFM_FORMS_POST_TYPE' ) ? SRFM_FORMS_POST_TYPE : 'sureforms_form' ) ) {
        echo '<div class="notice notice-warning"><p>SureForms form post type is not registered. Ensure SureForms is active.</p></div>';
    }
    ?>
    <h2>Add or update a form webhook</h2>
    <p>Match a SureForms form to a webhook endpoint. Saving an existing form updates its mapping. Existing mappings are preserved when upgrading.</p>
    <form method="post">
        <?php wp_nonce_field( 'save_responsefsf_settings', 'responsefsf_nonce' ); ?>
        <table class="form-table"><tbody>
            <tr><th scope="row"><label for="form_id">Form</label></th><td>
                <select id="form_id" name="form_id" required>
                    <option value="">Select a form</option>
                    <?php foreach ( $forms as $form ) : ?>
                        <option value="<?php echo esc_attr( $form->ID ); ?>"><?php echo esc_html( $form_names[ (string) $form->ID ] . ' (#' . $form->ID . ', ' . $form->post_status . ')' ); ?></option>
                    <?php endforeach; ?>
                </select>
                <?php if ( empty( $forms ) ) : ?><p class="description">No SureForms forms were found.</p><?php endif; ?>
            </td></tr>
            <tr><th scope="row"><label for="webhook_url">Webhook URL</label></th><td><input class="regular-text" type="url" id="webhook_url" name="webhook_url" required placeholder="https://example.com/webhook" /></td></tr>
        </tbody></table>
        <?php submit_button( 'Save Mapping', 'primary', 'responsefsf_save_mapping' ); ?>
    </form>
    <h2>Existing form webhooks</h2>
    <table class="widefat striped"><thead><tr><th>Form ID</th><th>Form name</th><th>Webhook URL</th><th>Actions</th></tr></thead><tbody>
    <?php if ( $form_webhooks ) : foreach ( $form_webhooks as $form_id => $webhook_url ) : ?>
        <tr><td><?php echo esc_html( $form_id ); ?></td><td><?php echo esc_html( $form_names[ (string) $form_id ] ?? 'Unknown / deleted form' ); ?></td>
        <td><code><?php echo esc_html( $webhook_url ); ?></code></td>
        <td><a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'page' => 'responsefsf_settings', 'delete_form_id' => absint( $form_id ) ], admin_url( 'admin.php' ) ), 'responsefsf_delete_' . absint( $form_id ) ) ); ?>" onclick="return confirm('Delete this webhook mapping?');">Delete</a></td></tr>
    <?php endforeach; else : ?><tr><td colspan="4">No webhook mappings found.</td></tr><?php endif; ?>
    </tbody></table></div>
    <?php
}
