// redirectform.js - Handles redirect on srfm_on_show_success_message event
//console.log("Redirect Loaded V1");
document.addEventListener("srfm_on_show_success_message", async (event) => {
    const { submitType, form, loader } = event.detail;

    // Only handle if the 'responsefsf_redirect_page' option is selected
    if (submitType !== "responsefsf_redirect_page") {
        console.log("Redirect redirect_page not selected. Exiting.");
        return;
    }

    console.log("Redirect option detected. Initiating response fetch...");
    event.preventDefault();

    // Get session ID and form ID from the form if not already set
    const sessionId = form.querySelector("input[name='session_id']")?.value || await injectSessionId(form);
    const formId = form.querySelector("input[name='form-id']")?.value;

    if (!sessionId || !formId) {
        console.error("Missing session_id or form_id.");
        return;
    }

    // Now submit the form and fetch the response
    await submitFormAndFetchResponse(form, sessionId, formId);
});

// Function to submit form data and fetch response
async function submitFormAndFetchResponse(form, sessionId, formId) {
    // Create and append the progress box to the form container
    const container = form.closest(".srfm-form-container");
    createProgressBox(container);

    // Start polling for the response
    await pollForRedirectResponse(form, sessionId, formId, container);
}

// General polling function for redirect responses
async function pollForRedirectResponse(form, sessionId, formId, container = null) {
    let attemptCount = 0;
    const retryInterval = 2000; // Retry every 2 seconds
    const maxAttempts = 40; // Allow up to 40 retries

    const loader = form.querySelector(".srfm-loader");

    while (attemptCount < maxAttempts) {
        console.log(`Polling attempt #${attemptCount + 1}`);

        try {
            const response = await fetch(`/wp-json/responsefsf/v1/receive-response?session_id=${sessionId}&form_id=${formId}`);
            const data = await response.json();

            console.log(`Polling data received (attempt #${attemptCount + 1}):`, data);

            if (data?.redirect_url) {
                console.log("Valid redirect URL received. Redirecting now.");
                window.location.href = data.redirect_url;
                return;
            }
        } catch (error) {
            console.error(`Error during polling attempt #${attemptCount + 1}:`, error);
        }

        attemptCount++;
        await new Promise((resolve) => setTimeout(resolve, retryInterval));
    }

    console.warn("Max polling attempts reached. No redirect URL received.");
    setTimeout(() => {
        loader?.classList.remove("srfm-active");
        displayFailureMessage(form, "No response was received. Please try again later.");
    }, 1500);
}

// Function to create and append the progress box
function createProgressBox(container) {
    const progressBox = document.createElement("div");
    progressBox.id = "responsefsf-progress-box";
    progressBox.innerHTML = "";

    container.appendChild(progressBox);
    progressBox.style.display = "block";
    console.log("Progress box displayed.");
}

// Function to display the failure message below the form
function displayFailureMessage(form, message) {
    const errorContainer = document.createElement('div');
    errorContainer.className = 'polling-error-message';
    errorContainer.textContent = message;
    form.appendChild(errorContainer);
}
