//console.log("Shared Output Functions Loaded v1.2");

// Session ID Injection
document.addEventListener("DOMContentLoaded", async () => {
    const forms = document.querySelectorAll('form.srfm-form');

    try {
        const response = await fetch(`${responsefsfData.base_url}/wp-json/responsefsf/v1/session-id`);
        const data = await response.json();

        if (data?.session_id) {
            forms.forEach((form) => {
                if (!form.querySelector("input[name='session_id']")) {
                    const hiddenField = document.createElement("input");
                    hiddenField.type = "hidden";
                    hiddenField.name = "session_id";
                    hiddenField.value = data.session_id;
                    form.appendChild(hiddenField);
                    //console.log("Session ID injected into form:", form);
                }
            });
        } else {
            console.error("Failed to fetch session ID. Response:", data);
        }
    } catch (error) {
        console.error("Error fetching session ID:", error);
    }
});


// Function to display the failure message
function displayFailureMessage(container, message) {
    console.log("Displaying failure message:", message);
    const progressBox = container.querySelector("#responsefsf-progress-box");
    if (progressBox) {
        progressBox.innerHTML = `<h3 class="responsefsf-text">Error</h3><p class="responsefsf-text">${message}</p>`;
    }
}
// Function to display the final response (works for both Confirmation and Below Form)
function displayResponseInContainer(container, data, formType = 'below') {
    console.log("Received data:", data);
    console.log("Displaying final response...");

    // Find or create a progress box container inside the srfm-form-container
    let progressBox = container.querySelector("#responsefsf-progress-box");

    // If the progress box doesn't exist, create one
    if (!progressBox) {
        progressBox = document.createElement("div");
        progressBox.id = "responsefsf-progress-box"; // Give it an ID for styling
        progressBox.style.width = "100%"; // Ensure it fills the form container width
        container.appendChild(progressBox); // Append to the container without clearing the form
    }

    progressBox.innerHTML = "";  // Clear the progress box (if any)

    const responseContainer = document.createElement("div");
    responseContainer.classList.add("responsefsf-inner-container");

    // Append the body content if allowed
    if (data.body_display === 'yes' && data.body) {
        console.log("Appending body to response container.");
        const bodyContent = document.createElement("div");
        bodyContent.classList.add("response-body");
        bodyContent.innerHTML = data.body;
        responseContainer.appendChild(bodyContent);
    }

    // Handle and embed PDFs
    if (data.pdf?.html) {
        const pdfContent = document.createElement("div");
        pdfContent.classList.add("response-pdf");
        let pdfUrl = data.pdf.html;

        if (pdfUrl.includes("<a href=")) {
            const tempDiv = document.createElement("div");
            tempDiv.innerHTML = pdfUrl;
            pdfUrl = tempDiv.querySelector("a")?.href;
        }

        if (pdfUrl && pdfUrl.startsWith("http")) {
            const iframe = document.createElement("iframe");
            iframe.src = pdfUrl;
            iframe.style.border = "none";

            pdfContent.appendChild(iframe);
            responseContainer.appendChild(pdfContent);
        }
    }

    // Handle media content (Video / Audio) with conditional checks
    if (data.has_video && data.video_url) {
        const videoContainer = document.createElement("div");
        videoContainer.classList.add("media-wrapper");

        const iframe = document.createElement("iframe");
        iframe.src = data.video_url
            .replace("youtu.be/", "www.youtube.com/embed/")
            .replace("/watch?v=", "/embed/")
            .replace("vimeo.com", "player.vimeo.com/video");
        iframe.allowFullscreen = true;
        videoContainer.appendChild(iframe);

        responseContainer.appendChild(videoContainer);
    }

    if (data.has_audio && data.audio_url) {
        const audio = document.createElement("audio");
        audio.src = data.audio_url;
        audio.controls = true;
        audio.classList.add("audio-player");
        responseContainer.appendChild(audio);
    }

    // Append the link content if provided
    if (data.link) {
        const linkContent = document.createElement("div");
        linkContent.classList.add("responsefsf-link");
        linkContent.innerHTML = data.link;
        responseContainer.appendChild(linkContent);
    }

    // Append the image content if available
    if (data.image?.html) {
        const imageContent = document.createElement("div");
        imageContent.classList.add("responsefsf-image");
        imageContent.innerHTML = data.image.html;
        responseContainer.appendChild(imageContent);
    }

    // Create buttons container
    const buttonsContainer = document.createElement("div");
    buttonsContainer.classList.add("responsefsf-buttons");

    // SVG for the buttons
    const copySVG = `
        <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" fill="none">
            <path d="M13.333 6H7.333a1.333 1.333 0 0 0-1.333 1.333v6a1.333 1.333 0 0 0 1.333 1.333h6a1.333 1.333 0 0 0 1.333-1.333v-6A1.333 1.333 0 0 0 13.333 6Z" stroke="#000" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M3.333 10.003H2.667a1.333 1.333 0 0 1-1.333-1.334V2.67A1.333 1.333 0 0 1 2.667 1.336h6a1.333 1.333 0 0 1 1.333 1.333v.667" stroke="#000" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`;


    const backSVG = `
    <svg fill="#000000" width="16" height="16" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <g data-name="Layer 2">
            <g data-name="arrow-back">
                <rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/>
                <path d="M19 11H7.14l3.63-4.36a1 1 0 1 0-1.54-1.28l-5 6a1.19 1.19 0 0 0-.09.15c0 .05 0 .08-.07.13A1 1 0 0 0 4 12a1 1 0 0 0 .07.36c0 .05 0 .08.07.13a1.19 1.19 0 0 0 .09.15l5 6A1 1 0 0 0 10 19a1 1 0 0 0 .64-.23 1 1 0 0 0 .13-1.41L7.14 13H19a1 1 0 0 0 0-2z"/>
            </g>
        </g>
    </svg>
`;


    // Add the back button for Confirmation Form only
    if (data.enable_back_button) {
        const backButton = document.createElement("button");
        backButton.classList.add("responsefsf-button");
        backButton.innerHTML = `${backSVG} Back`; // Reusing the same SVG for now
        backButton.addEventListener("click", () => {
            location.reload();
        });
        buttonsContainer.appendChild(backButton);
    }

    // Add the copy button
    if (data.copy_button) {
        const copyButton = document.createElement("button");
        copyButton.classList.add("responsefsf-button");
        copyButton.innerHTML = `${copySVG} Copy`;
        copyButton.addEventListener("click", () => {
            navigator.clipboard.writeText(data.body || "No response data available.").then(() => {
                console.log("Response copied to clipboard.");
                copyButton.innerHTML = `${copySVG} Copied!`;
                setTimeout(() => {
                    copyButton.innerHTML = `${copySVG} Copy`;
                }, 1500);
            });
        });
        buttonsContainer.appendChild(copyButton);
    }

    // Append buttons container
    responseContainer.appendChild(buttonsContainer);

    // Append the response container to the progress box
    progressBox.appendChild(responseContainer);

    // Scroll to the response
    responseContainer.scrollIntoView({ behavior: "smooth" });
}



