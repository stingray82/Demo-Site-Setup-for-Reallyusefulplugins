//console.log("Version 0.2");
// Change to srfm_on_show_success_message from SRFM_Form_Success_Message in V1.1
document.addEventListener("srfm_on_show_success_message", async (event) => {
    const { submitType, form, loader } = event.detail;

    // Only handle if the 'responsefsf_below_form' option is selected
    if (submitType !== "responsefsf_below_form") {
        console.log("Webhook Below Form option not selected. Exiting.");
        return;
    }

    console.log("Webhook Below Form option detected. Initiating response fetch...");
    event.preventDefault();

    // Get session ID and form ID from the form if not already set
    const sessionId = form.querySelector("input[name='session_id']")?.value || await injectSessionId(form);
    const formId = form.querySelector("input[name='form-id']")?.value;

    if (!sessionId || !formId) {
        console.error("Missing session_id or form_id.");
        return;
    }

    // Now submit the form and fetch the response
    await submitFormAndFetchResponsebelow(form, sessionId, formId);
});

// Function to submit form data and fetch response
async function submitFormAndFetchResponsebelow(form, sessionId, formId) {
    // Create and append the progress box to the form container
    const container = form.closest(".srfm-form-container");
    createProgressBox(container);

    // Start polling for the response
    await pollForResponsebelow(form, sessionId, formId, container);
}

// General polling function to be reused for both belowform and confirmation
async function pollForResponsebelow(form, sessionId, formId, container = null) {
    let attemptCount = 0;
    const retryInterval = 2000; // Retry every 2 seconds
    const maxAttempts = 40; // Allow up to 40 retries

    // Optional: You can pass a container to show failure message if needed
    const showFailureMessage = container ? displayFailureMessage : () => {};

    // Select the loader to hide later
    const loader = form.querySelector(".srfm-loader");

    while (attemptCount < maxAttempts) {
        console.log(`Polling attempt #${attemptCount + 1}`);

        try {
            const response = await fetch(`${responsefsfData.base_url}/wp-json/responsefsf/v1/receive-response?session_id=${sessionId}&form_id=${formId}`);
            const data = await response.json();

            console.log(`Polling data received (attempt #${attemptCount + 1}):`, data);

            if (data?.body) {
                console.log("Valid response data received. Stopping progress simulation and displaying response.");

                // Stop polling once a valid response is received
                if (container) {
                    setTimeout(() => {
                        displayResponseInContainer(container, data);
                        // After response is displayed, remove the loader
                        loader?.classList.remove("srfm-active");
                    }, 1500); // Delay the display to simulate response generation time
                }

                return; // Exit polling loop
            }
        } catch (error) {
            console.error(`Error during polling attempt #${attemptCount + 1}:`, error);
        }

        attemptCount++;

        // Wait for the retry interval before the next polling attempt
        await new Promise((resolve) => setTimeout(resolve, retryInterval));
    }

    console.warn("Max polling attempts reached. No response received.");

    // Hide the loader if no response after max attempts
    setTimeout(() => {
        loader?.classList.remove("srfm-active");
        showFailureMessage(form, "No response was received. Please try again later.");
    }, 1500); // Delay the failure message for better UX
}



// Function to create and append the progress box
function createProgressBox(container) {
    // Create the progress box container
    const progressBox = document.createElement("div");
    progressBox.id = "responsefsf-progress-box";
    progressBox.innerHTML = ``;

    // Append progress box to the container
    container.appendChild(progressBox);
    progressBox.style.display = "block";
    console.log("Progress box displayed.");
}

// Function to display the failure message below the form
function displayFailureMessage(form, message) {
    const errorContainer = document.createElement('div');
    errorContainer.className = 'polling-error-message'; // Add a class for styling if needed
    errorContainer.textContent = message;

    // Append the message to the form
    form.appendChild(errorContainer);
}
