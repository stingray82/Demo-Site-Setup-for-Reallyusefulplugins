//console.log("Output Confirmation v1");

document.addEventListener("DOMContentLoaded", () => {
    //console.log("Confirmation script loaded and parsed.");

    // Process each form on the page
    document.querySelectorAll(".srfm-form").forEach(async (form) => {
        // Check the form type
        const submitType = form.getAttribute("message-type"); // Detect the message type

        if (submitType === "responsefsf_confirmation_page") {
            //console.log("Confirmation Page Confirmed");
        } else {
            //console.log("Form is not a confirmation form'. Skipping.");
        }

        // Add form submission listener
        form.addEventListener("submit", async (event) => {
            event.preventDefault(); // Prevent the default submission
            //console.log("Form submission intercepted:", form);

            // Fetch necessary attributes and hidden fields
            const sessionId = form.querySelector("input[name='session_id']")?.value;
            const formId = form.querySelector("input[name='form-id']")?.value;

            if (submitType === "responsefsf_confirmation_page") {
                console.log("Confirmation Page option detected. Proceeding...");

                if (sessionId && formId) {
                    console.log("Session ID and Form ID found:", { sessionId, formId });

                    const container = form.closest(".srfm-form-container");
                    if (container) {
                        console.log("Form container located. Hiding children except progress box.");
                        hideContainerChildrenExceptProgress(container);
                    } else {
                        console.error("Unable to locate form container.");
                        return; // Exit if the container is missing
                    }

                    // Proceed with custom submission and response handling
                    await submitFormAndFetchResponseConfirmation(container, form, sessionId, formId);
                } else {
                    console.error("Missing session ID or form ID.");
                    displayFailureMessage(
                        form.closest(".srfm-form-container"),
                        "Missing session ID or form ID. Please try again."
                    );
                }
            } else {
                console.log("Submit type does not match 'responsefsf_confirmation_page'. Skipping...");
            }
        });
    });
});


// Function to hide all container children except the progress box
// Consider Moving if we add other confirmation types
function hideContainerChildrenExceptProgress(container) {
    console.log("Hiding container children, except the progress box.");
    Array.from(container.children).forEach((child) => {
        if (child.id !== "responsefsf-progress-box") {
            child.style.display = "none";
        }
    });

    let progressBox = container.querySelector("#responsefsf-progress-box");
    if (!progressBox) {
        console.log("Creating progress box.");
        progressBox = document.createElement("div");
        progressBox.id = "responsefsf-progress-box";
        progressBox.innerHTML = `
            <div class="responsefsf-inner-container">
                <h3 class="responsefsf-generating">We are generating your response...</h3>
                <div id="progress-circle-container" class="progress-circle-container">
                    <svg width="100" height="100">
                        <circle cx="50" cy="50" r="45" fill="none" stroke="#eaeaea" stroke-width="10"></circle>
                        <circle id="progress-circle" cx="50" cy="50" r="45" fill="none" stroke="#7f56d9" stroke-width="10" stroke-dasharray="282.6" stroke-dashoffset="282.6" stroke-linecap="round"></circle>
                    </svg>
                    <div id="progress-percentage" class="responsefsf-text" style="padding-bottom: 20px;">0%</div> <!-- Added padding -->
                </div>
            </div>
        `;
        container.appendChild(progressBox);
    }
    progressBox.style.display = "block";
    console.log("Progress box displayed.");
}

// Function to submit form data and fetch response
async function submitFormAndFetchResponseConfirmation(container, form, sessionId, formId) {
    console.log("Submitting form data to fetch response...");
    const responseEndpoint = `${responsefsfData.base_url}/wp-json/responsefsf/v1/receive-response`;
    const progressCircle = container.querySelector("#progress-circle");
    const progressPercentage = container.querySelector("#progress-percentage");
    let progress = 0;

    // Simulate gradual progress up to 90%
    console.log("Starting progress simulation.");
    const updateProgress = setInterval(() => {
        if (progress < 90) {
            progress += Math.random() * 2; // Adjust speed of progress
            const offset = 282.6 - (progress / 100) * 282.6;
            progressCircle.style.strokeDashoffset = offset;
            progressPercentage.textContent = `${Math.min(Math.round(progress), 90)}%`;
        }
    }, 500);

    const formData = new FormData(form);
    formData.append("session_id", sessionId);
    formData.append("form_id", formId); 
    await pollForResponsepage(container, sessionId, formId, progressCircle, progressPercentage, progress);
}


async function pollForResponsepage(container, sessionId, formId, progressCircle, progressPercentage) {
    console.log("Starting polling for response...");
    let attemptCount = 0;
    const retryInterval = 3000; // Increased retry interval to 3 seconds
    const maxAttempts = 40; // Allow up to 40 retries
    let currentProgress = 0;

    const updateProgress = (attempt) => {
        const targetProgress = Math.min((attempt / maxAttempts) * 90, 90);
        smoothProgressUpdate(progressCircle, progressPercentage, targetProgress, currentProgress);
        currentProgress = targetProgress;
    };

    // Show "waiting" message
    const waitingMessage = document.createElement('div');
    waitingMessage.className = 'waiting-message';
    //waitingMessage.textContent = 'Processing, please wait...'; // Optional text message
    container.appendChild(waitingMessage);

    // Wait for the srfm_on_show_success_message event before proceeding with polling
    await new Promise((resolve) => {
        document.addEventListener("srfm_on_show_success_message", (event) => {
            const { submitType, form } = event.detail;

            // Only proceed with polling if the correct submit type is selected
            if (submitType === "responsefsf_confirmation_page") {
                console.log("Received srfm_on_show_success_message. Starting polling.");
                resolve(); // Proceed with polling after the event is received
            } else {
                console.log("Webhook for confirmation page not selected. Exiting.");
            }
        });
    });

    // Start polling after the event is received
    while (attemptCount < maxAttempts) {
        console.log(`Polling attempt #${attemptCount + 1}`);
        updateProgress(attemptCount);

        try {
            const response = await fetch(`${responsefsfData.base_url}/wp-json/responsefsf/v1/receive-response?session_id=${sessionId}&form_id=${formId}`);
            const data = await response.json();
            console.log(`Polling data received (attempt #${attemptCount + 1}):`, data);

            if (data?.body) {
                console.log("Valid response data received. Stopping progress simulation and displaying response.");
                smoothProgressUpdate(progressCircle, progressPercentage, 100, currentProgress);

                // Remove the waiting message and show response
                waitingMessage.remove();
                setTimeout(() => displayResponseInContainer(container, data), 1500);
                return;
            }

            if (data?.code === 'not_found') {
                console.log("Response not ready yet, retrying...");
                continue;
            }
        } catch (error) {
            console.error(`Error during polling attempt #${attemptCount + 1}:`, error);
        }

        attemptCount++;
        await new Promise((resolve) => setTimeout(resolve, retryInterval)); // Wait before next retry
    }

    console.warn("Max polling attempts reached. No response received.");

    // Remove the waiting message and show failure
    waitingMessage.remove();
    displayFailureMessage(container, "No response was received. Please try again later.");
}



function smoothProgressUpdate(progressCircle, progressPercentage, targetProgress, currentProgress = 0) {
    const animate = () => {
        if (currentProgress < targetProgress) {
            currentProgress += 0.5; // Adjust speed
            const offset = 282.6 - (currentProgress / 100) * 282.6;
            progressCircle.style.strokeDashoffset = offset;
            progressPercentage.textContent = `${Math.round(currentProgress)}%`;
            requestAnimationFrame(animate);
        }
    };
    animate();
}
