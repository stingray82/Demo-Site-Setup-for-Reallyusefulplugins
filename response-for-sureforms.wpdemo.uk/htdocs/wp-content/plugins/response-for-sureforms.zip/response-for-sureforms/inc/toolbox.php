<?php
defined( 'ABSPATH' ) || exit;

// Generates a session ID for responsefsf
function responsefsf_generate_session_id() {
    return uniqid( 'responsefsf_', true );
}

// Generates a response URL for responsefsf
function responsefsf_generate_response_url( $session_id, $form_id ) {
    return get_rest_url( null, "responsefsf/v1/response/{$session_id}/{$form_id}" );
}

// Verifies the nonce for responsefsf token
function responsefsf_verify_nonce( $nonce, $session_id ) {
    $stored_nonce = get_transient( "responsefsf_nonce_{$session_id}" );
    return hash_equals( $stored_nonce, $nonce );
}

// Sets result data in a transient
function responsefsf_set_result_transient( $session_id, $form_id, $data ) {
    set_transient( "responsefsf_result_{$session_id}_{$form_id}", $data, HOUR_IN_SECONDS );
}

// Gets result data from a transient
function responsefsf_get_result_transient( $session_id, $form_id ) {
    return get_transient( "responsefsf_result_{$session_id}_{$form_id}" );
}

// Processes and retrieves attachment data for a given URL
function responsefsf_process_attachment( $attachment_url ) {
    if ( empty( $attachment_url ) ) {
        return [];
    }

    $attachment_res = wp_remote_head( esc_url_raw( $attachment_url ) );

    if ( ! is_wp_error( $attachment_res ) ) {
        return [
            'status' => wp_remote_retrieve_response_code( $attachment_res ),
            'type'   => wp_remote_retrieve_header( $attachment_res, 'content-type' ),
            'size'   => [
                'bytes'     => intval( wp_remote_retrieve_header( $attachment_res, 'content-length' ) ),
                'formatted' => size_format( wp_remote_retrieve_header( $attachment_res, 'content-length' ) ),
            ],
            'html'   => '<a href="' . esc_url( $attachment_url ) . '" download>Download Attachment</a>',
            'link'   => $attachment_url,
        ];
    }

    return [];
}

/**
 * Get the licensing client.
 *
 * @return \ResponseFSF\Licensing\ConfigAwareClient
 */
function responsefsf_get_client() {
    static $client = null;

    if ( null === $client ) {
        $client = new \ResponseFSF\Licensing\ConfigAwareClient(
            'Response for SureForms',
            'pt_usTzCchJQpYtKWCoRCusHS5P',
            RESPONSEFSF_PLUGIN_FILE
        );

        $client->set_textdomain( 'response-for-sureforms-textdomain' );
        $client->set_license_constant( 'RESPONSEFSF_LICENSE_KEY' );
        $client->infer_license_constant( true );
        $client->allow_db_fallback( true );
    }

    return $client;
}

/**
 * Check if the plugin is activated and licensed.
 *
 * @return bool
 */
function responsefsf_is_activated_and_licensed() {
    try {
        $client = responsefsf_get_client();
    } catch ( \Throwable $e ) {
        return false;
    }

    if ( ! $client ) {
        return false;
    }

    try {
        $settings   = $client->settings();
        $license    = $client->license();
        $activation = $client->activation();
    } catch ( \Throwable $e ) {
        return false;
    }

    $license_key   = $settings->license_key;
    $activation_id = $settings->activation_id;

    if ( empty( $license_key ) || empty( $activation_id ) ) {
        return false;
    }

    $valid = $license->is_valid( $license_key );
    if ( is_wp_error( $valid ) || true !== $valid ) {
        return false;
    }

    $activation_data = $activation->get( $activation_id );
    if ( is_wp_error( $activation_data ) ) {
        return false;
    }

    if ( empty( $activation_data ) || empty( $activation_data->id ) ) {
        return false;
    }

    return true;
}
