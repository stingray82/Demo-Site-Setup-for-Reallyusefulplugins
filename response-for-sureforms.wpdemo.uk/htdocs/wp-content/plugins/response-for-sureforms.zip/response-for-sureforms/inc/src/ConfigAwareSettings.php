<?php

namespace ResponseFSF\Licensing;

if ( ! class_exists( __NAMESPACE__ . '\Settings' ) ) {
	require_once __DIR__ . '/Settings.php';
}

/**
 * Config-aware Settings class.
 *
 * Reads license keys from wp-config.php constants first and suppresses
 * raw license-key persistence to the database.
 *
 * Supports a runtime-only override so manual activation still works even when
 * a config key exists.
 *
 * Also fixes the native SDK menu page so it does not print the wp-config key
 * into the input field, while still allowing blank submit to use the config key.
 */
class ConfigAwareSettings extends Settings {
	protected $using_config_license = null;
	protected $runtime_license_key = null;

	public function get_license_constant_name() {
		if ( method_exists( $this->client, 'get_license_constant' ) ) {
			$explicit = $this->client->get_license_constant();
			if ( ! empty( $explicit ) ) {
				return $explicit;
			}
		}

		if ( method_exists( $this->client, 'should_infer_license_constant' ) && $this->client->should_infer_license_constant() ) {
			return $this->client->get_inferred_license_constant();
		}

		return null;
	}

	public function get_config_license_key() {
		$constant = $this->get_license_constant_name();
		if ( empty( $constant ) ) {
			$this->using_config_license = false;
			return null;
		}

		if ( defined( $constant ) ) {
			$value = constant( $constant );
			$value = is_string( $value ) ? trim( $value ) : '';

			if ( '' !== $value ) {
				$this->using_config_license = true;
				return $value;
			}
		}

		$this->using_config_license = false;
		return null;
	}

	public function set_runtime_license_key( $key ) {
		$this->runtime_license_key = is_string( $key ) ? trim( $key ) : null;
		return $this;
	}

	public function clear_runtime_license_key() {
		$this->runtime_license_key = null;
		return $this;
	}

	public function is_config_license_mode() {
		if ( null !== $this->runtime_license_key && '' !== $this->runtime_license_key ) {
			return false;
		}

		if ( null === $this->using_config_license ) {
			$this->get_config_license_key();
		}

		return (bool) $this->using_config_license;
	}

	public function __get( $name ) {
		if ( 'license_key' === $name ) {
			if ( null !== $this->runtime_license_key && '' !== $this->runtime_license_key ) {
				return $this->runtime_license_key;
			}

			$config_key = $this->get_config_license_key();
			if ( ! empty( $config_key ) ) {
				return $config_key;
			}

			if ( method_exists( $this->client, 'should_allow_db_fallback' ) && ! $this->client->should_allow_db_fallback() ) {
				return null;
			}
		}

		return parent::__get( $name );
	}

	public function __set( $name, $value ) {
		if ( 'license_key' === $name ) {
			$config_key = $this->get_config_license_key();

			// If a wp-config key exists, never persist the raw key.
			if ( ! empty( $config_key ) ) {
				$this->set_runtime_license_key( $value );
				return true;
			}
		}

		if ( 'license_id' === $name ) {
			$config_key = $this->get_config_license_key();

			// If config mode is active, do not persist license_id.
			if ( ! empty( $config_key ) ) {
				return true;
			}
		}

		return parent::__set( $name, $value );
	}

	public function should_allow_manual_license_entry() {
		return true;
	}

	public function get_config_license_notice() {
		$constant = $this->get_license_constant_name();
		if ( empty( $constant ) ) {
			return '';
		}

		$config_key = $this->get_config_license_key();
		if ( empty( $config_key ) ) {
			return '';
		}

		return sprintf(
			$this->client->__( 'A license key is available from wp-config.php via %s. Leave the field blank to use it, or enter a different key manually for this request.' ),
			$constant
		);
	}

	/**
	 * Native SDK menu form submit handler.
	 *
	 * Fixes native settings pages so blank submit can use the wp-config key,
	 * while still allowing manual entry and never persisting the raw config key.
	 *
	 * @return void
	 */
	public function license_form_submit() {
		if ( ! isset( $_POST['submit'] ) ) {
			return;
		}

		if ( ! isset( $_POST['_nonce'], $_POST['_action'] ) ) {
			$this->add_error( 'missing_info', $this->client->__( 'Please add all information' ) );
			return;
		}

		if ( ! wp_verify_nonce( $_POST['_nonce'], $this->client->name ) ) {
			$this->add_error( 'unauthorized', $this->client->__( "You don't have permission to manage licenses." ) );
			return;
		}

		if ( 'activate' === $_POST['_action'] ) {
			$key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';

			// Blank submit should use wp-config key when available.
			if ( empty( $key ) ) {
				$key = $this->get_config_license_key();
			}

			if ( ! empty( $key ) ) {
				$this->set_runtime_license_key( $key );
			}

			$activated = $this->client->license()->activate( $key );

			if ( is_wp_error( $activated ) ) {
				$this->add_error( $activated->get_error_code(), $activated->get_error_message() );
				$this->clear_runtime_license_key();
				return;
			}

			if ( ! empty( $this->menu_args['activated_redirect'] ) ) {
				$this->clear_runtime_license_key();
				$this->redirect( $this->menu_args['activated_redirect'] );
				exit;
			}

			$this->clear_runtime_license_key();
			$this->add_success( 'activated', $this->client->__( 'This site was successfully activated.', 'surecart' ) );
			return;
		}

		if ( 'deactivate' === $_POST['_action'] ) {
			$deactivated = $this->client->license()->deactivate( sanitize_text_field( $_POST['activation_id'] ) );

			if ( is_wp_error( $deactivated ) ) {
				$this->add_error( $deactivated->get_error_code(), $deactivated->get_error_message() );
			}

			if ( ! empty( $this->menu_args['deactivated_redirect'] ) ) {
				$this->redirect( $this->menu_args['deactivated_redirect'] );
				exit;
			}

			$this->add_success( 'deactivated', $this->client->__( 'This site was successfully deactivated.', 'surecart' ) );
			return;
		}
	}

	/**
	 * Native SDK settings page output.
	 *
	 * Prevents the raw wp-config key from being printed into the HTML input value.
	 *
	 * @return void
	 */
	public function settings_output() {
		$this->license_form_submit();

		$this->print_css();

		$activation = $this->get_activation();
		$action     = ! empty( $activation->id ) ? 'deactivate' : 'activate';
		$config_notice = $this->get_config_license_notice();
		$show_prefilled_key = ! $this->get_config_license_key();
		?>
		<div class="wrap">
			<h1></h1>
			<?php settings_errors(); ?>

			<div class="<?php echo esc_attr( strtolower( preg_replace( '/\s+/', '', $this->client->name ) ) ) . '-form-container'; ?>">
				<form method="post" action="<?php echo esc_attr( apply_filters( 'surecart_client_license_form_action', '' ) ); ?>">
					<input type="hidden" name="_action" value="<?php echo esc_attr( $action ); ?>">
					<input type="hidden" name="_nonce" value="<?php echo esc_attr( wp_create_nonce( $this->client->name ) ); ?>">
					<input type="hidden" name="activation_id" value="<?php echo esc_attr( $this->activation_id ); ?>">

					<h2><?php echo esc_html( $this->menu_args['page_title'] ); ?></h2>

					<label for="license_key">
						<?php if ( 'activate' === $action ) : ?>
							<?php echo esc_html( sprintf( $this->client->__( 'Enter your license key to activate %s.', 'surecart' ), $this->client->name ) ); ?>
						<?php else : ?>
							<?php echo esc_html( sprintf( $this->client->__( 'Your license is succesfully activated for this site.', 'surecart' ), $this->client->name ) ); ?>
						<?php endif; ?>
					</label>

					<?php if ( ! empty( $config_notice ) ) : ?>
						<p class="description"><?php echo esc_html( $config_notice ); ?></p>
					<?php endif; ?>

					<?php if ( 'activate' === $action ) : ?>
						<input
							class="widefat"
							type="password"
							autocomplete="off"
							name="license_key"
							id="license_key"
							value="<?php echo esc_attr( $show_prefilled_key ? $this->license_key : '' ); ?>"
							placeholder="<?php echo esc_attr( ! empty( $config_notice ) ? $this->client->__( 'Leave blank to use the wp-config.php key, or enter a different key.' ) : '' ); ?>"
							autofocus
						>
					<?php endif; ?>

					<?php if ( isset( $_GET['debug'] ) ) : ?>
						<label for="license_id"><?php echo esc_html( sprintf( $this->client->__( 'License ID', 'surecart' ), $this->client->name ) ); ?></label>
						<input class="widefat" type="text" autocomplete="off" name="license_id" id="license_id" value="<?php echo esc_attr( $this->license_id ); ?>" autofocus>

						<label for="activation_id"><?php echo esc_html( sprintf( $this->client->__( 'Activation ID', 'surecart' ), $this->client->name ) ); ?></label>
						<input class="widefat" type="text" autocomplete="off" name="activation_id" id="activation_id" value="<?php echo esc_attr( $this->activation_id ); ?>" autofocus>
					<?php endif; ?>

					<?php submit_button( 'activate' === $action ? $this->client->__( 'Activate License' ) : $this->client->__( 'Deactivate License' ) ); ?>
				</form>
			</div>
		</div>
		<?php
	}
}
