<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! class_exists( 'RUP_License_Box', false ) ) {
class RUP_License_Box {

    /**
     * Render a transient notice created by the bootstrap handler.
     *
     * @param string $action_slug Form action slug.
     * @return void
     */
    protected static function render_notice( $action_slug ) {
        $notice_key = preg_replace( '/_license$/', '', $action_slug ) . '_license_notice';
        $notice     = get_transient( $notice_key );

        if ( empty( $notice ) || empty( $notice['message'] ) ) {
            return;
        }

        $type = ! empty( $notice['type'] ) ? $notice['type'] : 'info';

        delete_transient( $notice_key );
        ?>
        <div class="notice notice-<?php echo esc_attr( $type ); ?> is-dismissible">
            <p><?php echo esc_html( $notice['message'] ); ?></p>
        </div>
        <?php
    }

    public static function render( array $config ) {

        $defaults = [
            'id'               => 'rup-license-box',
            'title'            => 'License',
            'action'           => 'rup_license',
            'client_callback'  => null,
            'redirect'         => admin_url(),
            'textdomain'       => 'default',
            'active_message'   => 'Your license is active.',
            'inactive_message' => 'Enter your license key to activate this plugin.',
            'placeholder'      => 'License key…',
            'activate_label'   => 'Activate License',
            'deactivate_label' => 'Deactivate License',
            'toggle_aria'      => 'Toggle license box',
            'namespace'        => 'SureCart\\Licensing',
            'box_class'        => '',
        ];

        $args = array_merge( $defaults, $config );

        if ( empty( $args['client_callback'] ) || ! is_callable( $args['client_callback'] ) ) {
            echo '<p>' . esc_html__( 'Licensing client callback is not configured.', $args['textdomain'] ) . '</p>';
            return;
        }

        $client = call_user_func( $args['client_callback'] );
        if ( ! $client || ! method_exists( $client, 'settings' ) || ! method_exists( $client, 'license' ) ) {
            echo '<p>' . esc_html__( 'Unable to initialize licensing client.', $args['textdomain'] ) . '</p>';
            return;
        }

        $settings = $client->settings();
        $activation  = $settings->get_activation();
        $license_key = $settings->license_key;

        $is_config_mode = method_exists( $settings, 'is_config_license_mode' ) && $settings->is_config_license_mode();
        $config_notice  = method_exists( $settings, 'get_config_license_notice' ) ? $settings->get_config_license_notice() : '';

        $is_active = ( $activation && ! is_wp_error( $activation ) && ! empty( $activation->id ) );

        $key_preview = '';
        if ( ! empty( $license_key ) ) {
            $key_preview = substr( $license_key, 0, 4 ) . '…' . substr( $license_key, -4 );
        }

        if ( $is_active ) {
            $input_type        = 'password';
            $input_value       = '';
            $input_placeholder = $key_preview ? sprintf( '•••••••••• (%s)', $key_preview ) : '••••••••••';
            $input_disabled    = true;
        } else {
            $input_type        = 'text';
            $input_value       = '';
            $input_placeholder = $is_config_mode && $key_preview
                ? sprintf( 'Leave blank to use configured key (%s)', $key_preview )
                : $args['placeholder'];
            $input_disabled    = false;
        }

        $status_class = $is_active ? 'rup-license-pill--active' : 'rup-license-pill--inactive';
        $status_label = $is_active ? esc_html__( 'Active', $args['textdomain'] ) : esc_html__( 'Inactive', $args['textdomain'] );

        $classes = 'postbox rup-generic-license-box';
        if ( ! empty( $args['box_class'] ) ) {
            $classes .= ' ' . $args['box_class'];
        }
        if ( $is_active ) {
            $classes .= ' is-collapsed';
        }

        $action_slug  = $args['action'];
        $nonce_action = $action_slug . '_license_action';
        $nonce_field  = $action_slug . '_license_nonce';
        ?>
        <?php self::render_notice( $action_slug ); ?>
        <div id="<?php echo esc_attr( $args['id'] ); ?>" class="<?php echo esc_attr( $classes ); ?>">
            <button type="button" class="rup-license-toggle" aria-expanded="<?php echo $is_active ? 'false' : 'true'; ?>">
                <span class="screen-reader-text"><?php echo esc_html( $args['toggle_aria'] ); ?></span>
                <span class="toggle-indicator" aria-hidden="true"></span>
            </button>

            <div class="rup-license-header">
                <h2 class="hndle"><span><?php echo esc_html( $args['title'] ); ?></span></h2>
                <div>
                    <span class="rup-license-pill <?php echo esc_attr( $status_class ); ?>"><?php echo $status_label; ?></span>
                    <?php if ( $key_preview ) : ?>
                        <span class="rup-license-key"><?php echo esc_html( $key_preview ); ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="inside rup-license-body">

                <?php if ( $is_active ) : ?>
                    <p><?php echo esc_html( $args['active_message'] ); ?></p>
                <?php else : ?>
                    <p><?php echo esc_html( $args['inactive_message'] ); ?></p>
                <?php endif; ?>

                <?php if ( ! empty( $config_notice ) ) : ?>
                    <p class="description"><?php echo esc_html( $config_notice ); ?></p>
                <?php endif; ?>

                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( $nonce_action, $nonce_field ); ?>
                    <input type="hidden" name="action" value="<?php echo esc_attr( $action_slug ); ?>" />
                    <input type="hidden" name="redirect_to" value="<?php echo esc_url( $args['redirect'] ); ?>" />

                    <p>
                        <input type="<?php echo esc_attr( $input_type ); ?>"
                               class="regular-text"
                               name="license_key"
                               autocomplete="off"
                               placeholder="<?php echo esc_attr( $input_placeholder ); ?>"
                               value="<?php echo esc_attr( $input_value ); ?>"
                               <?php echo $input_disabled ? 'disabled="disabled"' : ''; ?> />
                    </p>

                    <p>
                        <?php if ( $is_active ) : ?>
                            <input type="submit" name="deactivate" class="button" value="<?php echo esc_attr( $args['deactivate_label'] ); ?>" />
                        <?php else : ?>
                            <input type="submit" name="activate" class="button button-primary" value="<?php echo esc_attr( $args['activate_label'] ); ?>" />
                        <?php endif; ?>
                    </p>
                </form>
            </div>
        </div>
        <?php
    }
}

} // Shared licence box class guard.
