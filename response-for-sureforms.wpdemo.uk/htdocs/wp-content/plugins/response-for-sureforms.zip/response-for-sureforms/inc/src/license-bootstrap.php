<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'RUP_License_Box' ) ) {
	require_once __DIR__ . '/license-box.php';
}

if ( ! class_exists( 'RUP_SureCart_Licensing_Bootstrap', false ) ) {
class RUP_SureCart_Licensing_Bootstrap {

	protected static $configs = [];
	protected static $clients = [];
	protected static $bootstrapped = false;

	public static function init_all_clients() {
		foreach ( self::$configs as $id => $config ) {
			self::get_client( $id );
		}
	}

	public static function register( array $args ) {
		$defaults = [
			'id'                => '',
			'plugin_file'       => '',
			'plugin_name'       => '',
			'public_token'      => '',
			'textdomain'        => 'default',
			'page_slug'         => '',
			'capability'        => 'manage_options',
			'action'            => '',
			'redirect'          => '',
			'namespace'         => 'SureCart\\Licensing',
			'client_file'       => '',
			'license_constant'  => '',
			'infer_constant'    => true,
			'allow_db_fallback' => true,
		];

		$config = wp_parse_args( $args, $defaults );

		if ( empty( $config['id'] ) ) {
			$config['id'] = sanitize_key( $config['plugin_name'] );
		}

		if ( empty( $config['action'] ) ) {
			$config['action'] = $config['id'] . '_license';
		}

		if ( empty( $config['redirect'] ) && ! empty( $config['page_slug'] ) ) {
			$config['redirect'] = admin_url( 'options-general.php?page=' . $config['page_slug'] );
		}

		self::$configs[ $config['id'] ] = $config;

		add_action( 'admin_post_' . $config['action'], [ __CLASS__, 'handle_form' ] );

		self::ensure_global_hooks();
	}

	public static function render_box( $id, array $overrides = [] ) {
		if ( empty( self::$configs[ $id ] ) ) {
			return;
		}

		$config = self::$configs[ $id ];

		$args = array_merge(
			[
				'id'              => $id . '-license-box',
				'title'           => sprintf( __( '%s License', $config['textdomain'] ), $config['plugin_name'] ),
				'action'          => $config['action'],
				'redirect'        => $config['redirect'],
				'textdomain'      => $config['textdomain'],
				'client_callback' => function() use ( $id ) {
					return RUP_SureCart_Licensing_Bootstrap::get_client( $id );
				},
			],
			$overrides
		);

		RUP_License_Box::render( $args );
	}

	public static function get_client( $id ) {
		if ( isset( self::$clients[ $id ] ) ) {
			return self::$clients[ $id ];
		}

		if ( empty( self::$configs[ $id ] ) ) {
			return null;
		}

		$config  = self::$configs[ $id ];
		$base_ns = ! empty( $config['namespace'] ) ? trim( $config['namespace'], '\\' ) : 'SureCart\\Licensing';

		$config_aware_class = '\\' . $base_ns . '\\ConfigAwareClient';
		$default_class      = '\\' . $base_ns . '\\Client';

		if ( ! class_exists( $config_aware_class ) && ! class_exists( $default_class ) ) {
			$client_file = ! empty( $config['client_file'] ) ? $config['client_file'] : dirname( $config['plugin_file'] ) . '/dist/SureCart/Client.php';
			if ( is_readable( $client_file ) ) {
				require_once $client_file;
			}
		}

		$class = class_exists( $config_aware_class ) ? $config_aware_class : $default_class;

		if ( ! class_exists( $class ) ) {
			return null;
		}

		$client = new $class( $config['plugin_name'], $config['public_token'], $config['plugin_file'] );

		if ( ! empty( $config['textdomain'] ) ) {
			$client->set_textdomain( $config['textdomain'] );
		}

		if ( method_exists( $client, 'set_license_constant' ) && ! empty( $config['license_constant'] ) ) {
			$client->set_license_constant( $config['license_constant'] );
		}

		if ( method_exists( $client, 'infer_license_constant' ) ) {
			$client->infer_license_constant( ! empty( $config['infer_constant'] ) );
		}

		if ( method_exists( $client, 'allow_db_fallback' ) ) {
			$client->allow_db_fallback( ! isset( $config['allow_db_fallback'] ) || (bool) $config['allow_db_fallback'] );
		}

		self::$clients[ $id ] = $client;

		return $client;
	}

	public static function handle_form() {
		$raw_action  = isset( $_REQUEST['action'] ) ? wp_unslash( $_REQUEST['action'] ) : '';
		$action_slug = $raw_action ? sanitize_key( $raw_action ) : '';

		if ( ! $action_slug ) {
			return;
		}

		$config = self::get_config_by_action( $action_slug );
		if ( ! $config ) {
			return;
		}

		if ( ! current_user_can( $config['capability'] ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', $config['textdomain'] ) );
		}

		$nonce_action = $config['action'] . '_license_action';
		$nonce_field  = $config['action'] . '_license_nonce';
		check_admin_referer( $nonce_action, $nonce_field );

		$client = self::get_client( $config['id'] );

		if ( ! $client || ! method_exists( $client, 'license' ) || ! method_exists( $client, 'settings' ) ) {
			set_transient( self::notice_key( $config['id'] ), [ 'type' => 'error', 'message' => __( 'Licensing client is not available.', $config['textdomain'] ) ], 30 );
			wp_safe_redirect( $config['redirect'] );
			exit;
		}

		$license  = $client->license();
		$settings = $client->settings();

		$key         = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		$action_type = '';
		$result      = null;

		if ( isset( $_POST['activate'] ) && method_exists( $license, 'activate' ) ) {
			$action_type = 'activate';

			if ( empty( $key ) ) {
				if ( method_exists( $settings, 'get_config_license_key' ) ) {
					$key = $settings->get_config_license_key();
				}
				if ( empty( $key ) && ! empty( $settings->license_key ) ) {
					$key = $settings->license_key;
				}
			}

			if ( method_exists( $settings, 'set_runtime_license_key' ) && ! empty( $key ) ) {
				$settings->set_runtime_license_key( $key );
			}

			$result = $key === '' ? new \WP_Error( 'missing_license_key', __( 'Please enter a licence key.', $config['textdomain'] ) ) : $license->activate( $key );
		} elseif ( isset( $_POST['deactivate'] ) && method_exists( $license, 'deactivate' ) ) {
			$action_type   = 'deactivate';
			$activation_id = $settings->activation_id;

			if ( $activation_id ) {
				$result = $license->deactivate( $activation_id );
			} else {
				$result = new \WP_Error( 'no_activation_id', __( 'No activation ID found.', $config['textdomain'] ) );
			}
		}

		if ( null === $result ) {
			$result = new \WP_Error( 'invalid_license_action', __( 'Invalid licence action.', $config['textdomain'] ) );
		}
		if ( is_wp_error( $result ) ) {
			set_transient( self::notice_key( $config['id'] ), [ 'type' => 'error', 'message' => $result->get_error_message() ], 30 );
		} else {
			if ( 'deactivate' === $action_type ) {
				$settings->activation_id = null;
			}

			$msg = ( 'activate' === $action_type ) ? __( 'License activated successfully.', $config['textdomain'] ) : __( 'License deactivated.', $config['textdomain'] );
			set_transient( self::notice_key( $config['id'] ), [ 'type' => 'success', 'message' => $msg ], 30 );
		}

		if ( method_exists( $settings, 'clear_runtime_license_key' ) ) {
			$settings->clear_runtime_license_key();
		}

		$redirect = ! empty( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : $config['redirect'];
		wp_safe_redirect( $redirect );
		exit;
	}

	public static function output_styles() {
		if ( ! apply_filters( 'rup_surecart_license_box_enable_styles', true ) ) {
			return;
		}
		?>
		<style>
			.rup-generic-license-box { margin: 1em auto 20px; max-width: 720px; border-radius: 12px; border: 1px solid #e5e7eb; background: #ffffff; box-shadow: 0 18px 40px rgba(15,23,42,0.06); }
			.rup-generic-license-box .rup-license-header { display: flex; justify-content: space-between; align-items: center; padding: 12px 18px; border-bottom: 1px solid #e5e7eb; cursor: pointer; }
			.rup-generic-license-box .rup-license-body { padding: 12px 18px 16px; }
			.rup-generic-license-box .rup-license-toggle { background: transparent; border: 0; cursor: pointer; padding: 8px 12px; float: right; }
			.rup-license-pill { display: inline-block; padding: 3px 8px; border-radius: 999px; font-size: 11px; font-weight: 600; }
			.rup-license-pill--active { background: #dcfce7; color: #166534; }
			.rup-license-pill--inactive { background: #fee2e2; color: #b91c1c; }
			.rup-license-key { margin-left: 10px; font-size: 11px; color: #4b5563; }
			.rup-generic-license-box.is-collapsed .rup-license-body { display: none; }
		</style>
		<?php
	}

	public static function enqueue_scripts() {
		wp_enqueue_script( 'jquery' );
		wp_add_inline_script( 'jquery', 'jQuery(function($){$(document).on("click", ".rup-generic-license-box .rup-license-header, .rup-generic-license-box .rup-license-toggle", function(e){if ($(e.target).closest("a,input,select,textarea").length) return; var $box=$(this).closest(".rup-generic-license-box"); var collapsed=$box.toggleClass("is-collapsed").hasClass("is-collapsed"); $box.find(".rup-license-body").stop(true,true).slideToggle(150); $box.find(".rup-license-toggle").attr("aria-expanded",String(!collapsed));});});' );
	}

	protected static function ensure_global_hooks() {
		if ( self::$bootstrapped ) {
			return;
		}
		self::$bootstrapped = true;

		add_action( 'admin_head', [ __CLASS__, 'output_styles' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_scripts' ] );
		add_action( 'admin_init', [ __CLASS__, 'init_all_clients' ] );
	}

	protected static function get_config_by_action( $action_slug ) {
		foreach ( self::$configs as $config ) {
			if ( $config['action'] === $action_slug ) {
				return $config;
			}
		}
		return null;
	}

	protected static function notice_key( $id ) {
		return $id . '_license_notice';
	}
}
add_action( 'admin_init', [ 'RUP_SureCart_Licensing_Bootstrap', 'init_all_clients' ], 5 );

} // Shared bootstrap class guard.
