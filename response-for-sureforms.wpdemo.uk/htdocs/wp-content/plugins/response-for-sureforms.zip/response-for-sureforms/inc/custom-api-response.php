<?php
// save version 51
// Handles only webhook responses
defined('ABSPATH') || exit;

add_action('rest_api_init', function () {
    register_rest_route('responsefsf/v1', '/receive-response', [
        'methods' => ['POST', 'GET'],
        'callback' => 'responsefsf_receive_response',
        'permission_callback' => '__return_true',
    ]);
});

function responsefsf_receive_response($request) {
    //error_log("=== Incoming Request ===");
    $method = $request->get_method();
    $session_id = $request->get_param('session_id');
    $form_id = $request->get_param('form_id');
    $redirect_url = $request->get_param('redirect_url'); // Added for Redirect URL


    if (empty($form_id) || empty($session_id)) {
        return new WP_Error('missing_params', 'Both form_id and session_id are required.', ['status' => 400]);
    }

    $transient_key = "responsefsf_{$session_id}_{$form_id}";

    if ($method === 'POST') {
       /* Redirect Functionality */
       error_log($redirect_url);
        if (!empty($redirect_url)) {
            // Validate Redirect URL
            if (!filter_var($redirect_url, FILTER_VALIDATE_URL)) {
                return new WP_Error('invalid_url', 'The provided redirect URL is not valid.', ['status' => 400]);
            }

            // Store Redirect URL
            set_transient("responsefsf_redirect_{$session_id}_{$form_id}", [
                'status' => 'success',
                'redirect_url' => esc_url_raw($redirect_url),
            ], 300); // Store for 5 minutes

            return rest_ensure_response(['status' => 'success']);
        }

        /* End Redirect Functionality */
        // Default values
        $has_link = $request->get_param('has_link') === 'yes';
        $has_image = $request->get_param('has_image') === 'yes';
        $has_pdf = $request->get_param('has_pdf') === 'yes';
        $has_video = $request->get_param('has_video') === 'yes';
        $has_audio = $request->get_param('has_audio') === 'yes';
        $body_display = $request->get_param('body_display') === 'no' ? 'no' : 'yes'; // Defaults to 'yes'

        // Additional parameters
        $custom_link_text = $request->get_param('custom_link_text') ?? '';
        $body_content = $request->get_param('body') ?? '';
        $link_url = $request->get_param('link_url') ?? '';
        $copy_button = $request->get_param('copy_button') === 'yes';
        $image_url = $request->get_param('image_url') ?? '';
        $pdf_url = $request->get_param('pdf_url') ?? '';
        $video_url = $request->get_param('video_url') ?? '';
        $audio_url = $request->get_param('audio_url') ?? '';
        $video_custom_text = $request->get_param('video_custom_text') ?? 'Play Video';
        $audio_custom_text = $request->get_param('audio_custom_text') ?? 'Play Audio';

        // Prepare response data dynamically
        $response_data = [];

        // Include body if applicable
        if ($body_display === 'yes' && !empty($body_content)) {
            $response_data['body'] = wp_kses_post($body_content); // Sanitize the body content
        } elseif ($body_display === 'no') {
            $response_data['body'] = "<p>There was an issue with your request. Please try again later.</p>";
        }

        $response_data['body_display'] = $body_display;

        // Include link if applicable
        if ($has_link && !empty($link_url)) {
            $response_data['link'] = '<a href="' . esc_url($link_url) . '" class="response-link">'
                . esc_html(!empty($custom_link_text) ? $custom_link_text : 'Visit Link')
                . '</a>';
        }

        // Include copy button if applicable
        if ($copy_button) {
            $response_data['copy_button'] = 1;
        }

        // Include back button if applicable
        if ($request->get_param('enable_back_button') === 'yes') {
            $response_data['enable_back_button'] = 1;
        }

        // Include image if applicable
        if ($has_image && !empty($image_url)) {
            $response_data['image'] = [
                'html' => '<img src="' . esc_url($image_url) . '" alt="Embedded Image">'
            ];
        }

        // Include PDF if applicable
        if ($has_pdf && !empty($pdf_url)) {
            $response_data['pdf'] = [
                'html' => '<a href="' . esc_url($pdf_url) . '" target="_blank">Download PDF</a>'
            ];
        }

        // Include video if applicable
        if ($has_video && !empty($video_url)) {
            $response_data['has_video'] = true;
            $response_data['video_url'] = esc_url($video_url);
            $response_data['video_custom_text'] = esc_html($video_custom_text);
        }

        // Include audio if applicable
        if ($has_audio && !empty($audio_url)) {
            $response_data['has_audio'] = true;
            $response_data['audio_url'] = esc_url($audio_url);
            $response_data['audio_custom_text'] = esc_html($audio_custom_text);
        }

        // Store response data always (no condition on body_display)
$existing_data = get_transient($transient_key);

// Check if data already exists and is valid, if not store the new response data
if (!$existing_data || !isset($existing_data['status']) || $existing_data['status'] !== 'success') {
    // Validate the response data and ensure it is correct
    if (isset($response_data['status']) && $response_data['status'] === 'success' && isset($response_data['body'])) {
        // Store valid response data for 5 minutes
        set_transient($transient_key, $response_data, 300); // Store for 5 minutes
    } else {
        // Log or handle invalid data
        error_log('Response data is incomplete or invalid.');
    }
} else {
    // Optionally, log that existing data is retained
    error_log('Valid response data already exists. Not overwriting.');
}


        
        $existing_data = get_transient($transient_key);
        set_transient($transient_key, $response_data, 300); // Store for 5 minutes

        return rest_ensure_response(['status' => 'success']);
    }

    // Handle GET method for retrieving response data
if ($method === 'GET') {
    // Check if the plugin is licensed and activated
    if (!responsefsf_is_activated_and_licensed()) {
        return new WP_Error('license_inactive', 'Please activate your license to access this feature.', ['status' => 403]);
    }

    // Attempt to retrieve both types of responses
    $retrieved_data = get_transient($transient_key);
    $redirect_data = get_transient("responsefsf_redirect_{$session_id}_{$form_id}");

    // Check if either type of data exists
    if (!$retrieved_data && !$redirect_data) {
        return new WP_Error('not_found', 'Response not ready yet.', ['status' => 404]);
    }

    // Return redirect data if available
    if ($redirect_data && isset($redirect_data['redirect_url'])) {
        return rest_ensure_response($redirect_data);
    }

    // Handle normal response data
    if ($retrieved_data) {
        if (!isset($retrieved_data['body'])) {
            unset($retrieved_data['body_display']);
        }
        return rest_ensure_response($retrieved_data);
    }
}

return new WP_Error('invalid_method', 'Invalid HTTP method.', ['status' => 405]);

}



add_action('rest_api_init', function() {
    register_rest_route('responsefsf/v1', '/session-id', [
        'methods' => 'GET',
        'callback' => 'responsefsf_get_session_id',
        'permission_callback' => '__return_true',
    ]);
});

function responsefsf_get_session_id() {
    $session_id = responsefsf_generate_session_id();
    $nonce = wp_create_nonce("responsefsf_nonce_{$session_id}");

    //error_log("Generated Session ID for API: {$session_id}");
    //error_log("Generated Nonce for API: {$nonce}");

    return [
        'session_id' => $session_id,
        'nonce' => $nonce,
    ];
}

add_action('rest_api_init', function() {
    register_rest_route('responsefsf/v1', '/validate-session-id', [
        'methods' => 'POST',
        'callback' => function(WP_REST_Request $request) {
            $form_id = $request->get_param('form_id');
            $submitted_session_id = $request->get_param('session_id');
            $stored_session_id = get_post_meta($form_id, '_session_id', true);

            if ($submitted_session_id === $stored_session_id) {
                return rest_ensure_response(['status' => 'valid']);
            } else {
                return new WP_Error('invalid_session', 'Invalid session ID.', ['status' => 400]);
            }
        },
        'permission_callback' => '__return_true',
    ]);
});
