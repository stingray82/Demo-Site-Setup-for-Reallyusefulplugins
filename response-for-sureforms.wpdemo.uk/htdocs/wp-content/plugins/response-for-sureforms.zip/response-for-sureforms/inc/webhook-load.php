<?php
// Save version 28
defined('ABSPATH') || exit;

require_once plugin_dir_path(__FILE__) . 'toolbox.php';

function responsefsf_trigger_webhook_on_submission($result, $server, $request) {
    if ($request->get_route() === '/sureforms/v1/submit-form' && $request->get_method() === 'POST' && !is_wp_error($result) && (!($result instanceof WP_REST_Response) || $result->is_error() === false)) {
        // Only send a webhook once SureForms reports a successful submission.
        $submission_response = $result instanceof WP_REST_Response ? $result->get_data() : null;
        if ( !is_array($submission_response) || empty($submission_response['success']) ) {
            return $result;
        }

        $form_data = $request->get_params();
        $submitted_form_id = $form_data['form-id'] ?? $form_data['form_id'] ?? $form_data['_form_id'] ?? null;

        if ($submitted_form_id) {
            $form_webhooks = get_option('responsefsf_webhooks', []);
            $webhook_url = $form_webhooks[$submitted_form_id] ?? null;

            if ($webhook_url) {
                //error_log("Form ID $submitted_form_id matched with webhook URL: $webhook_url");

                // Retrieve session ID from form data
                $session_id = $form_data['session_id'] ?? null;

                if (!$session_id) {
                    //error_log("Session ID is missing in the form data.");
                    return $result;
                }

                // Use the session ID provided in the form (no need to generate it here)
                //error_log("Using Session ID: $session_id");

                // Generate nonce using the session ID for security
                $nonce = wp_create_nonce("responsefsf_nonce_{$session_id}");

                //error_log("Generated Nonce: $nonce");

                // Store transient for the session
                set_transient("responsefsf_responsefsf_{$session_id}_{$submitted_form_id}", [
                    'body' => '',
                    'attachment' => '',
                    'status' => 'pending',
                ], HOUR_IN_SECONDS);

                // Create and encode the token
                $token_data = [
                    'nonce' => $nonce,
                    'session_id' => $session_id,
                    'form_id' => $submitted_form_id,
                ];
                $token = base64_encode(wp_json_encode($token_data));

                //error_log("Generated Token Data: " . print_r($token_data, true));
                //error_log("Encoded Token: $token");

                // Add session details to the form data
                $form_data['token'] = $token;
                $form_data['session_id'] = $session_id;
                $form_data['nonce'] = $nonce;
                $form_data['custom_forward_url'] = get_rest_url(null, 'responsefsf/v1/receive-response');

                //error_log("Form Data Sent to Webhook: " . print_r($form_data, true));

                // Send data to the webhook URL
                $response = responsefsf_send_data_to_webhook($webhook_url, $form_data);

                if (is_wp_error($response)) {
                    //error_log('Error in webhook response: ' . $response->get_error_message());
                } else {
                    //error_log('Data successfully sent to webhook.');
                }
            } else {
                //error_log("No matching webhook URL found for submitted Form ID: $submitted_form_id");
            }
        } else {
            //error_log("Submitted Form ID is missing.");
        }
    }
    return $result;
}

function responsefsf_send_data_to_webhook($url, $data) {
    // Check if the plugin is licensed and activated
    if ( ! responsefsf_is_activated_and_licensed() ) {
        // If not licensed, send a fallback response
        $fallback_data = [
            'error'   => true,
            'message' => 'Please activate your license to use this feature.',
        ];
        
        //error_log("License not active. Sending fallback data to webhook at URL: $url");

        return wp_remote_post($url, [
            'body'    => wp_json_encode($fallback_data),
            'headers' => ['Content-Type' => 'application/json'],
            'timeout' => 10, // Extended timeout for slower webhook processors
        ]);
    }

    // If licensed, send the real data
    //error_log("License active. Sending data to webhook at URL: $url");

    return wp_remote_post($url, [
        'body'    => wp_json_encode($data),
        'headers' => ['Content-Type' => 'application/json'],
        'timeout' => 10, // Extended timeout for slower webhook processors
    ]);
}


// Add hook for SureForms submission
add_action('rest_api_init', function() {
    add_filter('rest_request_after_callbacks', 'responsefsf_trigger_webhook_on_submission', 10, 3);
});

// Add session ID as additional post meta for SureForms
add_action('srfm_register_additional_post_meta', function() {
    register_post_meta('sureforms', '_session_id', [
        'type' => 'string',
        'description' => 'Session ID for SureForms',
        'single' => true,
        'show_in_rest' => true,
    ]);
});
