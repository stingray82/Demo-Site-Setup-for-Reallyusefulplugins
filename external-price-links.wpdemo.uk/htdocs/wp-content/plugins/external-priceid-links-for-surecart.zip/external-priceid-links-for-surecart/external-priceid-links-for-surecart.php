<?php
/**
 * Plugin Name:       External PriceID Links for SureCart
 * Description:       Sell offsite or affiliate or link to external stores using SureCart Price IDs
 * Version:           1.1.3
 * Requires at least: 6.5
 * Tested up to:      6.9
 * Requires PHP:      8.0
 * Author:            ReallyUsefulPlugins.com
 * Author URI:        https://Reallyusefulplugins.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       external-priceid-links-for-surecart
 * Website:           https://reallyusefulplugins.com
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if ( ! function_exists( 'rup_external_price_links_get_settings' ) ) {

    // ---------- SETTINGS: LOAD & SAVE ----------

    function rup_external_price_links_get_settings() {
        $defaults = array(
            'debug'    => 0,
            'mappings' => array(),
        );

        $settings = get_option( 'surecart_price_link_settings', array() );
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }

        return array_merge( $defaults, $settings );
    }

    function rup_external_price_links_save_settings() {
        if ( ! isset( $_POST['surecart_price_settings_nonce'] ) ) {
            return;
        }

        if ( ! wp_verify_nonce( $_POST['surecart_price_settings_nonce'], 'surecart_price_settings_save' ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = isset( $_POST['surecart_price_settings'] ) ? (array) $_POST['surecart_price_settings'] : array();

        $settings = array(
            'debug'    => ! empty( $data['debug'] ) ? 1 : 0,
            'mappings' => array(),
        );

        if ( ! empty( $data['mappings'] ) && is_array( $data['mappings'] ) ) {
            foreach ( $data['mappings'] as $row ) {
                $price_id       = isset( $row['price_id'] ) ? trim( sanitize_text_field( $row['price_id'] ) ) : '';
                $url            = isset( $row['url'] ) ? esc_url_raw( trim( $row['url'] ) ) : '';
                $selected_label = isset( $row['selected_label'] ) ? sanitize_text_field( $row['selected_label'] ) : '';
                $override_label = isset( $row['override_label'] ) ? sanitize_text_field( $row['override_label'] ) : '';
                $delete         = ! empty( $row['delete'] );

                // Skip rows marked for deletion OR empty/incomplete rows.
                if ( $delete || ! $price_id || ! $url ) {
                    continue;
                }

                $settings['mappings'][] = array(
                    'price_id'       => $price_id,
                    'url'            => $url,
                    'selected_label' => $selected_label,
                    'override_label' => $override_label,
                );
            }
        }

        update_option( 'surecart_price_link_settings', $settings );
    }

    /**
     * Get all SureCart products (sc_product) and their prices.
     *
     * Returns an array of:
     * [
     *   'post_id'   => (int),
     *   'title'     => (string),
     *   'product_id'=> (string SureCart product UUID),
     *   'prices'    => [
     *        [
     *          'id'             => (string price UUID),
     *          'name'           => (string price name),
     *          'display_amount' => (string e.g. "US$9.99"),
     *        ],
     *        ...
     *   ],
     * ]
     */
    function rup_external_price_links_get_products_with_prices() {
        $products_with_prices = array();

        $posts = get_posts(
            array(
                'post_type'      => 'sc_product',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC',
            )
        );

        if ( empty( $posts ) ) {
            return $products_with_prices;
        }

        foreach ( $posts as $post ) {
            $raw = get_post_meta( $post->ID, 'product', true );

            if ( empty( $raw ) ) {
                continue;
            }

            $product = is_string( $raw ) ? maybe_unserialize( $raw ) : $raw;
            if ( empty( $product ) || ! is_array( $product ) ) {
                continue;
            }

            // SureCart product ID (the UUID like e6455c...).
            $product_id = isset( $product['id'] ) ? $product['id'] : '';

            $prices = array();

            // Prefer active_prices if present, fall back to prices.data.
            if ( ! empty( $product['active_prices'] ) && is_array( $product['active_prices'] ) ) {
                $price_source = $product['active_prices'];
            } elseif (
                ! empty( $product['prices'] ) &&
                is_array( $product['prices'] ) &&
                ! empty( $product['prices']['data'] ) &&
                is_array( $product['prices']['data'] )
            ) {
                $price_source = $product['prices']['data'];
            } else {
                $price_source = array();
            }

            foreach ( $price_source as $price ) {
                if ( ! is_array( $price ) ) {
                    continue;
                }

                $price_id   = isset( $price['id'] ) ? $price['id'] : '';
                $price_name = isset( $price['name'] ) ? $price['name'] : '';
                $display    = isset( $price['display_amount'] ) ? $price['display_amount'] : '';

                if ( ! $price_id ) {
                    continue;
                }

                $prices[] = array(
                    'id'             => $price_id,
                    'name'           => $price_name,
                    'display_amount' => $display,
                );
            }

            if ( empty( $prices ) ) {
                continue;
            }

            $products_with_prices[] = array(
                'post_id'    => $post->ID,
                'title'      => get_the_title( $post ),
                'product_id' => $product_id,
                'prices'     => $prices,
            );
        }

        return $products_with_prices;
    }

    // ---------- ADMIN PAGE ----------

   function rup_external_price_links_admin_menu() {
        add_submenu_page(
            'sc-dashboard',                                // Parent = SureCart top-level menu
            'SureCart External Prices',                    // Page title
            'External Prices',                             // Menu label
            'manage_options',                               // Capability
            'surecart-external-prices',                    // Slug
            'rup_external_price_links_render_admin_page'    // Callback
        );
    }
    add_action( 'admin_menu', 'rup_external_price_links_admin_menu',99 );


    function rup_external_price_links_render_admin_page() {
        if ( 'POST' === $_SERVER['REQUEST_METHOD'] ) {
            rup_external_price_links_save_settings();
        }

        $settings = rup_external_price_links_get_settings();
        $mappings = ! empty( $settings['mappings'] ) ? $settings['mappings'] : array();

        // Add one empty row for "new" entry.
        $mappings[] = array(
            'price_id'       => '',
            'url'            => '',
            'selected_label' => '',
            'override_label' => '',
        );

        // Get SureCart products + prices.
        $sc_products = rup_external_price_links_get_products_with_prices();
        $debug       = ! empty( $settings['debug'] );
        ?>
        <div class="wrap">
            <h1>SureCart External Prices</h1>
            <style>
            /* ==========================
            PAGE HEADINGS
            ========================== */

            .wrap h1 {
                font-size: 24px;
                font-weight: 600;
                margin: 0 0 16px;
                color: #111827;
                letter-spacing: -0.02em;
            }

            .wrap h2 {
                font-size: 16px;
                font-weight: 600;
                margin: 24px 0 8px;
                color: #111827;
            }

            /* ==========================
            TABLE LAYOUT & COLUMNS
            ========================== */

            #sc-ext-price-table {
                border-collapse: separate;
                border-spacing: 0 10px; /* vertical gap between rows */
                width: 100%;
                box-sizing: border-box;
            }

            /* Flex header row so columns align with body */
            #sc-ext-price-table thead tr {
                display: flex;
                gap: 6px; /* space between header cells */
                margin-left: 10px;
                margin-right: 10px;
            }

            /* Each body row is also flex; all cells top-align */
            #sc-ext-price-table tbody tr {
                display: flex;
                gap: 6px;                 /* space between columns */
                align-items: flex-start;  /* align all fields from the top */
                background: #ffffff;
                box-shadow: 0 8px 20px rgba(15, 23, 42, 0.04);
                border-radius: 12px;
                overflow: hidden;
                box-sizing: border-box;
            }

            /* Header cells base styles */
            #sc-ext-price-table thead tr th {
                background: #f3f4f6;
                padding: 8px 14px !important;
                font-weight: 600;
                border-bottom: 1px solid #e2e8f0;
                border-radius: 8px;
                font-size: 13px;
                line-height: 1.3;
                color: #374151;
                text-align: left;
                white-space: nowrap;
                box-sizing: border-box;
            }

            /* Extra breathing room so they don't touch card edge */
            #sc-ext-price-table thead tr th:first-child {
                padding-left: 20px !important;
            }
            #sc-ext-price-table thead tr th:last-child {
                padding-right: 20px !important;
            }

            /* Body cells base styles */
            #sc-ext-price-table tbody tr td {
                padding: 10px 14px;
                background: #ffffff;
                border-top: 1px solid #f3f4f6;
                font-size: 13px;
                box-sizing: border-box;
            }

            /* first & last cell borders / rounding + extra padding */
            #sc-ext-price-table tbody tr td:first-child {
                border-left: 1px solid #e5e7eb;
                border-radius: 12px 0 0 12px;
                padding-left: 20px;
            }

            #sc-ext-price-table tbody tr td:last-child {
                border-right: 1px solid #e5e7eb;
                border-radius: 0 12px 12px 0;
                text-align: center;
                padding-right: 20px;
            }

            /* Column flex widths (header + body share these) */
            #sc-ext-price-table thead tr th:nth-child(1),
            #sc-ext-price-table tbody tr td:nth-child(1) { flex: 1 1 16%; }

            #sc-ext-price-table thead tr th:nth-child(2),
            #sc-ext-price-table tbody tr td:nth-child(2) { flex: 1 1 20%; }

            #sc-ext-price-table thead tr th:nth-child(3),
            #sc-ext-price-table tbody tr td:nth-child(3) { flex: 1 1 25%; }

            #sc-ext-price-table thead tr th:nth-child(4),
            #sc-ext-price-table tbody tr td:nth-child(4) { flex: 1 1 17%; }

            #sc-ext-price-table thead tr th:nth-child(5),
            #sc-ext-price-table tbody tr td:nth-child(5) { flex: 1 1 17%; }

            #sc-ext-price-table thead tr th:nth-child(6),
            #sc-ext-price-table tbody tr td:nth-child(6) { flex: 0 0 5%; }

            /* Row hover */
            #sc-ext-price-table tbody tr:hover {
                background: #f9fafb;
                box-shadow: 0 10px 25px rgba(15, 23, 42, 0.08);
            }

            /* ==========================
            INPUTS & SELECTS
            ========================== */

            #sc-ext-price-table input.regular-text,
            #sc-ext-price-table select {
                border: 1px solid #d1d5db;
                border-radius: 8px;
                padding: 8px 11px;
                background: #f9fafb;
                transition: border-color .18s ease, box-shadow .18s ease, background-color .18s ease;
                width: 100%;
                box-sizing: border-box;
                font-size: 13px;
                height: 38px; /* consistent field height */
            }

            #sc-ext-price-table input.regular-text:focus,
            #sc-ext-price-table select:focus {
                border-color: #2563eb;
                box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.8);
                outline: none;
                background: #ffffff;
            }

            /* Placeholder option */
            #sc-ext-price-table select option[value=""] {
                color: #9ca3af;
            }

            /* ==========================
            PRICE DESCRIPTION
            ========================== */

            .sc-product-price-picker {
                margin-top: 0;
            }

            /* Markup:
            <select class="sc-price-select"></select>
            <p class="sc-price-description">…</p>
            */
            .sc-price-select {
                margin-top: 0;
                margin-bottom: 4px;
                cursor: pointer;
            }

            .sc-price-description {
                font-size: 12px;
                color: #6b7280;
                margin-top: 4px;
                padding-left: 2px;
                line-height: 1.4;
            }

            /* Debug ID label */
            .sc-price-id-debug {
                margin-top: 6px;
                color: #9ca3af;
                font-size: 11px;
                font-family: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
                word-break: break-all;
            }

            .sc-product-select {
                margin-top: 0;
                margin-bottom: 4px;
                cursor: pointer;
            }

            .sc-product-select:hover,
            .sc-price-select:hover {
                border-color: #9ca3af;
            }

            /* ==========================
            CARD WRAPPER
            ========================== */

            .sc-ext-card {
                background: #ffffff;
                padding: 18px 18px 12px;
                border-radius: 16px;
                box-shadow: 0 18px 40px rgba(15, 23, 42, 0.06);
                margin-bottom: 24px;
                border: 1px solid #e5e7eb;
            }

            /* ==========================
            DEBUG TOGGLE (APPLE STYLE)
            ========================== */

            .sc-debug-row {
                display: flex;
                align-items: center;
                padding: 12px 16px;
                margin: 0 0 18px;
                background: #ffffff;
                border-radius: 14px;
                border: 1px solid #e5e7eb;
                box-shadow: 0 6px 16px rgba(15, 23, 42, 0.04);
            }

            .sc-toggle-label {
                display: flex;
                align-items: center;
                gap: 12px;
                cursor: pointer;
            }

            .sc-toggle {
                position: relative;
                display: inline-block;
                width: 46px;
                height: 26px;
            }

            .sc-toggle input {
                opacity: 0;
                width: 0;
                height: 0;
            }

            .sc-toggle-slider {
                position: absolute;
                cursor: pointer;
                inset: 0;
                background-color: #d1d5db;
                border-radius: 999px;
                transition: background-color .18s ease, box-shadow .18s ease;
                box-shadow: inset 0 0 0 1px rgba(15, 23, 42, 0.06);
            }

            .sc-toggle-slider:before {
                content: "";
                position: absolute;
                height: 20px;
                width: 20px;
                left: 3px;
                top: 3px;
                background-color: #ffffff;
                border-radius: 50%;
                box-shadow: 0 2px 6px rgba(15, 23, 42, 0.25);
                transition: transform .18s ease;
            }

            .sc-toggle input:checked + .sc-toggle-slider {
                background-color: #34c759; /* Apple green */
                box-shadow: 0 0 0 1px rgba(52, 199, 89, 0.45);
            }

            .sc-toggle input:checked + .sc-toggle-slider:before {
                transform: translateX(18px);
            }

            .sc-toggle-text {
                font-size: 13px;
                color: #111827;
            }

            .sc-toggle-text strong {
                font-weight: 600;
            }

            .sc-toggle-sub {
                display: block;
                font-size: 12px;
                color: #6b7280;
                margin-top: 2px;
            }
        </style>
            <?php RUP_SureCart_Licensing_Bootstrap::render_box( 'rup_price_id_inks_surecart_license_box', [
                    'title' => __( 'External Price ID for SureCart', 'external-priceid-links-for-surecart' ),
                ] ); ?>

            <form method="post">
             

                <?php wp_nonce_field( 'surecart_price_settings_save', 'surecart_price_settings_nonce' ); ?>

                <h2>Debug</h2>
                <div class="sc-debug-row">
                    <label class="sc-toggle-label">
                        <span class="sc-toggle">
                            <input type="checkbox"
                                name="surecart_price_settings[debug]"
                                value="1"
                                <?php checked( $debug ); ?> />
                            <span class="sc-toggle-slider"></span>
                        </span>
                        <span class="sc-toggle-text">
                            <strong>Enable debug mode</strong>
                            <span class="sc-toggle-sub">
                                Show console debug output and reveal stored Price IDs under each row.
                            </span>
                        </span>
                    </label>
                </div>

                <h2>Price Mappings</h2>
                <p>
                    Choose a <strong>SureCart product</strong> and one of its <strong>prices/versions</strong>.
                    The underlying <code>Price ID</code> is stored automatically and used by the existing logic.
                </p>
                <div class="sc-ext-card">
                <table class="widefat fixed striped" id="sc-ext-price-table">
                    <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price / Version</th>
                        <th>External URL</th>
                        <th>Label when selected</th>
                        <th>Override default label (optional)</th>
                        <th>Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $mappings as $index => $row ) : ?>
                        <?php $price_id_value = isset( $row['price_id'] ) ? $row['price_id'] : ''; ?>
                        <tr>
                            <!-- PRODUCT -->
                            <td>
                                <select class="sc-product-select">
                                    <option value=""><?php esc_html_e( '— Select product —', 'surecart' ); ?></option>
                                    <?php foreach ( $sc_products as $product ) : ?>
                                        <option value="<?php echo esc_attr( $product['post_id'] ); ?>">
                                            <?php echo esc_html( $product['title'] ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>

                            <!-- PRICE / VERSION -->
                            <td>
                                <div class="sc-product-price-picker">
                                    <select class="sc-price-select" <?php echo empty( $sc_products ) ? 'disabled="disabled"' : ''; ?>>
                                        <option value=""><?php esc_html_e( '— Select price / version —', 'surecart' ); ?></option>
                                    </select>
                                    <p class="description sc-price-description"></p>

                                    <!-- hidden actual price_id field that gets saved -->
                                    <input type="hidden"
                                        name="surecart_price_settings[mappings][<?php echo esc_attr( $index ); ?>][price_id]"
                                        value="<?php echo esc_attr( $price_id_value ); ?>"
                                        class="sc-price-id-field" />

                                    <?php if ( $debug ) : ?>
                                        <p class="sc-price-id-debug">
                                            Stored Price ID:<br><?php echo esc_html( $price_id_value ); ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </td>

                            <!-- EXTERNAL URL -->
                            <td>
                                <input type="url"
                                    name="surecart_price_settings[mappings][<?php echo esc_attr( $index ); ?>][url]"
                                    value="<?php echo esc_attr( $row['url'] ?? '' ); ?>"
                                    class="regular-text" />
                            </td>

                            <!-- LABEL WHEN SELECTED -->
                            <td>
                                <input type="text"
                                    name="surecart_price_settings[mappings][<?php echo esc_attr( $index ); ?>][selected_label]"
                                    value="<?php echo esc_attr( $row['selected_label'] ?? '' ); ?>"
                                    class="regular-text" />
                            </td>

                            <!-- OVERRIDE LABEL -->
                            <td>
                                <input type="text"
                                    name="surecart_price_settings[mappings][<?php echo esc_attr( $index ); ?>][override_label]"
                                    value="<?php echo esc_attr( $row['override_label'] ?? '' ); ?>"
                                    class="regular-text" />
                            </td>

                            <!-- DELETE -->
                            <td>
                                <?php
                                $is_last_row = ( $index === array_key_last( $mappings ) );
                                if ( ! $is_last_row ) : ?>
                                    <label>
                                        <input type="checkbox"
                                            name="surecart_price_settings[mappings][<?php echo esc_attr( $index ); ?>][delete]"
                                            value="1" />
                                    </label>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>

                <p class="description">
                    <strong>Behaviour:</strong><br>
                    &ndash; Select a product &amp; price; the hidden <em>Price ID</em> is filled automatically.<br>
                    &ndash; Existing mappings will auto-select the correct product/price when the page loads.<br>
                    &ndash; To delete a mapping, tick <strong>Delete</strong> and click <strong>Save Changes</strong>.<br>
                    &ndash; To add more rows, fill the last empty row and save; a new empty row will appear.
                </p>

                <?php submit_button(); ?>
            </form>
        </div>
        <?php
        // ---------- INLINE JS TO WIRE UP THE DROPDOWNS ----------
        if ( ! empty( $sc_products ) ) :
            ?>
            <script>
            (function() {
                const products = <?php echo wp_json_encode( $sc_products ); ?> || [];
                const productMap = {};
                products.forEach(function (p) {
                    productMap[String(p.post_id)] = p;
                });

                const rows = document.querySelectorAll('#sc-ext-price-table tbody tr');
                rows.forEach(function (row) {
                    const priceIdInput = row.querySelector('.sc-price-id-field');
                    const productSelect = row.querySelector('.sc-product-select');
                    const priceSelect   = row.querySelector('.sc-price-select');
                    const desc          = row.querySelector('.sc-price-description');
                    const debugText     = row.querySelector('.sc-price-id-debug');

                    if (!priceIdInput || !productSelect || !priceSelect) {
                        return;
                    }

                    function populatePricesForProduct(postId) {
                        priceSelect.innerHTML = '';
                        const placeholder = document.createElement('option');
                        placeholder.value = '';
                        placeholder.textContent = '<?php echo esc_js( '— Select price / version —' ); ?>';
                        priceSelect.appendChild(placeholder);

                        const product = productMap[String(postId)];
                        if (!product || !product.prices) {
                            priceSelect.disabled = true;
                            return;
                        }

                        product.prices.forEach(function (price) {
                            const opt = document.createElement('option');
                            opt.value = price.id;
                            let label = price.name || price.id;
                            if (price.display_amount) {
                                label += ' (' + price.display_amount + ')';
                            }
                            opt.textContent = label;
                            priceSelect.appendChild(opt);
                        });

                        priceSelect.disabled = false;
                    }

                    productSelect.addEventListener('change', function () {
                        const postId = this.value;
                        desc.textContent = '';
                        populatePricesForProduct(postId);

                        // When product changes, clear price selection and price ID.
                        priceSelect.value = '';
                        priceIdInput.value = '';
                        if (debugText) {
                            debugText.textContent = 'Stored Price ID:';
                        }
                    });

                    priceSelect.addEventListener('change', function () {
                        const selectedPriceId = this.value;
                        priceIdInput.value = selectedPriceId;

                        const postId  = productSelect.value;
                        const product = productMap[String(postId)];
                        if (!product) {
                            desc.textContent = '';
                            if (debugText) debugText.textContent = 'Stored Price ID: ' + selectedPriceId;
                            return;
                        }
                        const price = (product.prices || []).find(function (p) {
                            return p.id === selectedPriceId;
                        });
                        if (price) {
                            let text = product.title + ' – ' + (price.name || '');
                            if (price.display_amount) {
                                text += ' (' + price.display_amount + ')';
                            }
                            desc.textContent = text;
                        } else {
                            desc.textContent = '';
                        }
                        if (debugText) {
                            debugText.textContent = 'Stored Price ID: ' + selectedPriceId;
                        }
                    });

                    // Preselect product/price if a Price ID is already stored.
                    const existingId = priceIdInput.value.trim();
                    if (existingId) {
                        products.forEach(function (product) {
                            const match = (product.prices || []).find(function (p) {
                                return p.id === existingId;
                            });
                            if (match) {
                                productSelect.value = String(product.post_id);
                                populatePricesForProduct(product.post_id);
                                priceSelect.value = existingId;

                                let text = product.title + ' – ' + (match.name || '');
                                if (match.display_amount) {
                                    text += ' (' + match.display_amount + ')';
                                }
                                desc.textContent = text;

                                if (debugText) {
                                    debugText.textContent = 'Stored Price ID: ' + existingId;
                                }
                            }
                        });
                    }
                });
            })();

            </script>
            <?php
        endif;
    }


    // ---------- FRONTEND INLINE JS ----------

    function rup_external_price_links_inline_script() {
        if ( is_admin() ) {
            return;
        }

        $settings = rup_external_price_links_get_settings();

        $js_settings = array(
            'debug'    => ! empty( $settings['debug'] ),
            'mappings' => $settings['mappings'],
        );
        ?>
        <style>
            /* When an external price is active, kill ALL payment UI everywhere */
            body.sc-external-price-active sc-payment,
            body.sc-external-price-active sc-payment *,
            body.sc-external-price-active sc-stripe-payment-element,
            body.sc-external-price-active sc-stripe-payment-element *,
            body.sc-external-price-active .StripeElement,
            body.sc-external-price-active .StripeElement *,
            body.sc-external-price-active .sc-payment-label {
                display: none !important;
            }
            /* When external price is active, hide the whole payment block */
            body.sc-external-price-active sc-payment {
                display: none !important;
            }

            /* And also hide any Payment heading/label */
            body.sc-external-price-active sc-payment::part(label),
            body.sc-external-price-active .sc-payment-label {
                display: none !important;
            }
        </style>
        <script>
        (function () {
            const SETTINGS = <?php echo wp_json_encode( $js_settings ); ?>;
            const DEBUG = !!SETTINGS.debug;
            const MAPPINGS = Array.isArray(SETTINGS.mappings) ? SETTINGS.mappings : [];

            function logDebug(...args) {
                if (DEBUG) console.log('[SureCart Debug]', ...args);
            }

            const mappingsById = {};
            MAPPINGS.forEach(m => {
                if (m && m.price_id) {
                    mappingsById[m.price_id] = m;
                }
            });

            // Global CSS toggle for hiding payment UI when external price is active
            const EXTERNAL_ACTIVE_CLASS = 'sc-external-price-active';

            (function ensureExternalCss() {
                if (document.getElementById('sc-external-price-css')) return;
                const style = document.createElement('style');
                style.id = 'sc-external-price-css';
                style.textContent = `
                    body.${EXTERNAL_ACTIVE_CLASS} sc-payment,
                    body.${EXTERNAL_ACTIVE_CLASS} sc-stripe-payment-element,
                    body.${EXTERNAL_ACTIVE_CLASS} .sc-payment-label {
                        display: none !important;
                    }
                `;
                document.head.appendChild(style);
            })();

            if (Object.keys(mappingsById).length === 0) {
                logDebug('No mappings configured at all; leaving SureCart buttons untouched.');
                return;
            }

            function parseContext(el) {
                if (!el) return null;
                const raw = el.getAttribute('data-wp-context');
                if (!raw) return null;
                try {
                    return JSON.parse(raw.replace(/&quot;/g, '"'));
                } catch (e) {
                    logDebug('Context parse error:', e);
                    return null;
                }
            }

            // ========== MODE 1: Classic block buttons (Add to Cart + Buy Now) ==========

            function findCurrentChoiceBlock(chooser) {
                return (
                    chooser.querySelector('.wp-block-surecart-product-price-choice-template.sc-choice--checked') ||
                    chooser.querySelector('.wp-block-surecart-product-price-choice-template[aria-checked="true"]')
                );
            }

            function initBlockButtonsMode() {
                const chooser = document.querySelector('.wp-block-surecart-product-price-chooser');
                const buyButtonsWrapper = document.querySelector('.wp-block-surecart-product-buy-buttons.wp-block-buttons');

                if (!chooser || !buyButtonsWrapper) {
                    logDebug('Block buttons mode: chooser or buy buttons wrapper not found – skipping.');
                    return;
                }

                logDebug('Initialising block buttons mode (Add To Cart + Buy Now).');

                const buttonWrappers = buyButtonsWrapper.querySelectorAll('.wp-block-surecart-product-buy-button');
                let addToCartWrapper = null;
                let buyNowWrapper = null;

                buttonWrappers.forEach(wrapper => {
                    const ctx = parseContext(wrapper);
                    if (!ctx) return;
                    if (ctx.addToCart) addToCartWrapper = wrapper;
                    else buyNowWrapper = wrapper;
                });

                if (!addToCartWrapper || !buyNowWrapper) {
                    logDebug('Block buttons mode: could not find both Add To Cart and Buy Now wrappers – skipping.');
                    return;
                }

                const buyNowButton = buyNowWrapper.querySelector('button');
                const buyNowTextSpan =
                    buyNowWrapper.querySelector('.sc-button__link-text') ||
                    buyNowWrapper.querySelector('.wp-block-button__link-text');

                if (!buyNowButton || !buyNowTextSpan) {
                    logDebug('Block buttons mode: Buy Now button or label span missing – skipping.');
                    return;
                }

                const buyNowCtx = parseContext(buyNowWrapper);
                let defaultBuyNowLabel = buyNowCtx && buyNowCtx.buttonText
                    ? buyNowCtx.buttonText
                    : (buyNowTextSpan.textContent || '').trim();

                logDebug('Block buttons mode: default Buy Now label:', defaultBuyNowLabel);

                const priceChoiceEls = chooser.querySelectorAll('.wp-block-surecart-product-price-choice-template');
                let hasMappedPriceOnPage = false;
                let pageOverrideLabel = null;

                priceChoiceEls.forEach(choice => {
                    const ctx = parseContext(choice);
                    const priceId = ctx && ctx.price && ctx.price.id;
                    if (!priceId) return;
                    const mapping = mappingsById[priceId];
                    if (mapping) {
                        hasMappedPriceOnPage = true;
                        if (mapping.override_label && !pageOverrideLabel) {
                            pageOverrideLabel = mapping.override_label;
                        }
                    }
                });

                if (!hasMappedPriceOnPage) {
                    logDebug('Block buttons mode: no mapped price IDs on this product page – leaving buttons untouched.');
                    return;
                }

                if (pageOverrideLabel) {
                    logDebug('Block buttons mode: page-level override label:', pageOverrideLabel);
                    buyNowTextSpan.textContent = pageOverrideLabel;
                }

                let currentRedirectUrl = null;

                function setLabelForNonMappedSelection() {
                    buyNowTextSpan.textContent = pageOverrideLabel || defaultBuyNowLabel;
                }

                function applySelectionBlock(priceId) {
                    logDebug('Block buttons mode: applySelection for priceId:', priceId);
                    const mapping = mappingsById[priceId] || null;

                    if (!mapping) {
                        logDebug('Block buttons mode: no mapping for this price – showing both buttons with default/override labels.');
                        currentRedirectUrl = null;
                        addToCartWrapper.style.display = '';
                        buyNowWrapper.style.display = '';
                        setLabelForNonMappedSelection();
                        return;
                    }

                    currentRedirectUrl = mapping.url || null;
                    logDebug('Block buttons mode: mapped price config:', mapping);

                    addToCartWrapper.style.display = 'none';
                    buyNowWrapper.style.display = '';

                    if (mapping.selected_label) {
                        buyNowTextSpan.textContent = mapping.selected_label;
                    } else if (pageOverrideLabel) {
                        buyNowTextSpan.textContent = pageOverrideLabel;
                    } else {
                        buyNowTextSpan.textContent = defaultBuyNowLabel;
                    }
                }

                buyNowButton.addEventListener(
                    'click',
                    event => {
                        if (currentRedirectUrl) {
                            logDebug('Block buttons mode: external redirect to:', currentRedirectUrl);
                            event.preventDefault();
                            event.stopPropagation();
                            window.location.href = currentRedirectUrl;
                        }
                    },
                    true
                );

                function syncFromCurrentChoiceBlock() {
                    const currentChoice = findCurrentChoiceBlock(chooser);
                    if (!currentChoice) {
                        logDebug('Block buttons mode: no current choice detected yet.');
                        return;
                    }
                    const ctx = parseContext(currentChoice);
                    const priceId = ctx && ctx.price && ctx.price.id;
                    if (priceId) {
                        logDebug('Block buttons mode: syncing from current selected price on load:', priceId);
                        applySelectionBlock(priceId);
                    }
                }

                syncFromCurrentChoiceBlock();
                setTimeout(syncFromCurrentChoiceBlock, 400);

                chooser.addEventListener('click', event => {
                    const choice = event.target.closest('.wp-block-surecart-product-price-choice-template');
                    if (!choice) return;
                    const ctx = parseContext(choice);
                    const priceId = ctx && ctx.price && ctx.price.id;
                    if (priceId) {
                        applySelectionBlock(priceId);
                    }
                });

                logDebug('Block buttons mode initialised.');
            }

            // ========== MODE 2: Embedded checkout (variant selector + Purchase button) ==========

            function initCheckoutMode() {
                const variantSelector = document.querySelector('sc-checkout-product-price-variant-selector');
                if (!variantSelector) {
                    logDebug('Checkout mode: no sc-checkout-product-price-variant-selector found – skipping.');
                    return;
                }

                const checkoutColumn = document.querySelector(
                    'sc-column.wp-block-surecart-column.is-horizontally-aligned-left'
                );
                if (!checkoutColumn) {
                    logDebug('Checkout mode: checkout column not found – skipping.');
                    return;
                }

                const productForm = document.querySelector('form.wp-block-surecart-product-page[data-wp-context]');
                if (!productForm) {
                    logDebug('Checkout mode: product form not found – skipping.');
                    return;
                }

                const formCtx = parseContext(productForm) || {};
                const pricesArray = Array.isArray(formCtx.prices) ? formCtx.prices : [];
                let hasMappedPriceOnPage = false;

                pricesArray.forEach(p => {
                    if (p && p.id && mappingsById[p.id]) {
                        hasMappedPriceOnPage = true;
                    }
                });

                if (!hasMappedPriceOnPage) {
                    logDebug('Checkout mode: no mapped price IDs in product form – leaving checkout alone.');
                    return;
                }

                logDebug('Initialising checkout mode (embedded checkout column).');

                const hiddenInput = variantSelector.querySelector(
                    '.sc-checkout-product-price-variant-selector__hidden-input'
                );

                function getCurrentPriceIdFromCheckout() {
                    // 1) hidden input, if present
                    if (hiddenInput && hiddenInput.value) {
                        return hiddenInput.value;
                    }

                    // 2) checked choice
                    const checked = variantSelector.querySelector(
                        'sc-price-choice-container[checked] sc-choice-container[value]'
                    );
                    if (checked) {
                        return checked.getAttribute('value');
                    }

                    // 3) fallback to initial selectedPrice in form context
                    const ctx = parseContext(productForm) || {};
                    const sel = ctx.selectedPrice;
                    if (sel && sel.id) return sel.id;

                    return null;
                }

                // All direct children of the checkout column (recomputed each time)
                function getColumnChildren() {
                    return Array.from(checkoutColumn.children);
                }

                // --- external button ------------------------------------------------

                const externalWrapper = document.createElement('div');
                externalWrapper.className = 'sc-external-price-wrapper';
                externalWrapper.style.marginTop = '20rem';
                externalWrapper.style.display = 'none';

                const externalScButton = document.createElement('sc-button');
                externalScButton.setAttribute('type', 'primary');
                externalScButton.setAttribute('size', 'large');
                externalScButton.setAttribute('full', '');
                externalScButton.textContent = 'Buy externally';

                externalWrapper.appendChild(externalScButton);
                checkoutColumn.appendChild(externalWrapper);

                let currentRedirectUrl = null;
                let lastPriceId = null;

                function syncPaymentVisibility() {
                    if (currentRedirectUrl) {
                        document.body.classList.add('sc-external-price-active');
                    } else {
                        document.body.classList.remove('sc-external-price-active');
                    }
                }

                function showInternalCheckout() {
                    currentRedirectUrl = null;
                    externalWrapper.style.display = 'none';

                    getColumnChildren().forEach(child => {
                        if (child !== externalWrapper) {
                            child.style.display = '';
                        }
                    });

                    syncPaymentVisibility();
                }

                function showExternalOnly(mapping) {
                    currentRedirectUrl = mapping.url || null;

                    getColumnChildren().forEach(child => {
                        if (child !== externalWrapper) {
                            child.style.display = 'none';
                        }
                    });

                    externalWrapper.style.display = '';
                    const label = mapping.selected_label || 'Buy externally';
                    externalScButton.textContent = label;

                    syncPaymentVisibility();
                }

                function applySelectionCheckout(priceId) {
                    logDebug('Checkout mode: applySelection for priceId:', priceId);
                    const mapping = mappingsById[priceId] || null;

                    if (!mapping) {
                        logDebug('Checkout mode: non-mapped price selected – show internal checkout.');
                        showInternalCheckout();
                        return;
                    }

                    logDebug('Checkout mode: mapped price config:', mapping);
                    showExternalOnly(mapping);
                }

                function syncFromCheckoutSelector() {
                    const priceId = getCurrentPriceIdFromCheckout();
                    if (!priceId) {
                        logDebug('Checkout mode: no current priceId detected yet.');
                        return;
                    }
                    if (priceId === lastPriceId) {
                        return;
                    }
                    lastPriceId = priceId;

                    logDebug('Checkout mode: syncing from current selected price:', priceId);
                    applySelectionCheckout(priceId);
                }

                // --- events & observers ---------------------------------------------

                externalScButton.addEventListener('click', event => {
                    if (currentRedirectUrl) {
                        logDebug('Checkout mode: external redirect to:', currentRedirectUrl);
                        event.preventDefault();
                        window.location.href = currentRedirectUrl;
                    }
                });

                // Respond immediately to clicks on choices
                variantSelector.addEventListener('click', event => {
                    const choice = event.target.closest('sc-choice-container[value]');
                    if (!choice) return;
                    const id = choice.getAttribute('value');
                    if (!id) return;
                    logDebug('Checkout mode: direct click on choice ->', id);
                    applySelectionCheckout(id);
                    lastPriceId = id;
                });

                // Hidden input changes (programmatic selection)
                if (hiddenInput) {
                    const onHiddenChange = () => {
                        setTimeout(syncFromCheckoutSelector, 0);
                    };
                    hiddenInput.addEventListener('input', onHiddenChange);
                    hiddenInput.addEventListener('change', onHiddenChange);
                }

                // Watch the variant selector for price changes / hydration
                const observer = new MutationObserver(() => {
                    syncFromCheckoutSelector();
                });
                observer.observe(variantSelector, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                    attributeFilter: ['checked', 'value']
                });

                // Initial sync + a couple of delayed syncs for safety
                syncFromCheckoutSelector();
                setTimeout(syncFromCheckoutSelector, 400);
                setTimeout(syncFromCheckoutSelector, 1200);

                logDebug('Checkout mode initialised.');
            }

            // ========== Root init ==========

            function rootInit() {
                initBlockButtonsMode();
                initCheckoutMode();
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', rootInit);
            } else {
                rootInit();
            }
        })();
        </script>
        <?php
    }

    add_action( 'wp_footer', 'rup_external_price_links_inline_script', 20 );
}


/* --------------------------------------------------
   SDK Inclusion - Via Licence Box V1.1
-------------------------------------------------- */
// 1. Load the SDK once.
if ( ! class_exists( 'RUP_SureCart_Licensing_Bootstrap' ) ) {
    require_once __DIR__ . '/dist/SureCart/license-bootstrap.php';
}

// 2. Register the license config (NOT inside the settings page callback).
RUP_SureCart_Licensing_Bootstrap::register( [
    'id'          => 'rup_price_id_inks_surecart_license_box',
    'plugin_file' => __FILE__,
    'plugin_name' => 'External Price ID for SureCart',
    'public_token'=> 'pt_usTzCchJQpYtKWCoRCusHS5P',
    'textdomain'  => 'external-priceid-links-for-surecart',
    //'page_slug'   => 'surecart-external-prices',
    'redirect' => admin_url( 'admin.php?page=surecart-external-prices' ),
    'namespace'   => 'RUPEPIDL4SC\\Licensing',
    'client_file' => __DIR__ . '/dist/SureCart/Client.php', // your scoped SDK file

] );
