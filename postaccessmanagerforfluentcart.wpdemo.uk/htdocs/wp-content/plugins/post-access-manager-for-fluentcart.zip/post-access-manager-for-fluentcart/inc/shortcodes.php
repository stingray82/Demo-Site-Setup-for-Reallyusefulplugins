<?php
/**
 * Shortcodes and Gutenberg blocks for Post Access Manager for FluentCart.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ruppamfc_current_post_id_for_access(): int {
    $post_id = get_the_ID();
    return $post_id ? absint( $post_id ) : 0;
}

function ruppamfc_locked_message( int $post_id = 0, string $message = '' ): string {
    $post_id = $post_id ?: ruppamfc_current_post_id_for_access();
    $buy_link = $post_id && function_exists( 'ruppamfc_get_final_purchase_link' ) ? ruppamfc_get_final_purchase_link( $post_id ) : home_url( '/' );
    $message = $message ?: __( 'This content is protected.', 'post-access-manager-for-fluentcart' );

    return sprintf(
        '<div class="protected-content-message"><p>%s <a href="%s" class="purchase-link button">%s</a></p></div>',
        esc_html( $message ),
        esc_url( $buy_link ),
        esc_html__( 'Purchase Access', 'post-access-manager-for-fluentcart' )
    );
}

/**
 * [user_access_list]
 * Lists posts/pages the current user can access.
 */
function ruppamfc_shortcode_user_access_list( $atts = [] ): string {
    if ( ! is_user_logged_in() ) {
        return '<p>Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a> to view your purchased content.</p>';
    }

    $user_id = get_current_user_id();
    $output  = '<h2 class="rup-access-title">Purchased Post Access</h2>';

    if ( function_exists( 'ruppamfc_user_has_all_access' ) && ruppamfc_user_has_all_access( $user_id ) ) {
        return $output . '<div class="rup-access-list"><div class="rup-access-item rup-all-access-item"><span class="rup-access-text">You are an</span><span class="rup-access-highlight">All Access</span><span class="rup-access-text">user and can view all protected content</span><span class="rup-access-arrow">&rarr;</span></div></div>';
    }

    $allowed = get_user_meta( $user_id, 'allowed_posts', true );
    $allowed = is_array( $allowed ) ? array_filter( array_map( 'absint', $allowed ) ) : [];

    if ( empty( $allowed ) ) {
        return $output . '<p>You have not purchased access to any posts yet.</p>';
    }

    $query = new WP_Query( [
        'post_type'      => function_exists( 'ruppamfc_get_protected_post_types' ) ? ruppamfc_get_protected_post_types() : [ 'post', 'page' ],
        'post__in'       => $allowed,
        'posts_per_page' => -1,
        'orderby'        => 'post_date',
        'order'          => 'DESC',
    ] );

    if ( ! $query->have_posts() ) {
        return $output . '<p>You have not purchased access to any posts yet.</p>';
    }

    $output .= '<div class="rup-access-list">';
    while ( $query->have_posts() ) {
        $query->the_post();
        $output .= sprintf(
            '<a class="rup-access-item" href="%1$s">%2$s <span class="rup-access-arrow">&rarr;</span></a>',
            esc_url( get_permalink() ),
            esc_html( get_the_title() )
        );
    }
    wp_reset_postdata();

    return $output . '</div>';
}
add_shortcode( 'user_access_list', 'ruppamfc_shortcode_user_access_list' );
add_shortcode( 'pamfc_user_access_list', 'ruppamfc_shortcode_user_access_list' );

/**
 * [pamfc_protected]Protected content[/pamfc_protected]
 * Gates only the wrapped content using the current post's access rules.
 */
function ruppamfc_shortcode_protected_content( $atts = [], $content = null ): string {
    $atts = shortcode_atts( [
        'post_id' => 0,
        'message' => '',
    ], $atts, 'pamfc_protected' );

    $post_id = absint( $atts['post_id'] ) ?: ruppamfc_current_post_id_for_access();

    if ( ! $post_id || ( function_exists( 'ruppamfc_user_can_view' ) && ruppamfc_user_can_view( get_current_user_id(), $post_id ) ) ) {
        return do_shortcode( (string) $content );
    }

    return ruppamfc_locked_message( $post_id, (string) $atts['message'] );
}
add_shortcode( 'pamfc_protected', 'ruppamfc_shortcode_protected_content' );
add_shortcode( 'pamsc_protected', 'ruppamfc_shortcode_protected_content' );

/**
 * [pamfc_purchase_link] or [pamfc_purchase_button]
 * Outputs the generated FluentCart instant checkout URL/button for the current post.
 */
function ruppamfc_shortcode_purchase_link( $atts = [] ): string {
    $atts = shortcode_atts( [
        'post_id' => 0,
        'label'   => __( 'Purchase Access', 'post-access-manager-for-fluentcart' ),
        'class'   => 'purchase-link button',
    ], $atts, 'pamfc_purchase_link' );

    $post_id = absint( $atts['post_id'] ) ?: ruppamfc_current_post_id_for_access();
    if ( ! $post_id || ! function_exists( 'ruppamfc_get_final_purchase_link' ) ) {
        return '';
    }

    return sprintf(
        '<a href="%s" class="%s">%s</a>',
        esc_url( ruppamfc_get_final_purchase_link( $post_id ) ),
        esc_attr( $atts['class'] ),
        esc_html( $atts['label'] )
    );
}
add_shortcode( 'pamfc_purchase_link', 'ruppamfc_shortcode_purchase_link' );
add_shortcode( 'pamfc_purchase_button', 'ruppamfc_shortcode_purchase_link' );

/**
 * [pamfc_protected_marker] / legacy [pamsc_protected_marker]
 * Outputs the marker used by the main content filter. Content below the marker is gated.
 */
function ruppamfc_shortcode_protected_marker(): string {
    return "\n<!-- protected -->\n";
}
add_shortcode( 'pamfc_protected_marker', 'ruppamfc_shortcode_protected_marker' );
add_shortcode( 'pamsc_protected_marker', 'ruppamfc_shortcode_protected_marker' );

/**
 * [view_purchased_post]
 * On thank-you pages, links back to the post captured from the checkout URL.
 */
add_shortcode( 'view_purchased_post', function (): string {
    $param_key = function_exists( 'ruppamfc_param_key' ) ? ruppamfc_param_key() : 'post_id';
    $post_id = isset( $_GET[ $param_key ] ) ? absint( $_GET[ $param_key ] ) : 0;

    if ( ! $post_id && ! empty( $_COOKIE['pamfc_dynamic_thankyou_post_id'] ) ) {
        $post_id = absint( $_COOKIE['pamfc_dynamic_thankyou_post_id'] );
    }

    if ( ! $post_id || ! get_permalink( $post_id ) ) {
        return '';
    }

    return sprintf(
        '<p><a class="fc-button button" href="%1$s">Access your purchased post here &rarr;</a></p>',
        esc_url( get_permalink( $post_id ) )
    );
} );

/**
 * Capture post_id from generated FluentCart checkout URLs for thank-you redirects.
 */
add_action( 'init', function (): void {
    $param_key = function_exists( 'ruppamfc_param_key' ) ? ruppamfc_param_key() : 'post_id';

    if ( isset( $_GET[ $param_key ] ) ) {
        $post_id = absint( $_GET[ $param_key ] );
        if ( $post_id > 0 ) {
            setcookie( 'pamfc_dynamic_thankyou_post_id', (string) $post_id, time() + DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        }
    }
} );

add_shortcode( 'pamfc_dynamic_thankyou', '__return_empty_string' );
add_shortcode( 'sc_dynamic_thankyou', '__return_empty_string' );

add_action( 'template_redirect', function (): void {
    if ( ! is_singular() ) {
        return;
    }

    global $post;
    if ( ! $post instanceof WP_Post ) {
        return;
    }

    $has_shortcode = has_shortcode( $post->post_content, 'pamfc_dynamic_thankyou' ) || has_shortcode( $post->post_content, 'sc_dynamic_thankyou' );
    if ( ! $has_shortcode || empty( $_COOKIE['pamfc_dynamic_thankyou_post_id'] ) ) {
        return;
    }

    $target_id = absint( $_COOKIE['pamfc_dynamic_thankyou_post_id'] );
    $url = $target_id ? get_permalink( $target_id ) : '';
    if ( ! $url ) {
        return;
    }

    setcookie( 'pamfc_dynamic_thankyou_post_id', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
    wp_safe_redirect( $url );
    exit;
} );

/**
 * Gutenberg marker block. Also registers the old pamsc namespace as an alias.
 */
add_action( 'init', function (): void {
    $handle = 'pamfc-protected-marker-block';
    wp_register_script(
        $handle,
        false,
        [ 'wp-blocks', 'wp-element', 'wp-i18n', 'wp-components', 'wp-block-editor' ],
        '1.0.4',
        true
    );

    $js = <<<'JS'
(function (blocks, element, i18n, components) {
  var el = element.createElement;
  var __ = i18n.__;

  function markerEdit() {
    return el(
      components.Notice,
      { status: 'info', isDismissible: false },
      __('Protected marker inserted. Content below this block will be gated by Post Access Manager.', 'post-access-manager-for-fluentcart')
    );
  }

  blocks.registerBlockType('pamfc/protected-marker', {
    title: __('PAM FluentCart: Protected Marker', 'post-access-manager-for-fluentcart'),
    description: __('Inserts the protected marker. Content below becomes protected.', 'post-access-manager-for-fluentcart'),
    icon: 'lock',
    category: 'widgets',
    supports: { html: false, reusable: true },
    edit: markerEdit,
    save: function () { return null; }
  });

  blocks.registerBlockType('pamsc/protected-marker', {
    title: __('PAM: Protected Marker (legacy)', 'post-access-manager-for-fluentcart'),
    description: __('Legacy marker block alias.', 'post-access-manager-for-fluentcart'),
    icon: 'lock',
    category: 'widgets',
    supports: { html: false, reusable: true },
    edit: markerEdit,
    save: function () { return null; }
  });
})(window.wp.blocks, window.wp.element, window.wp.i18n, window.wp.components);
JS;

    wp_add_inline_script( $handle, $js );

    $args = [
        'editor_script'   => $handle,
        'render_callback' => function () {
            return "\n<!-- protected -->\n";
        },
    ];

    register_block_type( 'pamfc/protected-marker', $args );
    register_block_type( 'pamsc/protected-marker', $args );
} );

/**
 * Bricks condition: whether the current post is protected.
 */
add_action( 'init', function (): void {
    add_filter( 'bricks/conditions/groups', function ( $groups ) {
        $groups[] = [
            'name'  => 'pamfc_access',
            'label' => esc_html__( 'PAM FluentCart: Access', 'post-access-manager-for-fluentcart' ),
        ];
        return $groups;
    } );

    add_filter( 'bricks/conditions/options', function ( $options ) {
        $options[] = [
            'key'   => 'pamfc_post_access_protected',
            'label' => esc_html__( 'Post access protected', 'post-access-manager-for-fluentcart' ),
            'group' => 'pamfc_access',
            'compare' => [
                'type' => 'select',
                'options' => [
                    'is'     => esc_html__( 'is', 'post-access-manager-for-fluentcart' ),
                    'is_not' => esc_html__( 'is not', 'post-access-manager-for-fluentcart' ),
                ],
                'placeholder' => esc_html__( 'is', 'post-access-manager-for-fluentcart' ),
            ],
            'value' => [
                'type' => 'select',
                'options' => [
                    '1' => esc_html__( '1 (protected)', 'post-access-manager-for-fluentcart' ),
                    '0' => esc_html__( '0 (not protected)', 'post-access-manager-for-fluentcart' ),
                ],
                'placeholder' => esc_html__( '1 (protected)', 'post-access-manager-for-fluentcart' ),
                'clearable' => false,
            ],
        ];
        return $options;
    } );

    add_filter( 'bricks/conditions/result', function ( $result, $condition_key, $condition ) {
        if ( 'pamfc_post_access_protected' !== $condition_key ) {
            return $result;
        }

        $post_id = get_the_ID();
        if ( ! $post_id ) {
            return false;
        }

        $compare = isset( $condition['compare'] ) ? (string) $condition['compare'] : 'is';
        $wanted  = isset( $condition['value'] ) ? (string) $condition['value'] : '1';
        $is_protected = function_exists( 'ruppamfc_is_post_protected' ) && ruppamfc_is_post_protected( $post_id );
        $val = $is_protected ? '1' : '0';
        $match = ( $val === $wanted );

        return 'is' === $compare ? $match : ! $match;
    }, 10, 3 );
} );

add_action( 'wp_enqueue_scripts', function (): void {
    wp_register_style( 'ruppamfc-shortcodes-inline', false, [], '1.0.4' );
    wp_enqueue_style( 'ruppamfc-shortcodes-inline' );
    wp_add_inline_style( 'ruppamfc-shortcodes-inline', '
        .rup-access-title { font-size: 1.2em; font-weight: bold; margin-bottom: 0.75em; }
        .rup-access-list { display: grid; gap: 0.5em; }
        .rup-access-item { display: flex; justify-content: space-between; align-items: center; padding: 0.75em 1em; background: #fff; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; }
        .rup-access-item:hover { background: #f9f9f9; border-color: #ccc; }
        .rup-access-arrow { font-size: 1.2em; }
        .rup-all-access-item { justify-content: flex-start; gap: 0.25em; background: #e6fffa; border-color: #38b2ac; }
        .rup-access-text { white-space: nowrap; }
        .rup-access-highlight { font-weight: bold; }
    ' );
} );
