<?php
/**
 * Admin settings for Post Access Manager for FluentCart.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'RUPPAMFC_OPTION_EXPIRY_ENABLED' ) ) {
    define( 'RUPPAMFC_OPTION_EXPIRY_ENABLED', 'pae_expiry_enabled' );
}
if ( ! defined( 'RUPPAMFC_OPTION_EXPIRY_DAYS' ) ) {
    define( 'RUPPAMFC_OPTION_EXPIRY_DAYS', 'pae_expiry_days' );
}
if ( ! defined( 'RUPPAMFC_OPTION_PROTECTED_TYPES' ) ) {
    define( 'RUPPAMFC_OPTION_PROTECTED_TYPES', 'pae_protected_post_types' );
}
if ( ! defined( 'RUPPAMFC_OPTION_ALL_ACCESS_ENABLED' ) ) {
    define( 'RUPPAMFC_OPTION_ALL_ACCESS_ENABLED', 'pae_all_access_enabled' );
}
if ( ! defined( 'RUPPAMFC_OPTION_ALL_ACCESS_PRODUCT_IDS' ) ) {
    define( 'RUPPAMFC_OPTION_ALL_ACCESS_PRODUCT_IDS', 'pae_all_access_fluentcart_product_ids' );
}
if ( ! defined( 'RUPPAMFC_OPTION_ARCHIVE_BEHAVIOUR' ) ) {
    define( 'RUPPAMFC_OPTION_ARCHIVE_BEHAVIOUR', 'ruppamfc_archive_behaviour' );
}

add_action( 'admin_menu', 'ruppamfc_add_admin_menu' );
function ruppamfc_add_admin_menu(): void {
    add_menu_page(
        'Post Access Manager for FluentCart',
        'Post Access',
        'manage_options',
        'post-access-fluentcart-settings',
        'ruppamfc_render_settings_page',
        'dashicons-lock',
        60
    );
}

add_action( 'admin_enqueue_scripts', 'ruppamfc_enqueue_admin_styles' );
function ruppamfc_enqueue_admin_styles( $hook_suffix ): void {
    if ( 'toplevel_page_post-access-fluentcart-settings' !== $hook_suffix ) {
        return;
    }

    $css = '.ruppamfc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;margin-bottom:24px}.ruppamfc-section{background:#fff;border:1px solid #ddd;border-radius:8px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.05)}.ruppamfc-section h2{margin-top:0;margin-bottom:12px;font-size:1.2em}.ruppamfc-field{margin-bottom:12px}.ruppamfc-field label{font-weight:600;display:block;margin-bottom:4px}.ruppamfc-field input[type=text],.ruppamfc-field input[type=number]{width:100%;padding:6px 8px;border:1px solid #ccc;border-radius:4px}.ruppamfc-product-ids input{display:block;margin-bottom:8px;width:100%;max-width:320px}';

    wp_register_style( 'ruppamfc-admin-inline', false, [], '1.0.1' );
    wp_enqueue_style( 'ruppamfc-admin-inline' );
    wp_add_inline_style( 'ruppamfc-admin-inline', $css . '.ruppamfc-field select{width:100%;max-width:420px;padding:4px 8px}' );
}

function ruppamfc_render_settings_page(): void {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $expiry_enabled      = get_option( RUPPAMFC_OPTION_EXPIRY_ENABLED, '0' );
    $expiry_days         = absint( get_option( RUPPAMFC_OPTION_EXPIRY_DAYS, 30 ) );
    $protected_types     = get_option( RUPPAMFC_OPTION_PROTECTED_TYPES, [ 'post', 'page' ] );
    $all_access_enabled  = get_option( RUPPAMFC_OPTION_ALL_ACCESS_ENABLED, '0' );
    $all_access_products = array_pad( (array) get_option( RUPPAMFC_OPTION_ALL_ACCESS_PRODUCT_IDS, [ '', '', '' ] ), 3, '' );
    $archive_behaviour   = get_option( RUPPAMFC_OPTION_ARCHIVE_BEHAVIOUR, 'preview' );
    $post_types          = get_post_types( [ 'public' => true ], 'objects' );
    $fluent_products     = function_exists( 'ruppamfc_get_fluentcart_products' ) ? ruppamfc_get_fluentcart_products() : [];
    ?>
    <div class="wrap">
        <h1>Post Access Manager for FluentCart</h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'ruppamfc_settings_group' ); ?>

            <div class="ruppamfc-grid">
                <div class="ruppamfc-section">
                    <h2>Expiry Settings</h2>
                    <div class="ruppamfc-field">
                        <label for="<?php echo esc_attr( RUPPAMFC_OPTION_EXPIRY_ENABLED ); ?>">Enable Automatic Expiry</label>
                        <input id="<?php echo esc_attr( RUPPAMFC_OPTION_EXPIRY_ENABLED ); ?>" name="<?php echo esc_attr( RUPPAMFC_OPTION_EXPIRY_ENABLED ); ?>" type="checkbox" value="1" <?php checked( $expiry_enabled, '1' ); ?> />
                    </div>
                    <div class="ruppamfc-field">
                        <label for="<?php echo esc_attr( RUPPAMFC_OPTION_EXPIRY_DAYS ); ?>">Expiry Interval (days)</label>
                        <input id="<?php echo esc_attr( RUPPAMFC_OPTION_EXPIRY_DAYS ); ?>" name="<?php echo esc_attr( RUPPAMFC_OPTION_EXPIRY_DAYS ); ?>" type="number" min="1" value="<?php echo esc_attr( $expiry_days ); ?>" />
                        <p><strong style="color:#a00;">Please note:</strong> Cron expiry is not ideal for subscriptions or all-access products.</p>
                    </div>
                </div>

                <div class="ruppamfc-section">
                    <h2>Protected Post Types</h2>
                    <?php foreach ( $post_types as $type_key => $type_obj ) : ?>
                        <div class="ruppamfc-field">
                            <label>
                                <input name="<?php echo esc_attr( RUPPAMFC_OPTION_PROTECTED_TYPES ); ?>[]" type="checkbox" value="<?php echo esc_attr( $type_key ); ?>" <?php checked( in_array( $type_key, (array) $protected_types, true ) ); ?> />
                                <?php echo esc_html( $type_obj->labels->singular_name ); ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="ruppamfc-section">
                    <h2>Archive / Blog Protection</h2>
                    <div class="ruppamfc-field">
                        <label for="<?php echo esc_attr( RUPPAMFC_OPTION_ARCHIVE_BEHAVIOUR ); ?>">Protected post behaviour outside single posts</label>
                        <select id="<?php echo esc_attr( RUPPAMFC_OPTION_ARCHIVE_BEHAVIOUR ); ?>" name="<?php echo esc_attr( RUPPAMFC_OPTION_ARCHIVE_BEHAVIOUR ); ?>">
                            <option value="preview" <?php selected( $archive_behaviour, 'preview' ); ?>>Show preview up to protected marker</option>
                            <option value="message" <?php selected( $archive_behaviour, 'message' ); ?>>Show locked message only</option>
                            <option value="hide" <?php selected( $archive_behaviour, 'hide' ); ?>>Hide protected posts from archives/search/blog</option>
                        </select>
                        <p class="description">Default is preview. This applies to the default posts page, blog home, archives, search results, excerpts and feeds.</p>
                    </div>
                </div>

                <div class="ruppamfc-section">
                    <h2>Configure All-Access</h2>
                    <div class="ruppamfc-field">
                        <label for="<?php echo esc_attr( RUPPAMFC_OPTION_ALL_ACCESS_ENABLED ); ?>">Enable All-Access by FluentCart Product ID</label>
                        <input id="<?php echo esc_attr( RUPPAMFC_OPTION_ALL_ACCESS_ENABLED ); ?>" name="<?php echo esc_attr( RUPPAMFC_OPTION_ALL_ACCESS_ENABLED ); ?>" type="checkbox" value="1" <?php checked( $all_access_enabled, '1' ); ?> />
                    </div>
                    <div class="ruppamfc-field ruppamfc-product-ids">
                        <label>All-Access FluentCart Products (max 3)</label>
                        <?php for ( $i = 0; $i < 3; $i++ ) : ?>
                            <select name="<?php echo esc_attr( RUPPAMFC_OPTION_ALL_ACCESS_PRODUCT_IDS ); ?>[]">
                                <option value="">— Select product —</option>
                                <?php foreach ( $fluent_products as $product ) :
                                    $product_post_id = absint( $product['post_id'] ?? 0 );
                                    $title           = $product['post_title'] ?: sprintf( 'Product #%d', $product_post_id );
                                    ?>
                                    <option value="<?php echo esc_attr( $product_post_id ); ?>" <?php selected( absint( $all_access_products[ $i ] ), $product_post_id ); ?>>
                                        <?php echo esc_html( sprintf( '%s (Post ID %d)', $title, $product_post_id ) ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        <?php endfor; ?>
                        <p class="description">These match FluentCart order item <code>post_id</code> values. Products are loaded from <code>fct_product_details</code>.</p>
                        <?php if ( empty( $fluent_products ) ) : ?>
                            <p class="description" style="color:#a00;">No FluentCart products found yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

add_action( 'admin_init', 'ruppamfc_register_settings' );
function ruppamfc_register_settings(): void {
    register_setting( 'ruppamfc_settings_group', RUPPAMFC_OPTION_EXPIRY_ENABLED, [
        'type' => 'string',
        'sanitize_callback' => static function ( $value ) { return $value === '1' ? '1' : '0'; },
        'default' => '0',
    ] );

    register_setting( 'ruppamfc_settings_group', RUPPAMFC_OPTION_EXPIRY_DAYS, [
        'type' => 'integer',
        'sanitize_callback' => 'absint',
        'default' => 30,
    ] );

    register_setting( 'ruppamfc_settings_group', RUPPAMFC_OPTION_PROTECTED_TYPES, [
        'type' => 'array',
        'sanitize_callback' => 'ruppamfc_sanitize_protected_types',
        'default' => [ 'post', 'page' ],
    ] );

    register_setting( 'ruppamfc_settings_group', RUPPAMFC_OPTION_ALL_ACCESS_ENABLED, [
        'type' => 'string',
        'sanitize_callback' => static function ( $value ) { return $value === '1' ? '1' : '0'; },
        'default' => '0',
    ] );

    register_setting( 'ruppamfc_settings_group', RUPPAMFC_OPTION_ALL_ACCESS_PRODUCT_IDS, [
        'type' => 'array',
        'sanitize_callback' => 'ruppamfc_sanitize_all_access_product_ids',
        'default' => [ '', '', '' ],
    ] );

    register_setting( 'ruppamfc_settings_group', RUPPAMFC_OPTION_ARCHIVE_BEHAVIOUR, [
        'type' => 'string',
        'sanitize_callback' => 'ruppamfc_sanitize_archive_behaviour',
        'default' => 'preview',
    ] );

}

function ruppamfc_sanitize_archive_behaviour( $value ): string {
    $value = sanitize_key( (string) $value );
    return in_array( $value, [ 'preview', 'message', 'hide' ], true ) ? $value : 'preview';
}


function ruppamfc_sanitize_protected_types( $input ): array {
    $public = array_keys( get_post_types( [ 'public' => true ] ) );
    return array_values( array_intersect( $public, array_map( 'sanitize_text_field', (array) $input ) ) );
}

function ruppamfc_sanitize_all_access_product_ids( $input ): array {
    $ids = array_map( 'absint', (array) $input );
    $ids = array_map( static function ( $id ) { return $id > 0 ? (string) $id : ''; }, $ids );
    return array_pad( array_slice( $ids, 0, 3 ), 3, '' );
}

add_filter( 'ruppamfc_protected_post_types', 'ruppamfc_get_configured_protected_types' );
function ruppamfc_get_configured_protected_types( array $default ): array {
    $configured = get_option( RUPPAMFC_OPTION_PROTECTED_TYPES, [ 'post', 'page' ] );
    return ! empty( $configured ) ? (array) $configured : $default;
}



add_action( 'ruppamfc_access_granted', 'ruppamfc_schedule_expiry', 10, 1 );
function ruppamfc_schedule_expiry( array $payload ): void {
    if ( get_option( RUPPAMFC_OPTION_EXPIRY_ENABLED, '0' ) !== '1' ) {
        return;
    }

    $user_id = absint( $payload['user_id'] ?? 0 );
    $post_id = absint( $payload['post_id'] ?? 0 );

    if ( $user_id < 1 || $post_id < 1 ) {
        return;
    }

    $days = max( 1, absint( get_option( RUPPAMFC_OPTION_EXPIRY_DAYS, 30 ) ) );

    if ( ! wp_next_scheduled( 'ruppamfc_execute_expiry_event', [ $user_id, $post_id ] ) ) {
        wp_schedule_single_event( time() + DAY_IN_SECONDS * $days, 'ruppamfc_execute_expiry_event', [ $user_id, $post_id ] );
    }
}

add_action( 'ruppamfc_execute_expiry_event', 'ruppamfc_execute_expiry', 10, 2 );
function ruppamfc_execute_expiry( int $user_id, int $post_id ): void {
    if ( get_option( RUPPAMFC_OPTION_EXPIRY_ENABLED, '0' ) !== '1' ) {
        return;
    }

    if ( function_exists( 'ruppamfc_revoke_post_access' ) ) {
        ruppamfc_revoke_post_access( $user_id, $post_id );
        return;
    }

    $allowed = get_user_meta( $user_id, 'allowed_posts', true );
    if ( ! is_array( $allowed ) ) {
        return;
    }

    $allowed = array_map( 'intval', $allowed );
    if ( in_array( $post_id, $allowed, true ) ) {
        update_user_meta( $user_id, 'allowed_posts', array_values( array_diff( $allowed, [ $post_id ] ) ) );
    }
}

if ( ! function_exists( 'legacy_pae_handle_remove_access' ) ) {
    add_action( 'legacy_pae_remove_access_event', 'legacy_pae_handle_remove_access', 10, 2 );
    function legacy_pae_handle_remove_access( $user_id, $post_id ): void {
        ruppamfc_execute_expiry( absint( $user_id ), absint( $post_id ) );
    }
}
