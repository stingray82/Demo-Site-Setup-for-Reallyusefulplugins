<?php
/**
 * Plugin Name:       Post Access Manager for FluentCart
 * Description:       Sell access to posts/pages/custom post types using FluentCart product or variation purchases.
 * Version:           1.0.12
 * Requires at least: 6.5
 * Requires PHP:      8.0
 * Author:            ReallyUsefulPlugins.com
 * License:           GPL-2.0-or-later
 * Text Domain:       post-access-manager-for-fluentcart
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'RUPPAMFC_PLUGIN_FILE' ) ) {
    define( 'RUPPAMFC_PLUGIN_FILE', __FILE__ );
}

require_once plugin_dir_path( __FILE__ ) . 'inc/admin.php';
require_once plugin_dir_path( __FILE__ ) . 'inc/shortcodes.php';

/**
 * Test build notes:
 * - Uses FluentCart product post_id + optional product variation object_id as the authorization key.
 * - Grants access when payment becomes paid, and also when order status becomes completed.
 * - Revokes access on full refund and optionally on canceled/failed order status.
 * - This version deliberately does not include licensing code.
 */

function ruppamfc_log_debug( $message ): void {
    if ( defined( 'RUPPAMFC_DEBUG' ) && RUPPAMFC_DEBUG === true ) {
        error_log( '[PAM FluentCart] ' . $message );
    }
}

function ruppamfc_get_protected_post_types(): array {
    return apply_filters( 'ruppamfc_protected_post_types', [ 'post', 'page' ] );
}

function ruppamfc_param_key(): string {
    return (string) apply_filters( 'ruppamfc_param_key', 'post_id' );
}

/**
 * Fetch FluentCart products from the plugin's database tables.
 *
 * Product IDs used for matching are the WordPress post IDs stored in
 * {$wpdb->prefix}fct_product_details.post_id.
 */
function ruppamfc_get_fluentcart_products(): array {
    global $wpdb;

    $details_table = $wpdb->prefix . 'fct_product_details';
    $posts_table   = $wpdb->posts;

    $details_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $details_table ) );
    if ( $details_exists !== $details_table ) {
        return [];
    }

    $sql = "
        SELECT
            d.id AS product_detail_id,
            d.post_id,
            d.default_variation_id,
            d.min_price,
            d.max_price,
            d.variation_type,
            p.post_title
        FROM {$details_table} d
        LEFT JOIN {$posts_table} p ON p.ID = d.post_id
        ORDER BY p.post_title ASC, d.post_id ASC
    ";

    $rows = $wpdb->get_results( $sql, ARRAY_A );
    return is_array( $rows ) ? $rows : [];
}

/**
 * Fetch FluentCart variations for a product post ID.
 *
 * Variation IDs used for matching are {$wpdb->prefix}fct_product_variations.id,
 * which appear on order items as object_id.
 */
function ruppamfc_get_fluentcart_variations( int $product_post_id = 0 ): array {
    global $wpdb;

    $variations_table = $wpdb->prefix . 'fct_product_variations';
    $variations_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $variations_table ) );
    if ( $variations_exists !== $variations_table ) {
        return [];
    }

    if ( $product_post_id > 0 ) {
        $sql = $wpdb->prepare(
            "SELECT id, post_id, variation_title, variation_identifier, sku, item_price, item_status
             FROM {$variations_table}
             WHERE post_id = %d
             ORDER BY serial_index ASC, id ASC",
            $product_post_id
        );
    } else {
        $sql = "SELECT id, post_id, variation_title, variation_identifier, sku, item_price, item_status
                FROM {$variations_table}
                ORDER BY post_id ASC, serial_index ASC, id ASC";
    }

    $rows = $wpdb->get_results( $sql, ARRAY_A );
    return is_array( $rows ) ? $rows : [];
}

function ruppamfc_get_default_variation_id_for_product( int $product_post_id ): int {
    foreach ( ruppamfc_get_fluentcart_products() as $product ) {
        if ( absint( $product['post_id'] ?? 0 ) === $product_post_id ) {
            $default = absint( $product['default_variation_id'] ?? 0 );
            if ( $default ) {
                return $default;
            }
        }
    }

    $variations = ruppamfc_get_fluentcart_variations( $product_post_id );
    if ( ! empty( $variations[0]['id'] ) ) {
        return absint( $variations[0]['id'] );
    }

    return 0;
}

function ruppamfc_get_instant_checkout_url( int $product_post_id, int $variation_id = 0 ): string {
    $item_id = $variation_id > 0 ? $variation_id : ruppamfc_get_default_variation_id_for_product( $product_post_id );

    if ( ! $item_id ) {
        $item_id = $product_post_id;
    }

    return add_query_arg(
        [
            'fluent-cart' => 'instant_checkout',
            'item_id'     => $item_id,
            'quantity'    => 1,
        ],
        home_url( '/' )
    );
}


/* --------------------------------------------------
 * Admin metaboxes
 * -------------------------------------------------- */

add_action( 'add_meta_boxes', function () {
    $types = ruppamfc_get_protected_post_types();

    add_meta_box(
        'ruppamfc_protected_toggle_meta_box',
        'Post Access Protection',
        'ruppamfc_render_protected_toggle_meta_box',
        $types,
        'side',
        'high'
    );

    add_meta_box(
        'ruppamfc_authorized_fluentcart_meta_box',
        'Authorized FluentCart Product',
        'ruppamfc_render_authorized_fluentcart_meta_box',
        $types,
        'side',
        'high'
    );

    add_meta_box(
        'ruppamfc_post_id_meta_box',
        'Post Information',
        function ( $post ) {
            echo '<p><strong>Post ID:</strong> ' . esc_html( $post->ID ) . '</p>';
        },
        $types,
        'side',
        'high'
    );
} );

function ruppamfc_render_protected_toggle_meta_box( WP_Post $post ): void {
    wp_nonce_field( 'ruppamfc_save_post_meta', 'ruppamfc_nonce' );
    $protected = get_post_meta( $post->ID, '_post_access_protected', true );
    ?>
    <label for="ruppamfc_post_access_protected">
        <input type="checkbox" name="ruppamfc_post_access_protected" id="ruppamfc_post_access_protected" value="1" <?php checked( $protected, '1' ); ?> />
        Protect Post Access
    </label>
    <?php
}

function ruppamfc_render_authorized_fluentcart_meta_box( WP_Post $post ): void {
    wp_nonce_field( 'ruppamfc_save_post_meta', 'ruppamfc_nonce' );

    $selected_product_id   = absint( get_post_meta( $post->ID, '_authorized_fluentcart_product_id', true ) );
    $selected_variation_id = absint( get_post_meta( $post->ID, '_authorized_fluentcart_variation_id', true ) );
    $products              = ruppamfc_get_fluentcart_products();
    $all_variations        = ruppamfc_get_fluentcart_variations( 0 );
    ?>
    <p>
        <label for="ruppamfc_authorized_product_id"><strong>FluentCart Product</strong></label>
        <select name="ruppamfc_authorized_product_id" id="ruppamfc_authorized_product_id" style="width:100%;">
            <option value="">— Select product —</option>
            <?php foreach ( $products as $product ) :
                $product_post_id = absint( $product['post_id'] ?? 0 );
                $title           = $product['post_title'] ?: sprintf( 'Product #%d', $product_post_id );
                ?>
                <option value="<?php echo esc_attr( $product_post_id ); ?>" data-default-variation="<?php echo esc_attr( absint( $product['default_variation_id'] ?? 0 ) ); ?>" <?php selected( $selected_product_id, $product_post_id ); ?>>
                    <?php echo esc_html( sprintf( '%s (Post ID %d)', $title, $product_post_id ) ); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>

    <p>
        <label for="ruppamfc_authorized_variation_id"><strong>Variation / Checkout Item</strong></label>
        <select name="ruppamfc_authorized_variation_id" id="ruppamfc_authorized_variation_id" style="width:100%;">
            <option value="">Any/default variation</option>
            <?php foreach ( $all_variations as $variation ) :
                $variation_id      = absint( $variation['id'] ?? 0 );
                $variation_post_id = absint( $variation['post_id'] ?? 0 );
                $title             = $variation['variation_title'] ?: sprintf( 'Variation #%d', $variation_id );
                ?>
                <option value="<?php echo esc_attr( $variation_id ); ?>" data-product="<?php echo esc_attr( $variation_post_id ); ?>" <?php selected( $selected_variation_id, $variation_id ); ?>>
                    <?php echo esc_html( sprintf( '%s (Item ID %d)', $title, $variation_id ) ); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>

    <?php
    $checkout_link = $selected_product_id ? ruppamfc_get_instant_checkout_url( $selected_product_id, $selected_variation_id ) : '';
    ?>
    <p>
        <label for="ruppamfc_generated_checkout_link"><strong>Generated Checkout Link</strong></label>
        <input type="text" id="ruppamfc_generated_checkout_link" value="<?php echo esc_url( $checkout_link ); ?>" style="width:100%;" readonly />
    </p>
    <p class="description">This link is generated automatically from the selected FluentCart product/variation and is the link shown to locked-out users. Save/update the post after changing the product or variation to refresh it.</p>

    <?php if ( empty( $products ) ) : ?>
        <p class="description" style="color:#a00;">No FluentCart products were found in the <code>fct_product_details</code> table.</p>
    <?php else : ?>
        <p class="description">The product select stores FluentCart <code>fct_product_details.post_id</code>. The variation select stores <code>fct_product_variations.id</code>, which should match order item <code>object_id</code> and instant checkout <code>item_id</code>.</p>
    <?php endif; ?>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const productSelect = document.getElementById('ruppamfc_authorized_product_id');
        const variationSelect = document.getElementById('ruppamfc_authorized_variation_id');
        const checkoutLink = document.getElementById('ruppamfc_generated_checkout_link');
        const checkoutBase = <?php echo wp_json_encode( home_url( '/' ) ); ?>;

        function updateCheckoutLink() {
            if (!productSelect || !checkoutLink) return;
            const productOption = productSelect.options[productSelect.selectedIndex];
            const productId = productSelect.value;
            const variationId = variationSelect ? variationSelect.value : '';
            const defaultVariationId = productOption ? productOption.dataset.defaultVariation : '';
            const itemId = variationId || defaultVariationId || productId;

            if (!itemId) {
                checkoutLink.value = '';
                return;
            }

            const url = new URL(checkoutBase);
            url.searchParams.set('fluent-cart', 'instant_checkout');
            url.searchParams.set('item_id', itemId);
            url.searchParams.set('quantity', '1');
            checkoutLink.value = url.toString();
        }

        function filterVariations() {
            if (!productSelect || !variationSelect) return;
            const productId = productSelect.value;
            Array.from(variationSelect.options).forEach(function(option) {
                if (!option.value) {
                    option.hidden = false;
                    return;
                }
                option.hidden = productId && option.dataset.product !== productId;
            });

            const selected = variationSelect.options[variationSelect.selectedIndex];
            if (selected && selected.hidden) {
                variationSelect.value = '';
            }
            updateCheckoutLink();
        }

        filterVariations();
        updateCheckoutLink();
        if (productSelect) {
            productSelect.addEventListener('change', function () {
                filterVariations();
                updateCheckoutLink();
            });
        }
        if (variationSelect) {
            variationSelect.addEventListener('change', updateCheckoutLink);
        }
    });
    </script>
    <?php
}

add_action( 'save_post', function ( int $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( ! isset( $_POST['ruppamfc_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ruppamfc_nonce'] ) ), 'ruppamfc_save_post_meta' ) ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['ruppamfc_post_access_protected'] ) ) {
        update_post_meta( $post_id, '_post_access_protected', '1' );
    } else {
        delete_post_meta( $post_id, '_post_access_protected' );
    }

    $product_id = isset( $_POST['ruppamfc_authorized_product_id'] ) ? absint( $_POST['ruppamfc_authorized_product_id'] ) : 0;
    $variant_id = isset( $_POST['ruppamfc_authorized_variation_id'] ) ? absint( $_POST['ruppamfc_authorized_variation_id'] ) : 0;

    $product_id ? update_post_meta( $post_id, '_authorized_fluentcart_product_id', (string) $product_id ) : delete_post_meta( $post_id, '_authorized_fluentcart_product_id' );
    $variant_id ? update_post_meta( $post_id, '_authorized_fluentcart_variation_id', (string) $variant_id ) : delete_post_meta( $post_id, '_authorized_fluentcart_variation_id' );
} );

/* --------------------------------------------------
 * Access helpers
 * -------------------------------------------------- */

function ruppamfc_get_final_purchase_link( int $post_id ): string {
    $product_id   = absint( get_post_meta( $post_id, '_authorized_fluentcart_product_id', true ) );
    $variation_id = absint( get_post_meta( $post_id, '_authorized_fluentcart_variation_id', true ) );

    if ( $product_id ) {
        return add_query_arg( ruppamfc_param_key(), $post_id, ruppamfc_get_instant_checkout_url( $product_id, $variation_id ) );
    }

    return apply_filters( 'ruppamfc_default_purchase_link', home_url( '/' ), $post_id );
}

function ruppamfc_is_post_protected( int $post_id ): bool {
    $protected = get_post_meta( $post_id, '_post_access_protected', true ) === '1';
    return (bool) apply_filters( 'ruppamfc_is_post_protected', $protected, $post_id );
}

function ruppamfc_user_has_all_access( int $user_id ): bool {
    return $user_id > 0 && get_user_meta( $user_id, 'all_access_granted', true ) === '1';
}

function ruppamfc_user_can_view( int $user_id, int $post_id ): bool {
    if ( $user_id <= 0 ) {
        return false;
    }

    if ( ruppamfc_user_has_all_access( $user_id ) ) {
        return true;
    }

    $allowed = get_user_meta( $user_id, 'allowed_posts', true );
    $allowed = is_array( $allowed ) ? array_map( 'intval', $allowed ) : [];

    return in_array( $post_id, $allowed, true );
}

function ruppamfc_grant_post_access( int $user_id, int $post_id ): void {
    if ( $user_id <= 0 || $post_id <= 0 ) {
        return;
    }

    $allowed = get_user_meta( $user_id, 'allowed_posts', true );
    $allowed = is_array( $allowed ) ? array_map( 'intval', $allowed ) : [];

    if ( ! in_array( $post_id, $allowed, true ) ) {
        $allowed[] = $post_id;
        update_user_meta( $user_id, 'allowed_posts', array_values( array_unique( $allowed ) ) );
    }
}

function ruppamfc_revoke_post_access( int $user_id, int $post_id ): void {
    if ( $user_id <= 0 || $post_id <= 0 ) {
        return;
    }

    $allowed = get_user_meta( $user_id, 'allowed_posts', true );
    $allowed = is_array( $allowed ) ? array_map( 'intval', $allowed ) : [];

    if ( in_array( $post_id, $allowed, true ) ) {
        $allowed = array_values( array_diff( $allowed, [ $post_id ] ) );
        update_user_meta( $user_id, 'allowed_posts', $allowed );
    }
}

function ruppamfc_grant_all_access_to_user( int $user_id ): void {
    if ( $user_id > 0 ) {
        update_user_meta( $user_id, 'all_access_granted', '1' );
    }
}

function ruppamfc_revoke_all_access_from_user( int $user_id ): void {
    if ( $user_id > 0 ) {
        delete_user_meta( $user_id, 'all_access_granted' );
    }
}

/* --------------------------------------------------
 * Front-end content protection
 * -------------------------------------------------- */

/**
 * Marker helpers.
 * Supports classic HTML comments, marker shortcodes, and Gutenberg marker blocks.
 */
function ruppamfc_get_protected_marker_regex(): string {
    return '/<!--\s*protected\s*-->|\[(?:pamfc|pamsc)_protected_marker[^\]]*\]|<!--\s*wp:(?:pamfc|pamsc)\/protected-marker\b[^>]*\/?\s*-->(?:\s*<!--\s*\/wp:(?:pamfc|pamsc)\/protected-marker\s*-->)?/i';
}

function ruppamfc_split_content_at_protected_marker( string $content ): ?array {
    $regex = ruppamfc_get_protected_marker_regex();

    if ( ! preg_match( $regex, $content ) ) {
        return null;
    }

    $parts = preg_split( $regex, $content, 2 );

    if ( ! is_array( $parts ) ) {
        return null;
    }

    return [
        isset( $parts[0] ) ? (string) $parts[0] : '',
        isset( $parts[1] ) ? (string) $parts[1] : '',
    ];
}

/**
 * Archive/blog protection helpers. Default: show only content before <!-- protected --> outside single protected posts.
 */
function ruppamfc_get_archive_behaviour(): string {
    $behaviour = get_option( 'ruppamfc_archive_behaviour', 'preview' );
    return in_array( $behaviour, [ 'preview', 'message', 'hide' ], true ) ? $behaviour : 'preview';
}

function ruppamfc_is_archive_like_context(): bool {
    if ( is_admin() || is_singular( ruppamfc_get_protected_post_types() ) ) {
        return false;
    }
    return is_home() || is_archive() || is_search() || is_feed();
}

function ruppamfc_get_archive_locked_message( int $post_id, bool $plain = false ): string {
    if ( $plain ) {
        return (string) apply_filters( 'ruppamfc_archive_locked_message_plain', 'This content is protected. Purchase access to read it.', $post_id );
    }
    $buy_link = function_exists( 'ruppamfc_get_final_purchase_link' ) ? ruppamfc_get_final_purchase_link( $post_id ) : '';
    return (string) apply_filters( 'ruppamfc_archive_locked_message', sprintf( '<p class="protected-content-message">This content is protected. <a href="%s">Purchase access</a> to read it.</p>', esc_url( $buy_link ) ), $post_id, $buy_link );
}

function ruppamfc_get_marker_preview_for_archive( int $post_id, bool $format = true ): string {
    $raw_content = get_post_field( 'post_content', $post_id );
    if ( ! is_string( $raw_content ) || $raw_content === '' ) { return ''; }

    $parts = ruppamfc_split_content_at_protected_marker( $raw_content );
    if ( null !== $parts ) {
        $preview = isset( $parts[0] ) ? (string) $parts[0] : '';
    } else {
        // Security-first default: if a protected post has no marker, do not leak
        // the manual excerpt or trimmed content in archive/blog/search contexts.
        return '';
    }

    if ( $preview === '' ) { return ''; }
    if ( ! $format ) { return wp_kses_post( $preview ); }

    remove_filter( 'the_content', 'ruppamfc_filter_archive_protected_content', 9 );
    remove_filter( 'the_content', 'ruppamfc_filter_protected_content', 20 );
    $formatted = apply_filters( 'the_content', $preview );
    add_filter( 'the_content', 'ruppamfc_filter_protected_content', 20 );
    add_filter( 'the_content', 'ruppamfc_filter_archive_protected_content', 9 );

    return is_string( $formatted ) ? $formatted : '';
}

function ruppamfc_filter_archive_protected_content( $content ) {
    if ( ! ruppamfc_is_archive_like_context() ) { return $content; }
    $post_id = absint( get_the_ID() );
    if ( ! $post_id || ! ruppamfc_is_post_protected( $post_id ) || ruppamfc_user_can_view( get_current_user_id(), $post_id ) ) { return $content; }
    $behaviour = ruppamfc_get_archive_behaviour();
    if ( 'hide' === $behaviour ) { return ''; }
    if ( 'message' === $behaviour ) { return ruppamfc_get_archive_locked_message( $post_id, false ); }

    // Preview mode: if a marker exists, show the preview before it AND a protected notice.
    // If no marker exists, never leak the post/excerpt; show the locked message only.
    $preview = ruppamfc_get_marker_preview_for_archive( $post_id, true );
    if ( $preview !== '' ) {
        return $preview . ruppamfc_get_archive_locked_message( $post_id, false );
    }

    return ruppamfc_get_archive_locked_message( $post_id, false );
}
add_filter( 'the_content', 'ruppamfc_filter_archive_protected_content', 9 );

function ruppamfc_filter_archive_protected_excerpt( $excerpt ) {
    if ( ! ruppamfc_is_archive_like_context() ) { return $excerpt; }
    $post_id = absint( get_the_ID() );
    if ( ! $post_id || ! ruppamfc_is_post_protected( $post_id ) || ruppamfc_user_can_view( get_current_user_id(), $post_id ) ) { return $excerpt; }
    $behaviour = ruppamfc_get_archive_behaviour();
    if ( 'hide' === $behaviour ) { return ''; }
    if ( 'message' === $behaviour ) { return ruppamfc_get_archive_locked_message( $post_id, true ); }

    // Preview mode for excerpt contexts. Keep enough room for the protected notice.
    $preview = ruppamfc_get_marker_preview_for_archive( $post_id, false );
    if ( $preview !== '' ) {
        $preview_text = trim( wp_trim_words( wp_strip_all_tags( $preview ), 28, '…' ) );
        $notice_text  = ruppamfc_get_archive_locked_message( $post_id, true );
        return trim( $preview_text . ' ' . $notice_text );
    }

    return ruppamfc_get_archive_locked_message( $post_id, true );
}
add_filter( 'the_excerpt', 'ruppamfc_filter_archive_protected_excerpt', 9 );
add_filter( 'get_the_excerpt', 'ruppamfc_filter_archive_protected_excerpt', 9 );

function ruppamfc_hide_protected_posts_from_archives( $query ): void {
    if ( is_admin() || ! $query instanceof WP_Query || ! $query->is_main_query() ) { return; }
    if ( 'hide' !== ruppamfc_get_archive_behaviour() ) { return; }
    if ( ! ( $query->is_home() || $query->is_archive() || $query->is_search() || $query->is_feed() ) ) { return; }
    $meta_query = (array) $query->get( 'meta_query' );
    $meta_query[] = [ 'relation' => 'OR', [ 'key' => '_post_access_protected', 'compare' => 'NOT EXISTS' ], [ 'key' => '_post_access_protected', 'value' => '1', 'compare' => '!=' ] ];
    $query->set( 'meta_query', $meta_query );
}
add_action( 'pre_get_posts', 'ruppamfc_hide_protected_posts_from_archives', 20 );


function ruppamfc_filter_protected_content( string $content ): string {
    if ( ! is_singular( ruppamfc_get_protected_post_types() ) ) {
        return $content;
    }

    $post_id = get_the_ID();
    if ( ! $post_id || ! ruppamfc_is_post_protected( $post_id ) ) {
        return $content;
    }

    if ( ruppamfc_user_can_view( get_current_user_id(), $post_id ) ) {
        return $content;
    }

    $preview = '';

    $rendered_parts = ruppamfc_split_content_at_protected_marker( $content );
    if ( null !== $rendered_parts ) {
        $preview = $rendered_parts[0];
    } else {
        $raw_content = get_post_field( 'post_content', $post_id );
        if ( is_string( $raw_content ) ) {
            $raw_parts = ruppamfc_split_content_at_protected_marker( $raw_content );
            if ( null !== $raw_parts ) {
                $raw_preview = $raw_parts[0];

                remove_filter( 'the_content', 'ruppamfc_filter_protected_content', 20 );
                $preview = apply_filters( 'the_content', $raw_preview );
                add_filter( 'the_content', 'ruppamfc_filter_protected_content', 20 );
            }
        }
    }

    $buy_link = ruppamfc_get_final_purchase_link( $post_id );
    $output = $preview . sprintf(
        '<div class="protected-content-message"><p>This content is protected. <a href="%s" class="purchase-link button">Purchase Access</a></p></div>',
        esc_url( $buy_link )
    );

    return apply_filters( 'ruppamfc_protected_content_output', $output, $post_id, $buy_link );
}
add_filter( 'the_content', 'ruppamfc_filter_protected_content', 20 );

/* --------------------------------------------------
 * User profile fields
 * -------------------------------------------------- */

add_action( 'show_user_profile', 'ruppamfc_user_profile_fields' );
add_action( 'edit_user_profile', 'ruppamfc_user_profile_fields' );

function ruppamfc_user_profile_fields( WP_User $user ): void {
    if ( ! current_user_can( 'edit_user', $user->ID ) ) {
        return;
    }

    $allowed_posts = get_user_meta( $user->ID, 'allowed_posts', true );
    $allowed_list  = is_array( $allowed_posts ) ? implode( ',', array_map( 'intval', $allowed_posts ) ) : '';
    $all_access    = get_user_meta( $user->ID, 'all_access_granted', true ) === '1';
    ?>
    <h3>Post Access Manager for FluentCart</h3>
    <table class="form-table">
        <tr>
            <th><label for="ruppamfc_allowed_posts">Allowed Post IDs</label></th>
            <td>
                <input type="text" name="ruppamfc_allowed_posts" id="ruppamfc_allowed_posts" value="<?php echo esc_attr( $allowed_list ); ?>" class="regular-text" />
                <p class="description">Comma-separated protected post IDs.</p>
            </td>
        </tr>
        <tr>
            <th><label for="ruppamfc_all_access_granted">All-Access Granted</label></th>
            <td>
                <input type="checkbox" name="ruppamfc_all_access_granted" id="ruppamfc_all_access_granted" value="1" <?php checked( $all_access, true ); ?> />
                <span class="description">Bypass all post protections.</span>
            </td>
        </tr>
    </table>
    <?php
}

add_action( 'personal_options_update', 'ruppamfc_save_user_profile_fields' );
add_action( 'edit_user_profile_update', 'ruppamfc_save_user_profile_fields' );

function ruppamfc_save_user_profile_fields( int $user_id ): void {
    if ( ! current_user_can( 'edit_user', $user_id ) ) {
        return;
    }

    $input = isset( $_POST['ruppamfc_allowed_posts'] ) ? sanitize_text_field( wp_unslash( $_POST['ruppamfc_allowed_posts'] ) ) : '';
    $ids   = array_filter( array_map( 'absint', explode( ',', $input ) ) );
    update_user_meta( $user_id, 'allowed_posts', array_values( array_unique( $ids ) ) );

    if ( isset( $_POST['ruppamfc_all_access_granted'] ) && $_POST['ruppamfc_all_access_granted'] === '1' ) {
        update_user_meta( $user_id, 'all_access_granted', '1' );
    } else {
        delete_user_meta( $user_id, 'all_access_granted' );
    }
}

/* --------------------------------------------------
 * FluentCart order integration
 * -------------------------------------------------- */

function ruppamfc_get_wp_user_id_from_fluentcart_order( $order ): int {
    $customer = $order->customer ?? null;

    if ( $customer && ! empty( $customer->user_id ) ) {
        return absint( $customer->user_id );
    }

    if ( ! empty( $order->customer_id ) && class_exists( '\FluentCart\App\Models\Customer' ) ) {
        try {
            $customer = \FluentCart\App\Models\Customer::find( $order->customer_id );
            if ( $customer && ! empty( $customer->user_id ) ) {
                return absint( $customer->user_id );
            }
        } catch ( Throwable $e ) {
            ruppamfc_log_debug( 'Customer lookup failed: ' . $e->getMessage() );
        }
    }

    $email = '';
    if ( $customer && ! empty( $customer->email ) ) {
        $email = sanitize_email( $customer->email );
    } elseif ( ! empty( $order->email ) ) {
        $email = sanitize_email( $order->email );
    }

    if ( $email ) {
        $user = get_user_by( 'email', $email );
        if ( $user ) {
            return absint( $user->ID );
        }

        if ( apply_filters( 'ruppamfc_create_wp_user_if_missing', true, $email, $order ) ) {
            $password = wp_generate_password();
            $user_id  = wp_create_user( $email, $password, $email );
            if ( ! is_wp_error( $user_id ) ) {
                return absint( $user_id );
            }
        }
    }

    return 0;
}

function ruppamfc_get_order_items( $order ): array {
    if ( isset( $order->order_items ) && is_iterable( $order->order_items ) ) {
        return is_array( $order->order_items ) ? $order->order_items : iterator_to_array( $order->order_items );
    }

    if ( isset( $order->filteredOrderItems ) && is_iterable( $order->filteredOrderItems ) ) {
        return is_array( $order->filteredOrderItems ) ? $order->filteredOrderItems : iterator_to_array( $order->filteredOrderItems );
    }

    if ( class_exists( '\FluentCart\App\Models\OrderItem' ) && ! empty( $order->id ) ) {
        try {
            $items = \FluentCart\App\Models\OrderItem::where( 'order_id', $order->id )->get();
            return $items && is_iterable( $items ) ? iterator_to_array( $items ) : [];
        } catch ( Throwable $e ) {
            ruppamfc_log_debug( 'Order item lookup failed: ' . $e->getMessage() );
        }
    }

    return [];
}

function ruppamfc_get_matching_posts_for_order( $order ): array {
    $items = ruppamfc_get_order_items( $order );

    if ( empty( $items ) ) {
        ruppamfc_log_debug( 'No FluentCart order items found for order ' . ( $order->id ?? 'unknown' ) );
        return [];
    }

    $matched_posts = [];

    foreach ( $items as $item ) {
        $product_id   = isset( $item->post_id ) ? absint( $item->post_id ) : 0;
        $variation_id = isset( $item->object_id ) ? absint( $item->object_id ) : 0;

        if ( ! $product_id ) {
            continue;
        }

        $query = new WP_Query( [
            'post_type'      => ruppamfc_get_protected_post_types(),
            'post_status'    => 'any',
            'fields'         => 'ids',
            'posts_per_page' => -1,
            'meta_query'     => [
                [
                    'key'     => '_authorized_fluentcart_product_id',
                    'value'   => (string) $product_id,
                    'compare' => '=',
                ],
            ],
        ] );

        foreach ( $query->posts as $post_id ) {
            $required_variation = absint( get_post_meta( $post_id, '_authorized_fluentcart_variation_id', true ) );

            if ( $required_variation && $required_variation !== $variation_id ) {
                continue;
            }

            $matched_posts[] = absint( $post_id );
        }
    }

    return array_values( array_unique( $matched_posts ) );
}

function ruppamfc_order_has_all_access_product( $order ): bool {
    $enabled = get_option( 'pae_all_access_enabled', '0' );
    if ( '1' !== $enabled ) {
        return false;
    }

    $ids = (array) get_option( 'pae_all_access_fluentcart_product_ids', [] );
    $ids = array_filter( array_map( 'absint', $ids ) );

    if ( empty( $ids ) ) {
        return false;
    }

    foreach ( ruppamfc_get_order_items( $order ) as $item ) {
        if ( isset( $item->post_id ) && in_array( absint( $item->post_id ), $ids, true ) ) {
            return true;
        }
    }

    return false;
}

function ruppamfc_grant_access_from_order( $data ): void {
    $order = is_array( $data ) && isset( $data['order'] ) ? $data['order'] : null;
    if ( ! $order ) {
        return;
    }

    $processed_key = '_ruppamfc_access_granted_order_' . absint( $order->id ?? 0 );
    if ( ! empty( $order->id ) && get_transient( $processed_key ) ) {
        return;
    }

    $user_id = ruppamfc_get_wp_user_id_from_fluentcart_order( $order );
    if ( ! $user_id ) {
        ruppamfc_log_debug( 'Grant failed: could not identify WP user for order ' . ( $order->id ?? 'unknown' ) );
        return;
    }

    if ( ruppamfc_order_has_all_access_product( $order ) ) {
        ruppamfc_grant_all_access_to_user( $user_id );
        do_action( 'ruppamfc_access_granted', [
            'user_id'  => $user_id,
            'post_id'  => 'all',
            'order_id' => $order->id ?? 0,
        ] );
        return;
    }

    $post_ids = ruppamfc_get_matching_posts_for_order( $order );

    foreach ( $post_ids as $post_id ) {
        ruppamfc_grant_post_access( $user_id, $post_id );

        do_action( 'ruppamfc_access_granted', [
            'user_id'  => $user_id,
            'post_id'  => $post_id,
            'order_id' => $order->id ?? 0,
        ] );
    }

    if ( ! empty( $order->id ) ) {
        set_transient( $processed_key, 1, DAY_IN_SECONDS );
    }
}

function ruppamfc_revoke_access_from_order( $data ): void {
    $order = is_array( $data ) && isset( $data['order'] ) ? $data['order'] : null;
    if ( ! $order ) {
        return;
    }

    $user_id = ruppamfc_get_wp_user_id_from_fluentcart_order( $order );
    if ( ! $user_id ) {
        ruppamfc_log_debug( 'Revoke failed: could not identify WP user for order ' . ( $order->id ?? 'unknown' ) );
        return;
    }

    if ( ruppamfc_order_has_all_access_product( $order ) ) {
        ruppamfc_revoke_all_access_from_user( $user_id );
        do_action( 'ruppamfc_access_revoked', [
            'user_id'  => $user_id,
            'post_id'  => 'all',
            'order_id' => $order->id ?? 0,
        ] );
        return;
    }

    foreach ( ruppamfc_get_matching_posts_for_order( $order ) as $post_id ) {
        ruppamfc_revoke_post_access( $user_id, $post_id );

        do_action( 'ruppamfc_access_revoked', [
            'user_id'  => $user_id,
            'post_id'  => $post_id,
            'order_id' => $order->id ?? 0,
        ] );
    }
}

// Main grant hooks.
add_action( 'fluent_cart/payment_status_changed_to_paid', 'ruppamfc_grant_access_from_order', 10, 1 );
add_action( 'fluent_cart/order_status_changed_to_completed', 'ruppamfc_grant_access_from_order', 10, 1 );

// Revoke hooks.
add_action( 'fluent_cart/order_fully_refunded', 'ruppamfc_revoke_access_from_order', 10, 1 );

add_action( 'fluent_cart/order_status_changed', function ( $data ) {
    $new_status = is_array( $data ) && isset( $data['new_status'] ) ? (string) $data['new_status'] : '';

    if ( in_array( $new_status, [ 'canceled', 'cancelled', 'failed' ], true ) ) {
        ruppamfc_revoke_access_from_order( $data );
    }
}, 10, 1 );

/* --------------------------------------------------
 * Admin post ID columns
 * -------------------------------------------------- */

add_filter( 'manage_posts_columns', function ( $columns ) {
    $columns['ruppamfc_post_id'] = 'Post ID';
    return $columns;
} );

add_filter( 'manage_pages_columns', function ( $columns ) {
    $columns['ruppamfc_post_id'] = 'Post ID';
    return $columns;
} );

add_action( 'manage_posts_custom_column', function ( $column_name, $post_id ) {
    if ( 'ruppamfc_post_id' === $column_name ) {
        echo esc_html( $post_id );
    }
}, 10, 2 );

add_action( 'manage_pages_custom_column', function ( $column_name, $post_id ) {
    if ( 'ruppamfc_post_id' === $column_name ) {
        echo esc_html( $post_id );
    }
}, 10, 2 );

/* --------------------------------------------------
 * Simple CSS
 * -------------------------------------------------- */

add_action( 'wp_head', function () {
    echo '<style>.hidden-post-id{display:none!important}.protected-content-message{margin:1.5em 0;padding:1em;border:1px solid currentColor}</style>';
} );
