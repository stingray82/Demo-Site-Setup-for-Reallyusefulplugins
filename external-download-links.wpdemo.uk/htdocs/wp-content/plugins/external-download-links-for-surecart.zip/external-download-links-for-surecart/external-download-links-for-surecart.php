<?php
/**
 * Plugin Name:       External Download Links for SureCart
 * Description:       Sell Large Files with External Download Links in Surecart
 * Version:           1.1.4
 * Requires at least: 6.5
 * Tested up to:      6.9
 * Requires PHP:      8.0
 * Author:            ReallyUsefulPlugins.com
 * Author URI:        https://Reallyusefulplugins.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       external-download-links-for-surecart
 * Website:           https://reallyusefulplugins.com
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * OPTION + META KEYS (unchanged to preserve existing data)
 */
define( 'SC_LINKMAP_OPTION', 'sc_linkmap_mappings' );          // Stores all link mappings
define( 'SC_LINKMAP_USER_META_KEY', 'sc_linkmap_price_ids' );  // Stores allowed price IDs per user

/* ============================================================
 * MAPPINGS HELPERS
 * ============================================================ */

/**
 * Helper: get all mappings (array of rows).
 *
 * Each row:
 * [
 *   'id'       => int,
 *   'name'     => string,
 *   'price_id' => string,
 *   'url'      => string,
 * ]
 */
function rup_sc_external_downloads_get_mappings() : array {
    $mappings = get_option( SC_LINKMAP_OPTION, [] );
    if ( ! is_array( $mappings ) ) {
        $mappings = [];
    }
    return $mappings;
}

/**
 * Helper: save all mappings.
 */
function rup_sc_external_downloads_save_mappings( array $mappings ) : void {
    // Reindex by integer ID for sanity.
    $clean = [];
    foreach ( $mappings as $row ) {
        if ( empty( $row['id'] ) ) {
            continue;
        }
        $id = (int) $row['id'];
        if ( $id <= 0 ) {
            continue;
        }
        $clean[ $id ] = [
            'id'       => $id,
            'name'     => isset( $row['name'] ) ? sanitize_text_field( $row['name'] ) : '',
            'price_id' => isset( $row['price_id'] ) ? sanitize_text_field( $row['price_id'] ) : '',
            'url'      => isset( $row['url'] ) ? esc_url_raw( $row['url'] ) : '',
        ];
    }

    update_option( SC_LINKMAP_OPTION, $clean );
}

/**
 * Helper: get next numeric ID for mappings.
 */
function rup_sc_external_downloads_get_next_id( array $mappings ) : int {
    if ( empty( $mappings ) ) {
        return 1;
    }
    $ids = array_map( 'intval', wp_list_pluck( $mappings, 'id' ) );
    return max( $ids ) + 1;
}

/* ============================================================
 * SURECART PRODUCTS + PRICES (for admin picker)
 * ============================================================ */

/**
 * Get all SureCart products (sc_product) and their prices.
 *
 * Returns an array of:
 * [
 *   'post_id'    => (int),
 *   'title'      => (string),
 *   'product_id' => (string SureCart product UUID),
 *   'prices'     => [
 *      [
 *        'id'             => (string price UUID),
 *        'name'           => (string price name),
 *        'display_amount' => (string e.g. "US$9.99"),
 *      ],
 *      ...
 *   ],
 * ]
 */
function rup_sc_external_downloads_get_products_with_prices() : array {
    $products_with_prices = [];

    $posts = get_posts(
        [
            'post_type'      => 'sc_product',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ]
    );

    if ( empty( $posts ) ) {
        return $products_with_prices;
    }

    foreach ( $posts as $post ) {
        $raw = get_post_meta( $post->ID, 'product', true );

        if ( empty( $raw ) ) {
            continue;
        }

        $product = is_string( $raw ) ? maybe_unserialize( $raw ) : $raw;
        if ( empty( $product ) || ! is_array( $product ) ) {
            continue;
        }

        $product_id = isset( $product['id'] ) ? $product['id'] : '';
        $prices     = [];

        // Prefer active_prices if present, fall back to prices.data.
        if ( ! empty( $product['active_prices'] ) && is_array( $product['active_prices'] ) ) {
            $price_source = $product['active_prices'];
        } elseif (
            ! empty( $product['prices'] ) &&
            is_array( $product['prices'] ) &&
            ! empty( $product['prices']['data'] ) &&
            is_array( $product['prices']['data'] )
        ) {
            $price_source = $product['prices']['data'];
        } else {
            $price_source = [];
        }

        foreach ( $price_source as $price ) {
            if ( ! is_array( $price ) ) {
                continue;
            }

            $price_id   = isset( $price['id'] ) ? $price['id'] : '';
            $price_name = isset( $price['name'] ) ? $price['name'] : '';
            $display    = isset( $price['display_amount'] ) ? $price['display_amount'] : '';

            if ( ! $price_id ) {
                continue;
            }

            $prices[] = [
                'id'             => $price_id,
                'name'           => $price_name,
                'display_amount' => $display,
            ];
        }

        if ( empty( $prices ) ) {
            continue;
        }

        $products_with_prices[] = [
            'post_id'    => $post->ID,
            'title'      => get_the_title( $post ),
            'product_id' => $product_id,
            'prices'     => $prices,
        ];
    }

    return $products_with_prices;
}

/* ============================================================
 * ADMIN: MENU + SAVE
 * ============================================================ */

/**
 * Add settings page under "Settings".

function rup_sc_external_downloads_admin_menu() {
    add_options_page(
        __( 'SureCart External Download Links', 'surecart-link-mapper' ),
        __( 'SureCart Downloads', 'surecart-link-mapper' ),
        'manage_options',
        'sc-link-mapper',
        'rup_sc_external_downloads_render_admin_page'
    );
}
add_action( 'admin_menu', 'rup_sc_external_downloads_admin_menu' );
 */

function rup_sc_external_downloads_admin_menu() {
    add_submenu_page(
        'sc-dashboard', // parent = SureCart
        __( 'SureCart External Download Links', 'surecart-link-mapper' ),
        __( 'External Downloads', 'surecart-link-mapper' ),
        'manage_options',
        'sc-link-mapper',
        'rup_sc_external_downloads_render_admin_page'
    );
}
add_action( 'admin_menu', 'rup_sc_external_downloads_admin_menu', 99 );




/**
 * Handle form save.
 */
function rup_sc_external_downloads_admin_init() {
    // Make sure this whole routine only runs once per request.
    static $rup_downloads_save_ran = false;

    if ( $rup_downloads_save_ran ) {
        return;
    }

    if ( ! isset( $_POST['sc_linkmap_submit'] ) ) {
        return;
    }
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    check_admin_referer( 'sc_linkmap_save', 'sc_linkmap_nonce' );

    $rup_downloads_save_ran = true;

    $raw_items = isset( $_POST['sc_linkmap_items'] ) && is_array( $_POST['sc_linkmap_items'] )
        ? $_POST['sc_linkmap_items']
        : [];

    $existing = rup_sc_external_downloads_get_mappings();
    $next_id  = rup_sc_external_downloads_get_next_id( $existing );
    $new      = [];

    foreach ( $raw_items as $row_id => $row ) {
        // Skip deleted rows.
        if ( isset( $row['delete'] ) && $row['delete'] === '1' ) {
            continue;
        }

        $name     = isset( $row['name'] ) ? sanitize_text_field( $row['name'] ) : '';
        $price_id = isset( $row['price_id'] ) ? sanitize_text_field( $row['price_id'] ) : '';
        $url      = isset( $row['url'] ) ? esc_url_raw( $row['url'] ) : '';

        // Ignore completely empty rows.
        if ( '' === $name && '' === $price_id && '' === $url ) {
            continue;
        }

        // Determine ID: existing numeric, or assign new.
        if ( ! empty( $row['id'] ) && is_numeric( $row['id'] ) ) {
            $id = (int) $row['id'];
        } else {
            $id = $next_id++;
        }

        $new[] = [
            'id'       => $id,
            'name'     => $name,
            'price_id' => $price_id,
            'url'      => $url,
        ];
    }

    rup_sc_external_downloads_save_mappings( $new );

    // Set a transient so we can show a one-off success notice on the next page load.
    set_transient( 'rup_sc_external_downloads_saved', 1, 30 );
}
add_action( 'admin_init', 'rup_sc_external_downloads_admin_init' );

/* ============================================================
 * ADMIN: PAGE RENDER (with modern skin + product/price picker)
 * ============================================================ */

/**
 * Render settings page.
 */
function rup_sc_external_downloads_render_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    // One-off success notice after saving.
    if ( get_transient( 'rup_sc_external_downloads_saved' ) ) {
        delete_transient( 'rup_sc_external_downloads_saved' );
        echo '<div class="notice notice-success is-dismissible"><p>' .
             esc_html__( 'Download link mappings saved.', 'surecart-link-mapper' ) .
             '</p></div>';
    }

    $mappings    = rup_sc_external_downloads_get_mappings();
    $sc_products = rup_sc_external_downloads_get_products_with_prices();

    // Add one empty row for "new" entry.
    $mappings[] = [
        'id'       => '',
        'name'     => '',
        'price_id' => '',
        'url'      => '',
    ];


RUP_SureCart_Licensing_Bootstrap::render_box( 'ruppamfsc', [
    'title' => __( 'External Download Manager Licence', 'external-download-links-for-surecart' ),
] );

    ?>

        <style>
            /* ==========================
            PAGE HEADINGS
            =========================== */

            .wrap h1 {
                font-size: 24px;
                font-weight: 600;
                margin: 0 0 16px;
                color: #111827;
                letter-spacing: -0.02em;
            }

            .wrap h2 {
                font-size: 16px;
                font-weight: 600;
                margin: 24px 0 8px;
                color: #111827;
            }

            /* ==========================
            TABLE LAYOUT & COLUMNS
            =========================== */

            #rup-sc-downloads-table {
                border-collapse: separate;
                border-spacing: 0 10px;
                width: 100%;
                box-sizing: border-box;
            }

            /* Flex header row so columns align with body */
            #rup-sc-downloads-table thead tr {
                display: flex;
                gap: 6px;
                margin-left: 10px;
                margin-right: 10px;
            }

            /* Each body row is also flex; all cells top-align */
            #rup-sc-downloads-table tbody tr {
                display: flex;
                gap: 6px;
                align-items: flex-start;
                background: #ffffff;
                box-shadow: 0 8px 20px rgba(15, 23, 42, 0.04);
                border-radius: 12px;
                overflow: hidden;
                box-sizing: border-box;
            }

            /* Header cells */
            #rup-sc-downloads-table thead tr th {
                background: #f3f4f6;
                padding: 8px 14px !important;
                font-weight: 600;
                border-bottom: 1px solid #e2e8f0;
                border-radius: 8px;
                font-size: 13px;
                line-height: 1.3;
                color: #374151;
                text-align: left;
                white-space: nowrap;
                box-sizing: border-box;
            }
            #rup-sc-downloads-table thead tr th:first-child {
                padding-left: 20px !important;
            }
            #rup-sc-downloads-table thead tr th:last-child {
                padding-right: 20px !important;
            }

            /* Body cells */
            #rup-sc-downloads-table tbody tr td {
                padding: 10px 14px;
                background: #ffffff;
                border-top: 1px solid #f3f4f6;
                font-size: 13px;
                box-sizing: border-box;
            }

            /* first & last cell borders / rounding + padding */
            #rup-sc-downloads-table tbody tr td:first-child {
                border-left: 1px solid #e5e7eb;
                border-radius: 12px 0 0 12px;
                padding-left: 20px;
            }
            #rup-sc-downloads-table tbody tr td:last-child {
                border-right: 1px solid #e5e7eb;
                border-radius: 0 12px 12px 0;
                text-align: center;
                padding-right: 20px;
            }

            /* Column flex widths */
            #rup-sc-downloads-table thead tr th:nth-child(1),
            #rup-sc-downloads-table tbody tr td:nth-child(1) { flex: 1 1 20%; }

            #rup-sc-downloads-table thead tr th:nth-child(2),
            #rup-sc-downloads-table tbody tr td:nth-child(2) { flex: 1 1 20%; }

            #rup-sc-downloads-table thead tr th:nth-child(3),
            #rup-sc-downloads-table tbody tr td:nth-child(3) { flex: 1 1 25%; }

            #rup-sc-downloads-table thead tr th:nth-child(4),
            #rup-sc-downloads-table tbody tr td:nth-child(4) { flex: 1 1 30%; }

            #rup-sc-downloads-table thead tr th:nth-child(5),
            #rup-sc-downloads-table tbody tr td:nth-child(5) { flex: 0 0 5%; }

            /* Row hover */
            #rup-sc-downloads-table tbody tr:hover {
                background: #f9fafb;
                box-shadow: 0 10px 25px rgba(15, 23, 42, 0.08);
            }

            /* Inputs & selects */
            #rup-sc-downloads-table input.regular-text,
            #rup-sc-downloads-table select {
                border: 1px solid #d1d5db;
                border-radius: 8px;
                padding: 8px 11px;
                background: #f9fafb;
                transition: border-color .18s ease, box-shadow .18s ease, background-color .18s ease;
                width: 100%;
                box-sizing: border-box;
                font-size: 13px;
                height: 38px;
            }
            #rup-sc-downloads-table input.regular-text:focus,
            #rup-sc-downloads-table select:focus {
                border-color: #2563eb;
                box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.8);
                outline: none;
                background: #ffffff;
            }
            #rup-sc-downloads-table select option[value=""] {
                color: #9ca3af;
            }

            /* Price description under selector */
            .rup-sc-price-description {
                font-size: 12px;
                color: #6b7280;
                margin-top: 4px;
                padding-left: 2px;
                line-height: 1.4;
            }

            .rup-sc-product-price-picker {
                margin-top: 0;
            }
            .rup-sc-product-select,
            .rup-sc-price-select {
                margin-top: 0;
                margin-bottom: 4px;
                cursor: pointer;
            }
            .rup-sc-product-select:hover,
            .rup-sc-price-select:hover {
                border-color: #9ca3af;
            }

            /* Card wrapper */
            .rup-sc-card {
                background: #ffffff;
                padding: 18px 18px 12px;
                border-radius: 16px;
                box-shadow: 0 18px 40px rgba(15, 23, 42, 0.06);
                margin-bottom: 24px;
                border: 1px solid #e5e7eb;
            }
        </style>

        <p><?php esc_html_e( 'Map SureCart prices to download links. Users will only see links for Price IDs they have purchased.', 'surecart-link-mapper' ); ?></p>

        <form method="post">
            <?php wp_nonce_field( 'sc_linkmap_save', 'sc_linkmap_nonce' ); ?>

            <div class="rup-sc-card">
                <table class="widefat fixed striped" id="rup-sc-downloads-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Product', 'surecart-link-mapper' ); ?></th>
                            <th><?php esc_html_e( 'Price / Version', 'surecart-link-mapper' ); ?></th>
                            <th><?php esc_html_e( 'Friendly Name', 'surecart-link-mapper' ); ?></th>
                            <th><?php esc_html_e( 'Download URL', 'surecart-link-mapper' ); ?></th>
                            <th><?php esc_html_e( 'Delete', 'surecart-link-mapper' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $mappings as $row ) : ?>
                        <?php
                        $row_id        = $row['id'] !== '' ? (int) $row['id'] : 'new_' . wp_generate_uuid4();
                        $price_id_val  = isset( $row['price_id'] ) ? $row['price_id'] : '';
                        $is_last_blank = ( '' === $row['id'] && '' === $row['name'] && '' === $row['url'] && '' === $row['price_id'] );
                        ?>
                        <tr>
                            <!-- PRODUCT -->
                            <td>
                                <input type="hidden"
                                    name="sc_linkmap_items[<?php echo esc_attr( $row_id ); ?>][id]"
                                    value="<?php echo esc_attr( $row['id'] ); ?>" />
                                <select class="rup-sc-product-select">
                                    <option value=""><?php esc_html_e( '— Select product —', 'surecart-link-mapper' ); ?></option>
                                    <?php foreach ( $sc_products as $product ) : ?>
                                        <option value="<?php echo esc_attr( $product['post_id'] ); ?>">
                                            <?php echo esc_html( $product['title'] ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>

                            <!-- PRICE / VERSION -->
                            <td>
                                <div class="rup-sc-product-price-picker">
                                    <select class="rup-sc-price-select" <?php echo empty( $sc_products ) ? 'disabled="disabled"' : ''; ?>>
                                        <option value=""><?php esc_html_e( '— Select price / version —', 'surecart-link-mapper' ); ?></option>
                                    </select>
                                    <p class="description rup-sc-price-description"></p>

                                    <input type="hidden"
                                        name="sc_linkmap_items[<?php echo esc_attr( $row_id ); ?>][price_id]"
                                        value="<?php echo esc_attr( $price_id_val ); ?>"
                                        class="rup-sc-price-id-field" />
                                </div>
                            </td>

                            <!-- FRIENDLY NAME -->
                            <td>
                                <input type="text"
                                    name="sc_linkmap_items[<?php echo esc_attr( $row_id ); ?>][name]"
                                    value="<?php echo esc_attr( $row['name'] ); ?>"
                                    class="regular-text"
                                    placeholder="<?php esc_attr_e( 'e.g. Members Area', 'surecart-link-mapper' ); ?>" />
                            </td>

                            <!-- DOWNLOAD URL -->
                            <td>
                                <input type="url"
                                    name="sc_linkmap_items[<?php echo esc_attr( $row_id ); ?>][url]"
                                    value="<?php echo esc_url( $row['url'] ); ?>"
                                    class="regular-text"
                                    placeholder="<?php esc_attr_e( 'https://example.com/download', 'surecart-link-mapper' ); ?>" />
                            </td>

                            <!-- DELETE -->
                            <td>
                                <?php if ( ! $is_last_blank ) : ?>
                                    <label>
                                        <input type="checkbox"
                                            name="sc_linkmap_items[<?php echo esc_attr( $row_id ); ?>][delete]"
                                            value="1" />
                                        <?php esc_html_e( 'Delete', 'surecart-link-mapper' ); ?>
                                    </label>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <p class="description">
                <?php esc_html_e( 'Select a product and price; the Price ID is stored automatically in the background.', 'surecart-link-mapper' ); ?><br>
                <?php esc_html_e( 'Tick "Delete" to remove a row, then save.', 'surecart-link-mapper' ); ?>
            </p>

            <p>
                <input type="submit"
                    name="sc_linkmap_submit"
                    class="button button-primary"
                    value="<?php esc_attr_e( 'Save Mappings', 'surecart-link-mapper' ); ?>" />
            </p>
        </form>
    </div>

    <?php if ( ! empty( $sc_products ) ) : ?>
    <script>
    (function() {
        const products = <?php echo wp_json_encode( $sc_products ); ?> || [];
        const productMap = {};
        products.forEach(function (p) {
            productMap[String(p.post_id)] = p;
        });

        const rows = document.querySelectorAll('#rup-sc-downloads-table tbody tr');

        rows.forEach(function (row) {
            const priceIdInput = row.querySelector('.rup-sc-price-id-field');
            const productSelect = row.querySelector('.rup-sc-product-select');
            const priceSelect   = row.querySelector('.rup-sc-price-select');
            const desc          = row.querySelector('.rup-sc-price-description');

            if (!priceIdInput || !productSelect || !priceSelect) {
                return;
            }

            function populatePricesForProduct(postId) {
                priceSelect.innerHTML = '';
                const placeholder = document.createElement('option');
                placeholder.value = '';
                placeholder.textContent = '<?php echo esc_js( '— Select price / version —' ); ?>';
                priceSelect.appendChild(placeholder);

                const product = productMap[String(postId)];
                if (!product || !product.prices) {
                    priceSelect.disabled = true;
                    return;
                }

                product.prices.forEach(function (price) {
                    const opt = document.createElement('option');
                    opt.value = price.id;
                    let label = price.name || price.id;
                    if (price.display_amount) {
                        label += ' (' + price.display_amount + ')';
                    }
                    opt.textContent = label;
                    priceSelect.appendChild(opt);
                });

                priceSelect.disabled = false;
            }

            productSelect.addEventListener('change', function () {
                const postId = this.value;
                desc.textContent = '';
                populatePricesForProduct(postId);

                priceSelect.value = '';
                priceIdInput.value = '';
            });

            priceSelect.addEventListener('change', function () {
                const selectedPriceId = this.value;
                priceIdInput.value = selectedPriceId;

                const postId  = productSelect.value;
                const product = productMap[String(postId)];
                if (!product) {
                    desc.textContent = '';
                    return;
                }
                const price = (product.prices || []).find(function (p) {
                    return p.id === selectedPriceId;
                });
                if (price) {
                    let text = product.title + ' – ' + (price.name || '');
                    if (price.display_amount) {
                        text += ' (' + price.display_amount + ')';
                    }
                    desc.textContent = text;
                } else {
                    desc.textContent = '';
                }
            });

            // Preselect product/price if a Price ID is already stored.
            const existingId = priceIdInput.value.trim();
            if (existingId) {
                products.forEach(function (product) {
                    const match = (product.prices || []).find(function (p) {
                        return p.id === existingId;
                    });
                    if (match) {
                        productSelect.value = String(product.post_id);
                        populatePricesForProduct(product.post_id);
                        priceSelect.value = existingId;

                        let text = product.title + ' – ' + (match.name || '');
                        if (match.display_amount) {
                            text += ' (' + match.display_amount + ')';
                        }
                        desc.textContent = text;
                    }
                });
            }
        });
    })();
    </script>
    <?php
    endif;
}

/* ============================================================
 * USER META HELPERS
 * ============================================================ */

/**
 * Get array of SureCart price IDs a user has access to.
 */
function rup_sc_external_downloads_get_user_price_ids( int $user_id ) : array {
    if ( $user_id <= 0 ) {
        return [];
    }
    $ids = get_user_meta( $user_id, SC_LINKMAP_USER_META_KEY, true );
    if ( ! is_array( $ids ) ) {
        $ids = [];
    }
    $ids = array_map( 'strval', $ids );
    $ids = array_unique( $ids );
    return $ids;
}

/**
 * Add a price ID to the user's allowed IDs.
 */
function rup_sc_external_downloads_add_price_to_user( int $user_id, string $price_id ) : void {
    $price_id = trim( $price_id );
    if ( $user_id <= 0 || '' === $price_id ) {
        return;
    }
    $ids = rup_sc_external_downloads_get_user_price_ids( $user_id );
    if ( ! in_array( $price_id, $ids, true ) ) {
        $ids[] = $price_id;
        update_user_meta( $user_id, SC_LINKMAP_USER_META_KEY, $ids );
    }
}

/**
 * Remove a price ID from the user's allowed IDs.
 */
function rup_sc_external_downloads_remove_price_from_user( int $user_id, string $price_id ) : void {
    $price_id = trim( $price_id );
    if ( $user_id <= 0 || '' === $price_id ) {
        return;
    }
    $ids = rup_sc_external_downloads_get_user_price_ids( $user_id );
    if ( empty( $ids ) ) {
        return;
    }
    $ids = array_filter(
        $ids,
        function ( $id ) use ( $price_id ) {
            return (string) $id !== (string) $price_id;
        }
    );
    update_user_meta( $user_id, SC_LINKMAP_USER_META_KEY, $ids );
}

/* ============================================================
 * SURECART INTEGRATION
 * ============================================================ */

/**
 * Helper: identify the purchased price ID from a Checkout object.
 *
 * @param \SureCart\Models\Checkout $checkout
 * @return string Price ID or empty string.
 */
function rup_sc_external_downloads_checkout_get_price_id( $checkout ) : string {
    if ( ! $checkout || ! isset( $checkout->line_items ) ) {
        return '';
    }
    $line_items = $checkout->line_items->data ?? [];
    $first      = reset( $line_items );
    if ( $first && ! empty( $first->price_id ) ) {
        return (string) $first->price_id;
    }
    return '';
}

/**
 * Helper: find or create a WP user from a SureCart checkout (by current user or email).
 *
 * @param \SureCart\Models\Checkout $checkout
 * @return int User ID or 0.
 */
function rup_sc_external_downloads_checkout_get_user_id( $checkout ) : int {
    $user_id = get_current_user_id();
    if ( $user_id ) {
        return (int) $user_id;
    }

    $email = isset( $checkout->email ) ? sanitize_email( $checkout->email ) : '';
    if ( ! $email ) {
        return 0;
    }

    $user = get_user_by( 'email', $email );
    if ( $user ) {
        return (int) $user->ID;
    }

    $password = wp_generate_password();
    $user_id  = wp_create_user( $email, $password, $email );
    if ( is_wp_error( $user_id ) ) {
        return 0;
    }

    return (int) $user_id;
}

/**
 * Checkout confirmed → grant the purchased price ID.
 */
add_action(
    'surecart/checkout_confirmed',
    function ( $checkout, $request ) {
        $price_id = rup_sc_external_downloads_checkout_get_price_id( $checkout );
        if ( '' === $price_id ) {
            return;
        }

        $user_id = rup_sc_external_downloads_checkout_get_user_id( $checkout );
        if ( ! $user_id ) {
            return;
        }

        rup_sc_external_downloads_add_price_to_user( $user_id, $price_id );
    },
    10,
    2
);

/**
 * Purchase revoked → revoke the price ID for that user.
 */
add_action(
    'surecart/purchase_revoked',
    function ( $purchase, $webhook_data = null ) {

        $price_id = '';
        if ( isset( $purchase->price ) ) {
            $price_id = (string) $purchase->price;
        } elseif ( isset( $purchase->price_id ) ) {
            $price_id = (string) $purchase->price_id;
        }

        if ( '' === $price_id ) {
            error_log( '[sc-linkmap] purchase_revoked: no price/price_id on purchase ' . ( $purchase->id ?? 'unknown' ) );
            return;
        }

        $email = '';

        if ( ! empty( $purchase->customer ) && class_exists( '\SureCart\Models\Customer' ) ) {
            try {
                $customer = \SureCart\Models\Customer::find( (string) $purchase->customer );
                if ( $customer && ! empty( $customer->email ) ) {
                    $email = sanitize_email( $customer->email );
                }
            } catch ( \Throwable $e ) {
                error_log( '[sc-linkmap] purchase_revoked: error loading customer ' . $e->getMessage() );
            }
        }

        if ( ! $email ) {
            error_log( '[sc-linkmap] purchase_revoked: could not determine customer email for purchase ' . ( $purchase->id ?? 'unknown' ) );
            return;
        }

        $user = get_user_by( 'email', $email );
        if ( ! $user ) {
            error_log( '[sc-linkmap] purchase_revoked: no WP user for email ' . $email );
            return;
        }

        rup_sc_external_downloads_remove_price_from_user( (int) $user->ID, $price_id );
        error_log( '[sc-linkmap] purchase_revoked: removed price ' . $price_id . ' from user ' . $user->ID );
    },
    10,
    2
);

/**
 * Purchase invoked (restored) → re-grant the price ID.
 */
add_action(
    'surecart/purchase_invoked',
    function ( $purchase, $webhook_data = null ) {
        static $has_run = false;
        if ( $has_run ) {
            return;
        }
        $has_run = true;

        if ( ! class_exists( '\SureCart\Models\Purchase' ) || ! class_exists( '\SureCart\Models\Checkout' ) ) {
            return;
        }

        $purchase_data = \SureCart\Models\Purchase::with( [ 'initial_order' ] )
            ->find( $purchase->id );
        if ( empty( $purchase_data->initial_order ) ) {
            return;
        }

        $raw_checkout = $purchase_data->initial_order->checkout;
        if ( $raw_checkout instanceof \SureCart\Models\Checkout ) {
            $checkout = $raw_checkout;
        } else {
            $checkout = \SureCart\Models\Checkout::with( [ 'metadata', 'line_items', 'line_items.price' ] )
                ->find( (string) $raw_checkout );
        }
        if ( ! $checkout ) {
            return;
        }

        $price_id = rup_sc_external_downloads_checkout_get_price_id( $checkout );
        if ( '' === $price_id ) {
            return;
        }

        $user_id = rup_sc_external_downloads_checkout_get_user_id( $checkout );
        if ( ! $user_id ) {
            return;
        }

        rup_sc_external_downloads_add_price_to_user( $user_id, $price_id );
    },
    10,
    2
);

/* ============================================================
 * SHORTCODE: [surecart_links]
 * ============================================================ */

add_shortcode(
    'surecart_links',
    function ( $atts ) {
        $atts = shortcode_atts(
            [
                'price_ids' => '',
                'title'     => __( 'File Download', 'surecart-link-mapper' ),
            ],
            $atts,
            'surecart_links'
        );

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return '';
        }

        $user_price_ids = rup_sc_external_downloads_get_user_price_ids( $user_id );
        if ( empty( $user_price_ids ) ) {
            $html = sprintf(
                '<div class="sc-account-section sc-linkmap-section">
                    <div class="sc-account-section-header">
                        <h2 class="sc-account-section-title">%s</h2>
                    </div>
                    <div class="sc-account-empty">
                        <p>%s</p>
                    </div>
                </div>',
                esc_html( $atts['title'] ),
                esc_html__( "You don't have any downloads.", 'surecart-link-mapper' )
            );
            return $html;
        }

        // Optional limit to specific price IDs.
        if ( ! empty( $atts['price_ids'] ) ) {
            $limit_price_ids = array_filter( array_map( 'trim', explode( ',', $atts['price_ids'] ) ) );
            $limit_price_ids = array_map( 'strval', $limit_price_ids );
            $user_price_ids  = array_values( array_intersect( $user_price_ids, $limit_price_ids ) );
            if ( empty( $user_price_ids ) ) {
                return '';
            }
        }

        $mappings = rup_sc_external_downloads_get_mappings();
        if ( empty( $mappings ) ) {
            return '';
        }

        // Only show links for price IDs the user owns.
        $visible_links = array_filter(
            $mappings,
            function ( $row ) use ( $user_price_ids ) {
                if ( empty( $row['price_id'] ) || empty( $row['url'] ) ) {
                    return false;
                }
                return in_array( (string) $row['price_id'], $user_price_ids, true );
            }
        );

        if ( empty( $visible_links ) ) {
            return '';
        }

        ob_start();
        ?>
        <div class="sc-account-section sc-linkmap-section">
            <div class="sc-account-section-header">
                <h2 class="sc-account-section-title">
                    <?php echo esc_html( $atts['title'] ); ?>
                </h2>
            </div>

            <div class="sc-card sc-linkmap-download-card">
                <?php foreach ( $visible_links as $row ) : ?>
                    <?php
                    $extension = '';
                    $url       = $row['url'];
                    $path      = wp_parse_url( $url, PHP_URL_PATH );
                    if ( $path ) {
                        $info = pathinfo( $path );
                        if ( ! empty( $info['extension'] ) ) {
                            $extension = strtolower( $info['extension'] );
                        }
                    }
                    if ( ! $extension ) {
                        $extension = 'file';
                    }
                    ?>
                    <div class="sc-linkmap-download-row">
                        <div class="sc-linkmap-download-left">
                            <div class="sc-linkmap-file-icon">
                                <?php echo esc_html( $extension ); ?>
                            </div>
                            <div class="sc-linkmap-name"
                                data-price-id="<?php echo esc_attr( $row['price_id'] ); ?>">
                                <?php echo esc_html( $row['name'] ?: __( 'Download', 'surecart-link-mapper' ) ); ?>
                            </div>
                        </div>

                        <div class="sc-linkmap-download-right">
                            <?php
                       // Build secure, obfuscated download URL.
                        $secure_url = add_query_arg(
                            [
                                'sc_secure_download_link' => (int) $row['id'],
                            ],
                            home_url( '/' )
                        );

                        // Add nonce to the URL.
                        $secure_url = wp_nonce_url(
                            $secure_url,
                            'sc_secure_download_link_' . (int) $row['id'],
                            'scd'
                        );

                    ?>
                    <a href="<?php echo esc_url( $secure_url ); ?>"
                        class="sc-button sc-linkmap-download-button">
                        <?php esc_html_e( 'Download', 'surecart-link-mapper' ); ?>
                    </a>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
);

/* ============================================================
 * FRONTEND STYLES
 * ============================================================ */

/**
 * Enqueue default styles for the download list.
 *
 * Filters (unchanged):
 *   sc_linkmap_enable_default_css (bool)
 *   sc_linkmap_inline_css         (string)
 */
function rup_sc_external_downloads_enqueue_styles() {
    $enabled = apply_filters( 'sc_linkmap_enable_default_css', true );
    if ( ! $enabled ) {
        return;
    }

    $css = "
    .sc-linkmap-section {
        margin-top: 1.75rem;
        margin-bottom: 1.75rem;
    }
    .sc-account-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.75rem;
    }
    .sc-account-section-title {
        font-size: 1.125rem;
        font-weight: 600;
        margin: 0 0 0.25rem 0;
    }

    .sc-card.sc-linkmap-download-card {
        border-radius: 12px;
        border: 1px solid rgba(15,23,42,0.06);
        background: #ffffff;
        overflow: hidden;
    }
    .sc-linkmap-download-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0.85rem 1.25rem;
        font-size: 0.95rem;
    }
    .sc-linkmap-download-row + .sc-linkmap-download-row {
        border-top: 1px solid rgba(15,23,42,0.06);
    }
    .sc-linkmap-download-left {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    .sc-linkmap-file-icon {
        width: 40px;
        height: 40px;
        border-radius: 6px;
        background: #f3f4f6;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.75rem;
        font-weight: 500;
        text-transform: lowercase;
        color: #4b5563;
        flex-shrink: 0;
    }
    .sc-linkmap-name {
        font-weight: 600;
        color: #111827;
    }
    .sc-linkmap-download-right {
        display: flex;
        align-items: center;
    }

    .sc-linkmap-download-button,
    .sc-linkmap-download-button:link,
    .sc-linkmap-download-button:visited,
    .sc-linkmap-download-button:hover,
    .sc-linkmap-download-button:focus,
    .sc-linkmap-download-button:active {
        text-decoration: none !important;
    }

    .sc-linkmap-download-button {
        border-radius: 4px;
        padding: 0.35rem 0.9rem;
        font-size: 0.85rem;
        border: 1px solid #d1d5db;
        background: #f9fafb;
        color: #111827;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-weight: 500;
        line-height: 1.2;
    }
    .sc-linkmap-download-button:hover {
        background: #e5e7eb;
    }

    .sc-account-empty {
        padding: 1.5rem 0;
        text-align: center;
        color: #6b7280;
        font-size: 0.95rem;
    }

    @media (max-width: 640px) {
        .sc-linkmap-download-row {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.5rem;
        }
        .sc-linkmap-download-right {
            width: 100%;
            justify-content: flex-start;
        }
    }
    ";

    $css = apply_filters( 'sc_linkmap_inline_css', $css );
    if ( ! $css ) {
        return;
    }

    wp_register_style( 'sc-linkmap-styles', false );
    wp_enqueue_style( 'sc-linkmap-styles' );
    wp_add_inline_style( 'sc-linkmap-styles', $css );
}
add_action( 'wp_enqueue_scripts', 'rup_sc_external_downloads_enqueue_styles' );

/**
 * Handle secure SureCart downloads.
 *
 * URL pattern example:
 *   https://yoursite.com/?sc_secure_download_link=123&scd=nonce
 */
function rup_sc_external_downloads_handle_secure_download() {
    // Only run on front-end.
    if ( is_admin() ) {
        return;
    }

    if ( ! isset( $_GET['sc_secure_download_link'] ) ) {
        return;
    }

    // Make sure pluggable functions such as auth_redirect() are loaded.
    if ( ! function_exists( 'auth_redirect' ) ) {
        require_once ABSPATH . 'wp-includes/pluggable.php';
    }

    $mapping_id = absint( $_GET['sc_secure_download_link'] );
    if ( $mapping_id <= 0 ) {
        wp_die( esc_html__( 'Invalid download link.', 'surecart-link-mapper' ) );
    }

    // Verify nonce.
    $nonce = isset( $_GET['scd'] ) ? sanitize_text_field( wp_unslash( $_GET['scd'] ) ) : '';
    if ( ! wp_verify_nonce( $nonce, 'sc_secure_download_link_' . $mapping_id ) ) {
        wp_die( esc_html__( 'Invalid or expired download link.', 'surecart-link-mapper' ) );
    }

    // Require login – redirects to login page if not logged in.
    if ( ! is_user_logged_in() ) {
        auth_redirect(); // exits
    }

    $user_id = get_current_user_id();
    if ( ! $user_id ) {
        wp_die( esc_html__( 'You must be logged in to access this file.', 'surecart-link-mapper' ) );
    }

    $mappings = rup_sc_external_downloads_get_mappings();

    if ( empty( $mappings[ $mapping_id ] ) ) {
        wp_die( esc_html__( 'Download not found.', 'surecart-link-mapper' ) );
    }

    $row = $mappings[ $mapping_id ];

    if ( empty( $row['url'] ) || empty( $row['price_id'] ) ) {
        wp_die( esc_html__( 'Download is not configured correctly.', 'surecart-link-mapper' ) );
    }

    // Check this user actually owns the mapped price.
    $user_price_ids = rup_sc_external_downloads_get_user_price_ids( $user_id );
    if ( empty( $user_price_ids ) || ! in_array( (string) $row['price_id'], $user_price_ids, true ) ) {
        wp_die( esc_html__( 'You do not have access to this download.', 'surecart-link-mapper' ) );
    }

    // All good – redirect to the actual external URL.
    $target = rup_sc_edl_google_drive_to_download_url( $row['url'] );
    $target = esc_url_raw( $target );

    if ( ! $target ) {
        wp_die( esc_html__( 'Download URL is invalid.', 'surecart-link-mapper' ) );
    }

    wp_redirect( $target );
    exit;


    // Use a normal redirect so external domains (CDN, S3, etc.) work.
    wp_redirect( $target );
    exit;

}
add_action( 'init', 'rup_sc_external_downloads_handle_secure_download', 0 );


/**
 * If this is a Google Drive view link, convert to direct download URL.
 */
function rup_sc_edl_google_drive_to_download_url( string $url ) : string {
    $parts = wp_parse_url( $url );
    if ( empty( $parts['host'] ) || strpos( $parts['host'], 'drive.google.com' ) === false ) {
        return $url; // not Google Drive
    }

    $id = '';

    // Pattern: /file/d/<id>/
    if ( ! empty( $parts['path'] ) && preg_match( '~^/file/d/([^/]+)~', $parts['path'], $m ) ) {
        $id = $m[1];
    }

    // Pattern: ...open?id=<id>
    if ( ! $id && ! empty( $parts['query'] ) ) {
        parse_str( $parts['query'], $query );
        if ( ! empty( $query['id'] ) ) {
            $id = $query['id'];
        }
    }

    if ( ! $id ) {
        return $url; // couldn't detect, fall back
    }

    return 'https://drive.google.com/uc?export=download&id=' . rawurlencode( $id );
}






/* --------------------------------------------------
   SDK Inclusion - Via Licence Box V1.1
-------------------------------------------------- */
if ( ! class_exists( 'RUP_SureCart_Licensing_Bootstrap' ) ) {
    require_once __DIR__ . '/dist/SureCart/license-bootstrap.php';
}


RUP_SureCart_Licensing_Bootstrap::register( [
    'id'          => 'ruppamfsc',
    'plugin_file' => __FILE__,
    'plugin_name' => 'External Download Links for SureCart',
    'public_token'=> 'pt_usTzCchJQpYtKWCoRCusHS5P',
    'textdomain'  => 'external-download-links-for-surecart',
    //'page_slug' => 'sc-link-mapper', // optional now; bootstrap won't use it if redirect is set
    'redirect'    => admin_url( 'admin.php?page=sc-link-mapper' ),
    'namespace'   => 'RUPEDL4SC\\Licensing',
    'client_file' => __DIR__ . '/dist/SureCart/Client.php',
] );